# Stage 10 fresh browser-only completeness assessment

Date: 2026-10-22. Status: assessment complete; no completeness findings established for the supplied case. The port supports the requested artifact drafts without borrowing the Workshop application's facts. The drafts still need Toolshare's withheld project facts and real verification before publication.

Teaching source: visible public UI at `http://localhost:3100/stages/10-documentation#choose`, reached through the configured Playwright MCP fallback. Controller supplied production build identity: `YDyl-9Cl-MRjn8rpkfEza`; I did not inspect server files or hidden browser state to verify that identity. I read only the assessment brief, its two named case/question files, and the Browser skill. I did not read source, chapter Markdown, specs, plans, research, answer files, other reports, bundles, network bodies or private state. No external links were followed.

This is a teaching-completeness assessment for the case, not a claim that Toolshare works or that the port passes visual, responsive, contrast, console or export tests.

## Supplied case, unchanged

Toolshare is a neighborhood tool-lending web app. Members reserve tools and volunteers record pickup and return. One maintainer built it; a second volunteer should be able to run it locally, understand the system boundary, and support a release without private instructions. A change replaces direct reminder-email sending with a durable queue after provider timeouts caused uncertain delivery. The old architectural decision to send directly remains in the repository. The same change adds REMINDER_QUEUE_URL, changes a documented retry option from 3 attempts to 5, and adds a new reminder-status response field. Toolshare wants the smallest useful documentation set and must not publish member contact details or real credentials. No framework, actual commands, URL, credentials, tests, deployment platform or measured incident outcomes are supplied.

## Navigation and observed teaching

I used the 12 visible stage tabs and their nested controls. The active hash changed to the corresponding panel. Accessibility snapshots captured the rendered public text; the observations below are the content I actually opened.

| Panel / hash | Controls opened or exercised | Observed teaching and result |
| --- | --- | --- |
| Choose a document / `#choose` | All four reader-need tabs; README, architecture, decision, conventions, troubleshooting, changelog and release-note disclosures | Tutorial teaches a skill; how-to completes a known task; reference gives exact names, types, allowed values and absence behavior; explanation gives concepts or reasons. Start with the smallest useful set. Diátaxis does not require four folders. Troubleshooting needs symptoms, checks, likely causes and a safe next action. Release notes address audience impact and actions; changelog is curated by version. |
| Verify the README / `#readme` | README outline; Fresh-clone check | Outline names purpose, prerequisites/versions, access and safe configuration source, clone/install/start commands, expected result, boundaries/dependencies, ADR links, release/rollback permissions and compatibility, logs/health and help. Try a fresh clone without private instructions; record revision, prerequisites, configuration source, commands and expected result. First unresolved step becomes a fix. A listed command is not evidence of a run. |
| Replace a decision / `#decisions` | ADR 004, ADR 005, Blank template, Format and status | Sequential `docs/adr/NNN-title.md`, no number reuse. Context, Decision, Reasoning, Consequences, Alternatives and date. Old example retains original Accepted status and reasoning, has replacement filename and Read ADR 005 control, then an appended dated Current status: Superseded notice. New example names Supersedes and offers Read ADR 004. Intro explicitly requires linking both records and updating an existing decision index. Proposed/Rejected/Accepted/Superseded are explained. |
| State exact facts / `#reference` | Both configuration and response-field tabs | A current architecture view names scope, components, relationships, owner and review trigger. The figure explicitly limits its illustrative Workshop scope and disclaims an implied email/payment dependency. Configuration and response examples each show shape, default/absence, authoritative source and owner/trigger. Text requires version and source, distinguishes absent/null/empty and says generation does not prove input correctness. |
| Explain the exception / `#comments` | All four practice cases, selecting an answer and Check answer for each | Four correct decisions displayed. Cases cover an outside metadata constraint, deliberate display/lookup distinction, tricky interval semantics and an exposed limit. Feedback avoids inventing outages, unrelated date semantics or measured application properties. Implementation comments explain intent/constraints unrecoverable from code; module documentation can explain purpose/use/behavior; names can replace unclear comments. |
| Trace the change / `#changes` | All six change tabs; Does configuration enforce itself?; What does automation establish? | Configuration maps validator to reference, `.env.example`, setup and missing/invalid-value checks. Response maps schema/serializer to reference/example and generation/diff/omission checks. Option changes map implementation and behavioral test to existing reference/how-to; find old values and check behavior. Boundary changes map current system/ADR to view/ADR/runbook and relationship/replacement checks. Procedure changes map real commands/access/environment to README/linked procedure and an observed safe run. Confirmed fixes/releases map diagnosed behavior/release record to troubleshooting/history as needed, with supported impact only. Owners and triggers are explicit; solo owner is the maintainer. `.env.example` lists configuration; only an actually invoked validator enforces it. Safe placeholders, never credentials. Types, tests and generation establish different things. |
| Keep history usable / `#history` | Historical record; Current instructions; Commit context | Preserve historical reasons with replacement/version context. Correct, redirect or retire obsolete current procedures where readers expect them. Avoid duplicate inventories nobody maintains. Commit body preserves a reason/constraint/rejected alternative when useful; subject can suffice for small changes. |
| Check the evidence / `#ai` | All three practice cases and answers; Ground and review the draft; Record the limits of validation | Three correct decisions displayed. Read is comparison with identified source, Compile is stated compiler/type checks, Execute names command/revision/environment/observed result. Isolated execution does not establish production recovery. Assistant receives source/version and labels missing facts. Named reviewer compares draft with diff, contract, code, verified procedure or approved notes. Remove credentials, contacts and private payloads; permissions/defaults/provider behavior/incident outcomes/release promises require traceable sources. |
| Plan your change / `#your-change` | Filled all four text fields | Prompts record scope, reader/task, affected paths/actions, source/revision. No example answers were inserted. With four evidence fields already filled, UI displayed 8 of 8 fields recorded, alongside “Recording fields and checks does not verify documentation. Documentation remains continuous work.” |
| Plan the check / `#your-evidence` | Filled all four text fields | Prompts require check/expected result/safe environment, actual observed evidence and limits, owner/reviewer, review trigger/follow-up. I entered a Toolshare plan and explicitly recorded that no Toolshare source or execution evidence exists. |
| Review this change / `#checklist` | Read per-change and periodic check groups; opened If you are not solo | Selections are self-recorded, not certification. Per-change checks include authoritative facts, replacements, matching current behavior, actual validation, safe examples and evidence scope. Periodic checks include fresh maintainer setup, owners/triggers and historical/current document treatment. Non-solo guidance makes first unresolved setup step the fix list; reviews documentation in the change; names area ownership, contributor expectations and operational handover links. I did not mark unverified Toolshare checks complete. |
| Spot the trap / `#traps` | All eight disclosures | Reinforces continuous work, usable setup/reference beyond comment advice, smallest artifact set, preservation vs retiring current instructions, generation/input checks, replacing template claims, synthetic data and evidence behind operational claims. |

Some tool-operation errors occurred, not app failures: a snapshot selector matched both outer and inner tabpanels; a ref was stale after a scoped snapshot. Retrying with the outer panel selector/fresh ref worked. During cleanup I initially closed a page with the clear-record confirmation still pending, then reopened, accepted the public confirmation, observed 0 of 8 fields and disabled copy/clear controls, and closed the page. Final MCP result: No open tabs. No lingering Toolshare planning answers were left in the record. Copy/export behavior and checklist persistence were not tested.

## Missing project facts, distinct from teaching gaps

These facts are absent from the case. The port supplies categories, sources and checks for obtaining them; filling them now would be guessing.

- Repository/revision, framework, supported tool versions, actual clone/install/start commands, local URL, first useful check, fixtures and safe local setup.
- Queue implementation/provider, URL format/protocol, required/default/unset/invalid behavior, access route, delivery and retry semantics, component/process boundary and operational procedures.
- Retry option's actual name, type, range, where it is configured, whether 5 is a default or an explicit setting, whether “attempts” includes the initial attempt, timing and failure behavior. The case establishes the documented change from 3 to 5; it does not establish all of these semantics.
- New response field's exact identifier/type/allowed values, applicable version, null/omission/empty behavior, consumer compatibility and authoritative contract/serializer.
- Old ADR's number/path/date/text, next unused number, existing index path and decision date. The case establishes adoption of the queue change, but not its historical metadata.
- Named owners/reviewers, release platform/permissions, release/rollback/health/log/help routes and compatibility constraints.
- Tests, generation tooling, actual checks run, execution results and measured incident outcomes. No claim of improved delivery, eliminated timeouts, successful recovery or validated production behavior can be made.

## Actual artifact drafts

These are drafts, not verified application instructions. Bracketed fields are intentional unresolved facts. Proposed paths below are drafting destinations unless the case establishes an existing artifact; they do not assert an inspected repository layout. Keep reference facts within an existing suitable page where possible, and link a longer procedure only if a short section hides important conditions. This avoids manufacturing nine documents from a template menu.

### 1. README.md

```markdown
# Toolshare

Toolshare is a neighborhood tool-lending web app. Members reserve tools;
volunteers record pickup and return. This guide is for a second volunteer
running the app locally and supporting a release without private instructions.

## Running locally

Applies to: [actual revision/version].

Prerequisites: [supported tools and versions].
Access: [how a volunteer obtains repository and safe development access].
Configuration: use [.env.example](.env.example) as a list of names, then obtain
[safe local configuration through the approved route]. Do not copy production
credentials or member contact details into examples, fixtures or this guide.
See [configuration reference path] for exact accepted and missing-value behavior.

1. Clone: [actual clone command].
2. Install: [actual install command].
3. Configure: [actual safe local configuration steps, including queue setup].
4. Start: [actual command(s), including any separately required queue process].
5. Open/check: [local address and first useful check with synthetic data].

Expected result: [observable result and any required reminder/queue check].
If a step cannot be followed without coaching, record the first unresolved step
with the revision and environment and fix the instructions.

Verification record: [revision, prerequisites, configuration source, commands,
observed result and remaining limits]. Status: not yet run from a fresh clone.

## Architecture

Scope: member reservations, volunteer pickup/return records and reminder delivery.
Members reserve tools through Toolshare; volunteers record pickup and return.
Reminder-email sending now uses a durable queue in place of direct sending.

Current relationships to confirm against the implementation:
Toolshare --[actual enqueue relationship]--> durable reminder queue
[actual queue consumer/process] --[actual send relationship]--> email provider

[Add the actual storage boundary and other dependencies from the current system;
do not infer the Workshop example's storage or process design.]

Owner: [maintainer]. Review when a boundary or dependency changes.
Decision: [durable reminder queue ADR path].
Decision log: [existing index, if present].

## Supporting a release

- Release: [procedure link, required access and compatibility limits].
- Rollback: [procedure link, permissions and compatibility/recovery constraints].
- Logs and health: [where to look and the check to perform].
- Reminder troubleshooting/handover: [applicable operational procedure].
- Help: [responsible role and approved support route].

The reminder change adds REMINDER_QUEUE_URL, changes the documented retry option
from 3 attempts to 5, and adds [actual reminder-status response field]. Consult
[current reference path] for the applicable version and exact behavior.
No measured delivery improvement or production recovery is claimed here.
```

Basis: README outline and Fresh-clone check; current-view source/owner/trigger in State exact facts; safety/evidence limits in Check the evidence. This is a useful starting guide with its blockers visible; it cannot yet be a runnable guide because actual commands/access/results were withheld.

### 2. Replacement decision record and discoverable supersession

New `docs/adr/[next-unused-number]-durable-reminder-queue.md`:

```markdown
# ADR [new number]: use a durable queue for reminder emails

Date: [actual decision date]
Status: Accepted
Supersedes: [ADR old number](./[actual-old-record-filename])
Applies to: [revision/version]

## Context

Toolshare sends reminder emails for its tool-lending service. Provider timeouts
made delivery uncertain when reminders were sent directly. The repository retains
the earlier decision to send directly, linked above.

## Decision

Replace direct reminder-email sending with a durable queue.
[Identify the adopted queue and the actual enqueue/consumer/provider boundaries.]

## Reasoning

The change addresses the uncertainty encountered during direct provider calls.
[Add the approved reasoning for this queue's behavior and trade-offs, supported
by the decision discussion and implementation at the recorded revision.]
This record does not claim that every timeout or delivery uncertainty is solved.

## Consequences

The documentation must now cover REMINDER_QUEUE_URL and the queue's current
boundary and operational procedure. The retry reference changes from 3 attempts
to 5; the response reference gains [actual reminder-status field].
[Record the actual operating costs, delivery guarantees/limits, failure handling,
compatibility obligations and checks. These are not supplied by the case.]
No measured incident outcome or successful release is asserted.

## Alternatives

Continue direct sending: replaced after provider timeouts caused uncertain delivery.
[Record any other options actually considered and the reasons they were declined;
do not manufacture a historical alternatives discussion.]
```

Append to the existing direct-send ADR, retaining its original date, status, context, reasoning and consequences:

```markdown
## Supersession notice (appended)

[actual supersession date] — Current status: Superseded.

Replaced by [ADR new number: use a durable queue for reminder emails](./[actual-new-record-filename]). The original decision and its reasoning above
are retained as historical context. Consult the replacement for the current choice.
```

In the existing decision index, if one exists:

```markdown
| [old number] | [direct-send record link] | Superseded by [new record link] |
| [new number] | [durable queue record link] | Accepted; supersedes [old record link] |
```

Use real unused sequential numbers and valid relative links after inspecting that project. The new record points back, the old record points forward, and the index exposes the current choice. This is not deletion or silent rewriting. Basis: Replace a decision, including the old/new examples, blank template and Format and status.

### 3. Safe configuration example and exact-fact reference excerpt

Draft `.env.example` entry:

```dotenv
# Documentation placeholder only; replace using the approved safe local setup.
# Exact URL format and unset/invalid behavior: [configuration reference path].
# No real credentials or member contact details belong in this file.
REMINDER_QUEUE_URL=REPLACE_WITH_SAFE_LOCAL_QUEUE_URL
```

The value is deliberately not claimed to be a valid or runnable queue URL. A usable synthetic URL requires Toolshare's actual format and local queue setup; the scenario withholds both. No invented framework, provider or credential syntax is needed to show the setting name safely.

Draft excerpt for the existing suitable reference page:

| Fact | Draft reference entry | Source / version to resolve | Owner / trigger |
| --- | --- | --- | --- |
| `REMINDER_QUEUE_URL` | Purpose: location used by the durable reminder queue configuration. Shape/protocol: [actual accepted form]. Required/default: [actual rule]. Unset, null, empty, invalid: [actual distinct behavior]. Safe example: [synthetic value valid for the local setup]. | [Invoked startup configuration validator and revision]; verify invocation rather than claiming `.env.example` enforces anything. | [Maintainer] / validator or queue setup change. |
| [actual retry option name] | Documented count changes from 3 attempts to 5 at [version]. Type/range/default: [actual contract]. Attempt-count meaning, timing and exhaustion behavior: [actual behavior]. Do not label 5 the default until confirmed. | [Implementation and behavioral test at revision]. | [Maintainer] / option change. |
| [actual reminder-status response field] | Type and allowed values: [contract]. Present/omitted/null/empty conditions: [actual serializer behavior]. Applicable response/version: [actual scope]. | [Response schema and serializer at revision]. | [Contract owner] / response change. |

Synthetic response specimen to complete from the contract, not an asserted API payload:

```text
{
  "[actual reminder-status field name]": "[synthetic value allowed by its actual type]"
}
[Add the contract's actual omission/null variants; do not assume optionality.]
```

Basis: State exact facts and Trace the change. The Workshop `waitlistPosition` omission rule and integer range/default belong to its example; none were imported into Toolshare. If Toolshare has a generator, update its authoritative input, run it and inspect the expected diff. The port's generation example is not evidence that Toolshare has one.

### 4. Rationale comment

At the actual direct-send-to-queue boundary, adapt to Toolshare's comment syntax:

```text
// Queue reminder emails instead of sending them directly because provider
// timeouts left delivery uncertain. See [replacement ADR link or identifier]
// for the decision and its operational limits.
```

This explains why the boundary exists using the supplied facts. It does not claim exactly-once delivery, identify a provider, diagnose from attempt counts, or promise a measured recovery. The actual code location and comment syntax remain unknown. Basis: Explain the exception, especially outside constraints and the warning against inventing incidents, plus the ADR cross-reference teaching.

### 5. Documentation change and check plan

| Change / action | Smallest useful documentation update | Source and expected check | Owner / trigger |
| --- | --- | --- | --- |
| Fresh-clone handover | Update README sections above; link a longer procedure if conditions need it. | [Revision/prerequisites/access/configuration/commands]. Second volunteer follows without private coaching in a safe environment. Record expected and observed useful result; first unresolved step becomes the fix list. | [Maintainer]; reviewer [second volunteer] / setup change and periodic onboarding check. |
| Durable queue boundary | Update README architecture view, create replacement ADR, append notice to old record, update existing index; update affected operational procedure. | Current system/diff/decision. Trace actual relationships and operational limits. Open old record and follow replacement; follow link back; inspect index and current instructions. | [Area owner, initially maintainer] / dependency/boundary change. |
| New queue setting | Add safe `.env.example` entry; update configuration reference and setup. | Invoked validator. Compare exact name/form/required/default/unset/invalid behavior, including tests for missing and invalid values where applicable. Confirm the documented path supplies usable safe configuration. | [Maintainer] / validator/setup change. |
| Retry count 3 to 5 | Update existing reference and relevant how-to; remove stale current instructions. | Implementation and behavioral test at revision. Find old values in affected current docs; check actual behavior rather than only replacement strings. Preserve historical 3 where properly versioned. | [Maintainer] / option change. |
| New response field | Update existing response reference and synthetic example; regenerate if the project actually has a generator. | Schema and serializer at revision. Verify exact name/type/allowed values, presence/absence semantics, and compatibility. Inspect expected generated diff if applicable. | [Contract owner, initially maintainer] / contract or serializer change. |
| Release/known timeout issue | Add one curated version entry and audience actions if needed; revise troubleshooting only with supported checks/workarounds. Link actual release/rollback/log/health/handover procedures. | Diagnosed behavior and release record. Follow safe procedure and record result. Publish only supported impact; no assertion that queue or five attempts solved the incident. | [Maintainer] / confirmed fix or release. |
| Publication review | Review all affected drafts in this change; keep a reason in commit context if it matters later. | Named reviewer compares with relevant source/diff/version. Replace all template infrastructure/test claims; review for credentials, member contacts and private payloads. | [Named reviewer] / this change. |

Evidence record to fill for each claimed check:

```text
Claim: [precise statement the evidence supports]
Source and revision: [identified source/revision]
Review level: [Read / Compile / Execute, as actually supported]
Check/command: [actual check or exact command]
Safe environment and fixture: [actual environment; synthetic data]
Expected result: [before running]
Observed result: [what happened, including failure or unresolved step]
Owner / reviewer / date: [actual people and date]
Limits and follow-up: [what was not established and the next check]
```

Current observed Toolshare evidence: none. These are proposed checks, not completed runs. Source review alone cannot be relabeled compilation; compilation cannot establish a successful procedure; an isolated run cannot establish production recovery. The task plan remains continuous work even with eight populated fields.

Deferred deliberately: no separate tutorial, full contributor guide, duplicate inventory, invented provider runbook, extra architecture decision, unsupported diagnosis or measured release promise. Add a document only when its reader/task warrants it. Reference/release edits can live in existing appropriate artifacts. Release and recovery procedure details need actual project facts and the linked operational stages, not guessed commands.

## Five supplied questions and answers

### 1. A second maintainer cannot run the app from a fresh clone. Where do I find what the setup guide must include and how to verify it?

Open **02 Verify the README** (`#readme`), read the **README.md outline**, then expand **Fresh-clone check**. It explicitly lists prerequisites/versions, access and safe configuration source, clone/install/start commands, expected result and first useful check, architecture/ADRs, release/rollback/access/compatibility, logs/health and help. Have the second volunteer try a fresh clone without private instructions; record revision, prerequisites, configuration source, commands and expected result, and fix the first unresolved step. A listed command is not proof it ran. **11 Review this change → If you are not solo** repeats the uncoached setup check. Toolshare's actual commands cannot be supplied from this scenario.

### 2. We replaced an earlier architecture decision. What should I write now, and how does a reader discover that the old decision no longer applies?

Open **03 Replace a decision** (`#decisions`), then **ADR 004**, **ADR 005**, **Blank template** and **Format and status**. Write the next unused sequential ADR with date/status, Context, Decision, Reasoning, Consequences and Alternatives. New record names and links the decision it supersedes. Preserve the old accepted reasons and append a dated notice of current Superseded status linked to the replacement. The examples show both direction controls and an old-record replacement filename; the visible introduction also says to update an existing decision index. That is enough to draft both ends and index action; actual IDs/dates remain placeholders.

### 3. A user needs the exact allowed values and defaults for a retry option. Should that live in a tutorial, reference page or explanation?

**Reference.** **01 Choose a document → Look up facts** explicitly describes exact names/types/allowed values/absence behavior. **04 State exact facts** shows shape/default/source/owner and requires applicable version and authoritative source. **06 Trace the change → Default or allowed value** maps changed options to the existing reference and relevant how-to, with implementation/behavioral-test evidence and a search for old values. A tutorial can teach a first exercise; explanation can give the reason; neither substitutes for the exact lookup facts. The case gives a 3-to-5 count change, not the complete allowable range or default semantics.

### 4. This change adds configuration and a response field. Which documents need updates, who owns them, and what checks detect drift?

Open **06 Trace the change → Configuration**: configuration reference, `.env.example` and setup; startup validator/unset/invalid behavior; maintainer owns it, validator change triggers review. **Response contract**: reference and example response; schema/serializer and generation/expected-diff/absence check; contract owner, response change trigger. Apply generation only if the actual project has it, and actual contract-defined absence rules rather than copying Workshop omission. **Default or allowed value** covers the retry reference/how-to and behavior check. **Boundary or dependency** adds the architecture view, replacement ADR and affected runbook for the queue. **Does configuration enforce itself?** says listing a variable does not enforce it; confirm the app invokes validation. **What does automation establish?** says tests establish only their asserted behavior and generation follows input. **11 If you are not solo** assigns area owners/triggers and review in the affecting change. For a lone maintainer the visible instruction makes that maintainer the owner; with a second volunteer, assign actual named reviewers. The concrete plan above applies these rules.

### 5. An AI assistant drafted documentation claiming a fix was validated. What evidence must I check before publishing it?

Open **08 Check the evidence** (`#ai`), complete **Which evidence do you actually have?**, then expand **Ground and review the draft** and **Record the limits of validation**. Identify source and version and a named reviewer. Compare against the relevant diff, contract, code, verified procedure or approved notes. Check operational claims such as defaults, provider behavior, permissions and incident outcomes against traceable sources. Record the actual command/check, revision, environment and observed result for execution. Distinguish Read, Compile and Execute; none can be promoted to a stronger claim by wording. A successful isolated example does not establish production recovery. Review synthetic examples for credentials, contacts and private payloads and replace template infrastructure/test claims. For Toolshare there is no supplied validation evidence, so the draft must say unverified rather than claim a confirmed fix.

## Findings and assessment limits

Finding IDs: none. No Critical, Important or Minor completeness gap was established from the observed teaching for this case. The actual drafts above are the attempted outcome, not an assertion that the port is complete because its prose looks plausible.

Every unresolved artifact field can be tied to a deliberately withheld Toolshare fact and to visible teaching that names the required source/check. In particular, an actual URL, accepted retry values, response enums, queue guarantees and production recovery evidence are not missing teaching merely because the Workshop examples differ. I did not supply them from expertise and call the port complete.

Successful teaching: a usable README outline and uncoached check; complete replacement-ADR convention including discovery from the old record; exact-reference choice and absence semantics; configuration/response/option/boundary trace with owners/checks; useful rationale comments without incident invention; safe examples and bounded validation claims; plans that preserve unknown facts and do not certify themselves.

Remaining assessment limits: no external reading, application source inspection or Toolshare implementation existed in the permitted inputs. I did not verify actual copied Markdown output, pixel layout, theme contrast, all keyboard behaviors, or downstream linked stages. Manual public planning fields and the clear-record confirmation were exercised; no code, build or repository change other than this report was performed. The owned browser page is closed and the shared profile is released.
