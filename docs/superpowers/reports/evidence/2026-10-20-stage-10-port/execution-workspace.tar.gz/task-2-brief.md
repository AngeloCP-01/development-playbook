### Task 2: Preserve record and practice state across panel changes

**Files:** Create `DocumentationSession.tsx`, `DocumentationSession.test.tsx`.

**Interfaces:** Consumes Task 1. Produces `DocumentationSession({ children })`,
`useDocumentationSession()`, `PracticeRun`, `EMPTY_PRACTICE` and context methods
`setField(id, text)`, `toggleCheck(id)`, `clear()`, `setPractice(id, update)`;
context exposes `record`, `warning`, `clearFailed`, `practices`. A provider wraps
the Stepper once; never mount a provider inside each panel. Tests may mount a
second independent subscriber solely to prove the shared hook notification contract.

- [ ] **Step 1: Write `DocumentationSession.test.tsx`.**

```tsx
import { act, fireEvent, render, screen } from '@testing-library/react'
import { renderToString } from 'react-dom/server'
import { hydrateRoot } from 'react-dom/client'
import { useState } from 'react'
import { afterEach, beforeEach, expect, test, vi } from 'vitest'
import { DocumentationSession, EMPTY_PRACTICE, useDocumentationSession } from './DocumentationSession'
import { EMPTY_RECORD, RECORD_KEY } from './record'

beforeEach(() => window.localStorage.clear())
afterEach(() => vi.restoreAllMocks())
function Probe() {
  const s = useDocumentationSession()
  return <div>
    <input aria-label="change" value={s.record.change} onChange={e => s.setField('change', e.target.value)} />
    <input aria-label="evidence" value={s.record.evidence} onChange={e => s.setField('evidence', e.target.value)} />
    <output aria-label="record">{JSON.stringify(s.record)}</output><p role="status">{s.warning}</p>
    <button onClick={() => s.toggleCheck('history')}>Tick history</button>
    <button onClick={s.clear}>Clear</button>
    <button onClick={() => s.setPractice('comments', old => ({ ...old, choices: { ...old.choices, external: 'keep' } }))}>Answer</button>
    <output aria-label="practice">{JSON.stringify(s.practices.comments ?? EMPTY_PRACTICE)}</output>
  </div>
}
function Harness() {
  const [panel, setPanel] = useState(0)
  return <DocumentationSession><button onClick={() => setPanel(v => v + 1)}>Switch panel</button><Probe key={panel} /></DocumentationSession>
}
const edit = (label: string, value: string) => fireEvent.change(screen.getByLabelText(label), { target: { value } })

test('fields checks and practice survive child remounts while only the record survives a full reload', () => {
  let view = render(<Harness />)
  edit('change', 'Changed field')
  fireEvent.click(screen.getByText('Tick history'))
  fireEvent.click(screen.getByText('Answer'))
  fireEvent.click(screen.getByText('Switch panel'))
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('Changed field')
  expect(screen.getByLabelText('practice').textContent).toContain('keep')
  expect(screen.getByLabelText('record').textContent).toContain('history')
  view.unmount(); view = render(<Harness />)
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('Changed field')
  expect(screen.getByLabelText('practice').textContent).not.toContain('keep')
  expect(Object.keys(JSON.parse(window.localStorage.getItem(RECORD_KEY)!))).not.toContain('practices')
  view.unmount()
})

test('malformed and partial storage normalize before the first edit without discarding valid other-view data', () => {
  for (const raw of ['{bad', 'null', '[]', '{"evidence":"Keep this","change":3,"checked":["history","unknown"],"secret":"drop"}']) {
    window.localStorage.setItem(RECORD_KEY, raw)
    const view = render(<Harness />)
    edit('change', 'New change')
    const saved = JSON.parse(window.localStorage.getItem(RECORD_KEY)!)
    expect(saved.change).toBe('New change'); expect(saved.secret).toBeUndefined()
    if (raw.includes('Keep this')) expect(saved.evidence).toBe('Keep this')
    view.unmount()
  }
})

test('failed reads announce the problem and keep subsequent edits across panel remounts', () => {
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new Error('denied') })
  render(<Harness />)
  expect(screen.getByRole('status').textContent).toContain('Saving is unavailable')
  edit('change', 'Unsaved'); fireEvent.click(screen.getByText('Switch panel')); edit('evidence', 'Observed locally')
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('Unsaved')
  expect((screen.getByLabelText('evidence') as HTMLInputElement).value).toBe('Observed locally')
})

test('a later failed write retains the whole draft ahead of external storage updates', () => {
  render(<Harness />); edit('change', 'Saved first')
  const denied = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('quota') })
  edit('evidence', 'Unsaved observation')
  fireEvent.click(screen.getByText('Switch panel'))
  expect((screen.getByLabelText('evidence') as HTMLInputElement).value).toBe('Unsaved observation')
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('Saved first')
  denied.mockRestore()
  act(() => { window.localStorage.setItem(RECORD_KEY, JSON.stringify({ ...EMPTY_RECORD, change: 'Other tab' })); window.dispatchEvent(new StorageEvent('storage', { key: RECORD_KEY })) })
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('Saved first')
  edit('change', 'Retry saved')
  expect(JSON.parse(window.localStorage.getItem(RECORD_KEY)!).evidence).toBe('Unsaved observation')
  expect(screen.getByRole('status').textContent).toBe('')
})

test('a successful same-tab write notifies another mounted subscriber of the same key', () => {
  render(<><DocumentationSession><Probe /></DocumentationSession><DocumentationSession><Probe /></DocumentationSession></>)
  const fields = screen.getAllByLabelText('change') as HTMLInputElement[]
  fireEvent.change(fields[0], { target: { value: 'Same-tab update' } })
  expect(fields.map(field => field.value)).toEqual(['Same-tab update', 'Same-tab update'])
})

test('successful storage events refresh other-view data and the next edit preserves it', () => {
  render(<Harness />)
  act(() => { window.localStorage.setItem(RECORD_KEY, JSON.stringify({ ...EMPTY_RECORD, evidence: 'Other tab' })); window.dispatchEvent(new StorageEvent('storage', { key: RECORD_KEY })) })
  expect((screen.getByLabelText('evidence') as HTMLInputElement).value).toBe('Other tab')
  edit('change', 'This tab')
  expect(JSON.parse(window.localStorage.getItem(RECORD_KEY)!).evidence).toBe('Other tab')
})

test('clear cancellation preserves everything and confirmed clear removes the complete saved record without resetting practice', () => {
  render(<Harness />); edit('change', 'One'); edit('evidence', 'Two')
  fireEvent.click(screen.getByText('Tick history')); fireEvent.click(screen.getByText('Answer'))
  const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false)
  fireEvent.click(screen.getByText('Clear')); expect(window.localStorage.getItem(RECORD_KEY)).not.toBeNull()
  confirm.mockReturnValue(true); fireEvent.click(screen.getByText('Clear'))
  expect(confirm).toHaveBeenLastCalledWith('Clear the whole documentation record, including both views and all checklist selections?')
  expect(window.localStorage.getItem(RECORD_KEY)).toBeNull()
  expect(JSON.parse(screen.getByLabelText('record').textContent!)).toEqual(EMPTY_RECORD)
  expect(screen.getByLabelText('practice').textContent).toContain('keep')
})

test('a failed clear empties the mounted draft while warning that the saved copy can return', () => {
  render(<Harness />); edit('change', 'Saved')
  vi.spyOn(window, 'confirm').mockReturnValue(true)
  vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => { throw new Error('denied') })
  fireEvent.click(screen.getByText('Clear')); fireEvent.click(screen.getByText('Switch panel'))
  expect((screen.getByLabelText('change') as HTMLInputElement).value).toBe('')
  expect(window.localStorage.getItem(RECORD_KEY)).toContain('Saved')
  expect(screen.getByRole('status').textContent).toContain('could return after reload')
})

test('server-empty markup hydrates stored data without a recovery error', async () => {
  window.localStorage.setItem(RECORD_KEY, JSON.stringify({ ...EMPTY_RECORD, change: 'Stored' }))
  const node = document.createElement('div'); document.body.append(node)
  node.innerHTML = renderToString(<DocumentationSession><Probe /></DocumentationSession>)
  expect((node.querySelector('input') as HTMLInputElement).value).toBe('')
  const errors: unknown[] = []
  let root!: ReturnType<typeof hydrateRoot>
  await act(async () => { root = hydrateRoot(node, <DocumentationSession><Probe /></DocumentationSession>, { onRecoverableError: error => errors.push(error) }) })
  expect((node.querySelector('input') as HTMLInputElement).value).toBe('Stored')
  expect(errors).toEqual([])
  await act(async () => root.unmount()); node.remove()
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/DocumentationSession.test.tsx`; capture RED.** Missing module first; then ensure the mounted-draft test fails if the provider merely exposes the shared hook.
- [ ] **Step 3: Add `DocumentationSession.tsx`.**

```tsx
'use client'
import { createContext, useContext, useState, useSyncExternalStore, type ReactNode } from 'react'
import { useLocalStorage } from '@/lib/useLocalStorage'
import { EMPTY_RECORD, normalizeRecord, RECORD_KEY, type CheckId, type DocumentationRecord, type FieldId } from './record'

export type PracticeRun = { index: number; drafts: Record<string, string>; choices: Record<string, string> }
export const EMPTY_PRACTICE: PracticeRun = { index: 0, drafts: {}, choices: {} }
type Session = {
  record: DocumentationRecord; warning: string; clearFailed: boolean
  setField: (id: FieldId, text: string) => void; toggleCheck: (id: CheckId) => void; clear: () => void
  practices: Record<string, PracticeRun>; setPractice: (id: string, update: (old: PracticeRun) => PracticeRun) => void
}
const Context = createContext<Session | null>(null)
const PROBE_EVENT = 'documentation:storage-check'
function subscribeProbe(listener: () => void) {
  window.addEventListener('storage', listener); window.addEventListener(PROBE_EVENT, listener)
  return () => { window.removeEventListener('storage', listener); window.removeEventListener(PROBE_EVENT, listener) }
}
function readable() { try { window.localStorage.getItem(RECORD_KEY); return true } catch { return false } }
const serverReadable = () => true

export function DocumentationSession({ children }: { children: ReactNode }) {
  const { value, setValue, reset } = useLocalStorage<unknown>(RECORD_KEY, EMPTY_RECORD)
  const canRead = useSyncExternalStore(subscribeProbe, readable, serverReadable)
  const [draft, setDraft] = useState<DocumentationRecord | null>(null)
  const [failure, setFailure] = useState<'save' | 'clear' | null>(null)
  const [practices, setPractices] = useState<Record<string, PracticeRun>>({})
  const record = draft ?? normalizeRecord(value)
  const warning = failure === 'clear'
    ? 'The visible record is cleared, but the saved copy could return after reload. Clearing storage is unavailable; retry or remove it in browser settings.'
    : failure === 'save' || !canRead
      ? 'Saving is unavailable. This draft stays editable across these panels; export it before leaving or reloading.' : ''
  function update(change: (old: DocumentationRecord) => DocumentationRecord) {
    let next = change(record)
    setValue((previous: unknown) => { next = change(draft ?? normalizeRecord(previous)); return next })
    let saved = false
    try { saved = window.localStorage.getItem(RECORD_KEY) === JSON.stringify(next) } catch { /* keep stage-session draft */ }
    setDraft(saved ? null : next); setFailure(saved ? null : 'save')
    window.dispatchEvent(new Event(PROBE_EVENT))
  }
  function clear() {
    if (!window.confirm('Clear the whole documentation record, including both views and all checklist selections?')) return
    reset()
    let cleared = false
    try { cleared = window.localStorage.getItem(RECORD_KEY) === null } catch { /* report uncertain removal */ }
    setDraft(cleared ? null : normalizeRecord(null)); setFailure(cleared ? null : 'clear')
    window.dispatchEvent(new Event(PROBE_EVENT))
  }
  return <Context.Provider value={{
    record, warning, clearFailed: failure === 'clear', clear,
    setField: (id, text) => update(old => ({ ...old, [id]: text })),
    toggleCheck: id => update(old => ({ ...old, checked: old.checked.includes(id) ? old.checked.filter(c => c !== id) : [...old.checked, id] })),
    practices,
    setPractice: (id, change) => setPractices(old => ({ ...old, [id]: change(old[id] ?? EMPTY_PRACTICE) })),
  }}>{children}</Context.Provider>
}
export function useDocumentationSession(): Session {
  const context = useContext(Context)
  if (!context) throw new Error('Documentation controls require DocumentationSession')
  return context
}
```

- [ ] **Step 4: Run focused GREEN, lint and typecheck.** Investigate actual lint/compiler diagnostics; do not weaken the hydration or draft assertions. Record any source correction to this plan as PLAN-AUTHORED when appropriate.
- [ ] **Step 5: Teeth check.** Replace `setDraft(saved ? null : next)` with `setDraft(saved || canRead ? null : next)`; the later-failed-write test must fail because the observation disappears. Restore, rerun the full Task 1/2 suite and record exact impact; no other behavior change is retained.
- [ ] **Step 6: Independent review and commit** `feat(documentation): retain change drafts across panels`. Deferred: actual forms and exercise UI.

