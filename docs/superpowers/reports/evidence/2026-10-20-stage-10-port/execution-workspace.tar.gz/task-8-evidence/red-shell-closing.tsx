export const TRAPS: { id: string; title: string; detail: string }[] = []
export function TrapsPanel() { return null }
