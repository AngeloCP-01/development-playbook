export const STEP_IDS: readonly string[] = []
export const COVERAGE: Record<string, readonly string[]> = {}
