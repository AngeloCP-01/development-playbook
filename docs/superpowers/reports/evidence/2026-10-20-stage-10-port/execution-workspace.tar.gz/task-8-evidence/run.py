import json, subprocess, sys, time
from pathlib import Path
name, *command = sys.argv[1:]
base = Path(__file__).parent
started = time.time()
with (base / (name + '.log')).open('wb') as output:
 p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
 for line in iter(p.stdout.readline, b''):
  output.write(line); output.flush(); sys.stdout.buffer.write(line); sys.stdout.flush()
 code = p.wait()
(base / (name + '.json')).write_text(json.dumps({'command':command,'exit_code':code,'seconds':time.time()-started}, indent=2)+'\n')
print('EXIT_CODE=' + str(code), flush=True)
sys.exit(code)
