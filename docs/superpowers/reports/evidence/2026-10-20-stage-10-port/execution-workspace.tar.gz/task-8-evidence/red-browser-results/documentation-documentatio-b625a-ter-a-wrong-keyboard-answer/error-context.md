# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: documentation.spec.ts >> documentation exposes replaced history and reasoning after a wrong keyboard answer
- Location: e2e/documentation.spec.ts:53:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('2026-10-20 — Current status: Superseded.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('2026-10-20 — Current status: Superseded.')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- complementary:
  - link "Playbook 18":
    - /url: /
  - button "System theme. Click to change."
  - button "Collapse index"
  - navigation "Stage index":
    - text: Before code
    - list "Before code":
      - listitem:
        - link "01 Product Discovery":
          - /url: /stages/01-product-discovery
      - listitem:
        - link "02 Product Planning":
          - /url: /stages/02-planning
      - listitem:
        - link "03 Architecture":
          - /url: /stages/03-architecture
    - text: Building
    - list "Building":
      - listitem:
        - link "04 Project Setup":
          - /url: /stages/04-project-setup
      - listitem:
        - link "05 Development":
          - /url: /stages/05-development
      - listitem:
        - link "06 Testing":
          - /url: /stages/06-testing
      - listitem:
        - link "07 Code Review":
          - /url: /stages/07-code-review
      - listitem:
        - link "08 Security Audit":
          - /url: /stages/08-security-audit
      - listitem:
        - link "09 Performance Optimization":
          - /url: /stages/09-performance-optimization
      - listitem:
        - link "10 Documentation WIP":
          - /url: /stages/10-documentation
    - text: Shipping
    - list "Shipping":
      - listitem:
        - link "11 CI/CD":
          - /url: /stages/11-ci-cd
      - listitem:
        - link "12 Staging":
          - /url: /stages/12-staging
      - listitem:
        - link "13 Production Deployment":
          - /url: /stages/13-production-deployment
      - listitem:
        - link "14 Post-Deployment Verification":
          - /url: /stages/14-post-deployment-verification
    - text: Running
    - list "Running":
      - listitem:
        - link "15 Observability":
          - /url: /stages/15-observability
      - listitem:
        - link "16 Incident Management":
          - /url: /stages/16-incident-management
      - listitem:
        - link "17 Maintenance WIP":
          - /url: /stages/17-maintenance
      - listitem:
        - link "18 Continuous Improvement WIP":
          - /url: /stages/18-continuous-improvement
  - navigation "Reference index":
    - text: Architecture
    - list "Architecture":
      - listitem:
        - link "Software Architecture Patterns":
          - /url: /reference/architecture-patterns
      - listitem:
        - link "Design Patterns":
          - /url: /reference/design-patterns
      - listitem:
        - link "API Design":
          - /url: /reference/api-design
      - listitem:
        - link "Caching":
          - /url: /reference/caching
      - listitem:
        - link "Infrastructure Scaling":
          - /url: /reference/scaling
    - text: Design Principles
    - list:
      - listitem:
        - link "SOLID Principles":
          - /url: /reference/solid-principles
      - listitem:
        - link "Clean Code":
          - /url: /reference/clean-code
    - text: Git
    - list "Git":
      - listitem:
        - link "Git Cheat Sheet":
          - /url: /reference/git-cheatsheet
      - listitem:
        - link "Git Commands":
          - /url: /reference/git-commands
      - listitem:
        - link "Git Branching & Conventions":
          - /url: /reference/git-branching
    - text: Standards
    - list "Standards":
      - listitem:
        - link "Coding Standards":
          - /url: /reference/coding-standards
      - listitem:
        - link "Software Development Life Cycle":
          - /url: /reference/sdlc
      - listitem:
        - link "Testing":
          - /url: /reference/testing
      - listitem:
        - link "Playwright":
          - /url: /reference/playwright
      - listitem:
        - link "Code Review":
          - /url: /reference/code-review
      - listitem:
        - link "Deployment Environments":
          - /url: /reference/deployment-environments
      - listitem:
        - link "AWS Deployment":
          - /url: /reference/aws-deployment
      - listitem:
        - link "Post-Deploy Verification":
          - /url: /reference/post-deploy-verification
      - listitem:
        - link "CI/CD Pipeline":
          - /url: /reference/ci-cd
      - listitem:
        - link "GitHub Actions":
          - /url: /reference/github-actions
      - listitem:
        - link "Incident Management":
          - /url: /reference/incident-management
      - listitem:
        - link "Security Audit":
          - /url: /reference/security
    - text: Languages
    - list "Languages":
      - listitem:
        - link "JavaScript WIP":
          - /url: /reference/javascript
      - listitem:
        - link "Python WIP":
          - /url: /reference/python
      - listitem:
        - link "Java WIP":
          - /url: /reference/java
      - listitem:
        - link "Spring Boot WIP":
          - /url: /reference/spring-boot
      - listitem:
        - link "Express & Node WIP":
          - /url: /reference/express
- main:
  - article:
    - text: Sheet 10 Section Building Cadence Continuous
    - heading "Documentation" [level=1]
    - paragraph: "Write down what code cannot say: why."
    - paragraph: When · Continuously, a little with every change.
    - paragraph: Sheet not drawn
    - paragraph: The markdown for this stage exists in the repo. The interactive version is still to come.
    - navigation:
      - link "11 Next sheet CI/CD":
        - /url: /stages/11-ci-cd
- alert
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { CHECKS, RECORD_KEY } from '../src/features/documentation/record'
  3  | const STAGE = '/stages/10-documentation'
  4  | 
  5  | test('documentation retains a literal change record across hashes history and reload in both themes', async ({ page }) => {
  6  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  7  |   const literal = '<script>window.__documentationExecuted=true</script>' + 'x'.repeat(600)
  8  |   for (const theme of ['light', 'dark'] as const) {
  9  |     await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  10 |     await page.evaluate(({ key, theme }) => { localStorage.removeItem(key); localStorage.setItem('playbook:theme', JSON.stringify(theme)) }, { key: RECORD_KEY, theme })
  11 |     await page.reload({ waitUntil: 'networkidle' })
  12 |     await expect(page.locator('html')).toHaveAttribute('data-theme', theme)
  13 |     await page.getByLabel('Change and scope', { exact: true }).fill(literal)
  14 |     await page.locator('#tab-your-evidence').click()
  15 |     await page.getByLabel('Observed evidence and limits', { exact: true }).fill('Not executed; source review only')
  16 |     await page.goBack(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue(literal)
  17 |     await page.goForward(); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  18 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  19 |     await page.locator('#tab-checklist').click(); await page.getByRole('checkbox', { name: CHECKS[9].text }).check()
  20 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByRole('checkbox', { name: CHECKS[9].text })).toBeChecked()
  21 |     for (const width of [320, 390, 768, 1024, 1440, 1920, 2560]) {
  22 |       await page.setViewportSize({ width, height: 900 })
  23 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true)
  24 |     }
  25 |     expect(await page.evaluate(() => Reflect.get(window, '__documentationExecuted'))).toBeUndefined()
  26 |     page.once('dialog', dialog => dialog.accept())
  27 |     await page.getByRole('button', { name: 'Clear whole record' }).click()
  28 |     expect(await page.evaluate(key => localStorage.getItem(key), RECORD_KEY)).toBeNull()
  29 |   }
  30 |   expect(errors).toEqual([])
  31 | })
  32 | 
  33 | test('documentation keeps an unsaved cross-panel draft and offers exact manual export when permissions fail', async ({ page }) => {
  34 |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  35 |   await page.addInitScript(key => {
  36 |     const read = Storage.prototype.getItem; const write = Storage.prototype.setItem
  37 |     Storage.prototype.getItem = function(name) { if (name === key) throw new DOMException('denied', 'SecurityError'); return read.call(this, name) }
  38 |     Storage.prototype.setItem = function(name, value) { if (name === key) throw new DOMException('quota', 'QuotaExceededError'); return write.call(this, name, value) }
  39 |     Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: () => Promise.reject(new Error('denied')) } })
  40 |   }, RECORD_KEY)
  41 |   await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  42 |   await page.getByLabel('Change and scope', { exact: true }).fill('Unsaved change')
  43 |   await page.locator('#tab-your-evidence').click()
  44 |   await page.getByLabel('Owner and reviewer', { exact: true }).fill('Me')
  45 |   await page.getByRole('button', { name: 'Copy as Markdown' }).click()
  46 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Unsaved change/)
  47 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Me/)
  48 |   await expect(page.getByText(/Saving is unavailable/)).toBeVisible()
  49 |   await page.locator('#tab-your-change').click(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue('Unsaved change')
  50 |   expect(errors).toEqual([])
  51 | })
  52 | 
  53 | test('documentation exposes replaced history and reasoning after a wrong keyboard answer', async ({ page }) => {
  54 |   await page.goto(`${STAGE}#decisions`, { waitUntil: 'networkidle' })
> 55 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
     |                                                                            ^ Error: expect(locator).toBeVisible() failed
  56 |   await page.getByRole('button', { name: 'Read ADR 005' }).click()
  57 |   await expect(page.getByRole('region', { name: 'docs/adr/005-generated-contract-reference.md' })).toBeVisible()
  58 |   await page.getByRole('button', { name: 'Read ADR 004' }).click()
  59 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  60 |   await page.locator('#tab-comments').click()
  61 |   const radios = page.locator('#panel-comments').getByRole('radio')
  62 |   await radios.first().focus(); await radios.first().press('Space'); await radios.first().press('ArrowDown')
  63 |   await expect(radios.nth(1)).toBeChecked()
  64 |   expect((await radios.nth(1).boundingBox())!.height).toBeGreaterThanOrEqual(44)
  65 |   await page.getByRole('button', { name: 'Check answer' }).click()
  66 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  67 |   await expect(page.getByText(/It supplies no evidence of silent truncation/)).toBeVisible()
  68 |   await page.locator('#tab-history').click(); await page.locator('#tab-comments').click()
  69 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  70 | })
  71 | 
```