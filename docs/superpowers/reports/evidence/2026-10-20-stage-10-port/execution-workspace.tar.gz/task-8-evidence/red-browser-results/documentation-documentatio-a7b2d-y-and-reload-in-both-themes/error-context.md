# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: documentation.spec.ts >> documentation retains a literal change record across hashes history and reload in both themes
- Location: e2e/documentation.spec.ts:5:5

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.fill: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByLabel('Change and scope', { exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - generic [ref=e5]:
        - link "Playbook 18" [ref=e6] [cursor=pointer]:
          - /url: /
          - generic [ref=e7]:
            - generic [ref=e8]: Playbook
            - generic [ref=e9]: "18"
        - generic [ref=e10]:
          - button "Light theme. Click to change." [ref=e12]:
            - img [ref=e13]
          - button "Collapse index" [ref=e19]:
            - img [ref=e20]
      - generic [ref=e23]:
        - navigation "Stage index" [ref=e24]:
          - generic [ref=e25]:
            - generic [ref=e26]: Before code
            - list "Before code" [ref=e27]:
              - listitem [ref=e28]:
                - link "01 Product Discovery" [ref=e29] [cursor=pointer]:
                  - /url: /stages/01-product-discovery
                  - generic [ref=e30]: "01"
                  - generic [ref=e32]: Product Discovery
              - listitem [ref=e33]:
                - link "02 Product Planning" [ref=e34] [cursor=pointer]:
                  - /url: /stages/02-planning
                  - generic [ref=e35]: "02"
                  - generic [ref=e37]: Product Planning
              - listitem [ref=e38]:
                - link "03 Architecture" [ref=e39] [cursor=pointer]:
                  - /url: /stages/03-architecture
                  - generic [ref=e40]: "03"
                  - generic [ref=e42]: Architecture
          - generic [ref=e43]:
            - generic [ref=e44]: Building
            - list "Building" [ref=e45]:
              - listitem [ref=e46]:
                - link "04 Project Setup" [ref=e47] [cursor=pointer]:
                  - /url: /stages/04-project-setup
                  - generic [ref=e48]: "04"
                  - generic [ref=e50]: Project Setup
              - listitem [ref=e51]:
                - link "05 Development" [ref=e52] [cursor=pointer]:
                  - /url: /stages/05-development
                  - generic [ref=e53]: "05"
                  - generic [ref=e55]: Development
              - listitem [ref=e56]:
                - link "06 Testing" [ref=e57] [cursor=pointer]:
                  - /url: /stages/06-testing
                  - generic [ref=e58]: "06"
                  - generic [ref=e60]: Testing
              - listitem [ref=e61]:
                - link "07 Code Review" [ref=e62] [cursor=pointer]:
                  - /url: /stages/07-code-review
                  - generic [ref=e63]: "07"
                  - generic [ref=e65]: Code Review
              - listitem [ref=e66]:
                - link "08 Security Audit" [ref=e67] [cursor=pointer]:
                  - /url: /stages/08-security-audit
                  - generic [ref=e68]: "08"
                  - generic [ref=e70]: Security Audit
              - listitem [ref=e71]:
                - link "09 Performance Optimization" [ref=e72] [cursor=pointer]:
                  - /url: /stages/09-performance-optimization
                  - generic [ref=e73]: "09"
                  - generic [ref=e75]: Performance Optimization
              - listitem [ref=e76]:
                - link "10 Documentation WIP" [ref=e77] [cursor=pointer]:
                  - /url: /stages/10-documentation
                  - generic [ref=e78]: "10"
                  - generic [ref=e79]:
                    - generic [ref=e80]: Documentation
                    - generic "Not written yet" [ref=e81]: WIP
          - generic [ref=e82]:
            - generic [ref=e83]: Shipping
            - list "Shipping" [ref=e84]:
              - listitem [ref=e85]:
                - link "11 CI/CD" [ref=e86] [cursor=pointer]:
                  - /url: /stages/11-ci-cd
                  - generic [ref=e87]: "11"
                  - generic [ref=e89]: CI/CD
              - listitem [ref=e90]:
                - link "12 Staging" [ref=e91] [cursor=pointer]:
                  - /url: /stages/12-staging
                  - generic [ref=e92]: "12"
                  - generic [ref=e94]: Staging
              - listitem [ref=e95]:
                - link "13 Production Deployment" [ref=e96] [cursor=pointer]:
                  - /url: /stages/13-production-deployment
                  - generic [ref=e97]: "13"
                  - generic [ref=e99]: Production Deployment
              - listitem [ref=e100]:
                - link "14 Post-Deployment Verification" [ref=e101] [cursor=pointer]:
                  - /url: /stages/14-post-deployment-verification
                  - generic [ref=e102]: "14"
                  - generic [ref=e104]: Post-Deployment Verification
          - generic [ref=e105]:
            - generic [ref=e106]: Running
            - list "Running" [ref=e107]:
              - listitem [ref=e108]:
                - link "15 Observability" [ref=e109] [cursor=pointer]:
                  - /url: /stages/15-observability
                  - generic [ref=e110]: "15"
                  - generic [ref=e112]: Observability
              - listitem [ref=e113]:
                - link "16 Incident Management" [ref=e114] [cursor=pointer]:
                  - /url: /stages/16-incident-management
                  - generic [ref=e115]: "16"
                  - generic [ref=e117]: Incident Management
              - listitem [ref=e118]:
                - link "17 Maintenance WIP" [ref=e119] [cursor=pointer]:
                  - /url: /stages/17-maintenance
                  - generic [ref=e120]: "17"
                  - generic [ref=e121]:
                    - generic [ref=e122]: Maintenance
                    - generic "Not written yet" [ref=e123]: WIP
              - listitem [ref=e124]:
                - link "18 Continuous Improvement WIP" [ref=e125] [cursor=pointer]:
                  - /url: /stages/18-continuous-improvement
                  - generic [ref=e126]: "18"
                  - generic [ref=e127]:
                    - generic [ref=e128]: Continuous Improvement
                    - generic "Not written yet" [ref=e129]: WIP
        - navigation "Reference index" [ref=e130]:
          - generic [ref=e131]:
            - generic [ref=e132]: Architecture
            - list "Architecture" [ref=e133]:
              - listitem [ref=e134]:
                - link "Software Architecture Patterns" [ref=e135] [cursor=pointer]:
                  - /url: /reference/architecture-patterns
                  - generic [ref=e137]: Software Architecture Patterns
              - listitem [ref=e138]:
                - link "Design Patterns" [ref=e139] [cursor=pointer]:
                  - /url: /reference/design-patterns
                  - generic [ref=e141]: Design Patterns
              - listitem [ref=e142]:
                - link "API Design" [ref=e143] [cursor=pointer]:
                  - /url: /reference/api-design
                  - generic [ref=e145]: API Design
              - listitem [ref=e146]:
                - link "Caching" [ref=e147] [cursor=pointer]:
                  - /url: /reference/caching
                  - generic [ref=e149]: Caching
              - listitem [ref=e150]:
                - link "Infrastructure Scaling" [ref=e151] [cursor=pointer]:
                  - /url: /reference/scaling
                  - generic [ref=e153]: Infrastructure Scaling
          - generic [ref=e154]:
            - generic [ref=e155]: Design Principles
            - list [ref=e156]:
              - listitem [ref=e157]:
                - link "SOLID Principles" [ref=e158] [cursor=pointer]:
                  - /url: /reference/solid-principles
                  - generic [ref=e160]: SOLID Principles
              - listitem [ref=e161]:
                - link "Clean Code" [ref=e162] [cursor=pointer]:
                  - /url: /reference/clean-code
                  - generic [ref=e164]: Clean Code
          - generic [ref=e165]:
            - generic [ref=e166]: Git
            - list "Git" [ref=e167]:
              - listitem [ref=e168]:
                - link "Git Cheat Sheet" [ref=e169] [cursor=pointer]:
                  - /url: /reference/git-cheatsheet
                  - generic [ref=e171]: Git Cheat Sheet
              - listitem [ref=e172]:
                - link "Git Commands" [ref=e173] [cursor=pointer]:
                  - /url: /reference/git-commands
                  - generic [ref=e175]: Git Commands
              - listitem [ref=e176]:
                - link "Git Branching & Conventions" [ref=e177] [cursor=pointer]:
                  - /url: /reference/git-branching
                  - generic [ref=e179]: Git Branching & Conventions
          - generic [ref=e180]:
            - generic [ref=e181]: Standards
            - list "Standards" [ref=e182]:
              - listitem [ref=e183]:
                - link "Coding Standards" [ref=e184] [cursor=pointer]:
                  - /url: /reference/coding-standards
                  - generic [ref=e186]: Coding Standards
              - listitem [ref=e187]:
                - link "Software Development Life Cycle" [ref=e188] [cursor=pointer]:
                  - /url: /reference/sdlc
                  - generic [ref=e190]: Software Development Life Cycle
              - listitem [ref=e191]:
                - link "Testing" [ref=e192] [cursor=pointer]:
                  - /url: /reference/testing
                  - generic [ref=e194]: Testing
              - listitem [ref=e195]:
                - link "Playwright" [ref=e196] [cursor=pointer]:
                  - /url: /reference/playwright
                  - generic [ref=e198]: Playwright
              - listitem [ref=e199]:
                - link "Code Review" [ref=e200] [cursor=pointer]:
                  - /url: /reference/code-review
                  - generic [ref=e202]: Code Review
              - listitem [ref=e203]:
                - link "Deployment Environments" [ref=e204] [cursor=pointer]:
                  - /url: /reference/deployment-environments
                  - generic [ref=e206]: Deployment Environments
              - listitem [ref=e207]:
                - link "AWS Deployment" [ref=e208] [cursor=pointer]:
                  - /url: /reference/aws-deployment
                  - generic [ref=e210]: AWS Deployment
              - listitem [ref=e211]:
                - link "Post-Deploy Verification" [ref=e212] [cursor=pointer]:
                  - /url: /reference/post-deploy-verification
                  - generic [ref=e214]: Post-Deploy Verification
              - listitem [ref=e215]:
                - link "CI/CD Pipeline" [ref=e216] [cursor=pointer]:
                  - /url: /reference/ci-cd
                  - generic [ref=e218]: CI/CD Pipeline
              - listitem [ref=e219]:
                - link "GitHub Actions" [ref=e220] [cursor=pointer]:
                  - /url: /reference/github-actions
                  - generic [ref=e222]: GitHub Actions
              - listitem [ref=e223]:
                - link "Incident Management" [ref=e224] [cursor=pointer]:
                  - /url: /reference/incident-management
                  - generic [ref=e226]: Incident Management
              - listitem [ref=e227]:
                - link "Security Audit" [ref=e228] [cursor=pointer]:
                  - /url: /reference/security
                  - generic [ref=e230]: Security Audit
          - generic [ref=e231]:
            - generic [ref=e232]: Languages
            - list "Languages" [ref=e233]:
              - listitem [ref=e234]:
                - link "JavaScript WIP" [ref=e235] [cursor=pointer]:
                  - /url: /reference/javascript
                  - generic [ref=e236]:
                    - generic [ref=e237]: JavaScript
                    - generic "Not gathered yet" [ref=e238]: WIP
              - listitem [ref=e239]:
                - link "Python WIP" [ref=e240] [cursor=pointer]:
                  - /url: /reference/python
                  - generic [ref=e241]:
                    - generic [ref=e242]: Python
                    - generic "Not gathered yet" [ref=e243]: WIP
              - listitem [ref=e244]:
                - link "Java WIP" [ref=e245] [cursor=pointer]:
                  - /url: /reference/java
                  - generic [ref=e246]:
                    - generic [ref=e247]: Java
                    - generic "Not gathered yet" [ref=e248]: WIP
              - listitem [ref=e249]:
                - link "Spring Boot WIP" [ref=e250] [cursor=pointer]:
                  - /url: /reference/spring-boot
                  - generic [ref=e251]:
                    - generic [ref=e252]: Spring Boot
                    - generic "Not gathered yet" [ref=e253]: WIP
              - listitem [ref=e254]:
                - link "Express & Node WIP" [ref=e255] [cursor=pointer]:
                  - /url: /reference/express
                  - generic [ref=e256]:
                    - generic [ref=e257]: Express & Node
                    - generic "Not gathered yet" [ref=e258]: WIP
    - main [ref=e260]:
      - article [ref=e261]:
        - generic [ref=e262]:
          - generic [ref=e263]:
            - generic [ref=e264]:
              - generic [ref=e265]:
                - generic [ref=e266]: Sheet
                - generic [ref=e267]: "10"
              - generic [ref=e268]:
                - generic [ref=e269]: Section
                - generic [ref=e270]: Building
              - generic [ref=e271]:
                - generic [ref=e272]: Cadence
                - generic [ref=e273]: Continuous
            - heading "Documentation" [level=1] [ref=e275]
          - paragraph [ref=e276]: "Write down what code cannot say: why."
          - paragraph [ref=e277]: When · Continuously, a little with every change.
        - generic [ref=e279]:
          - paragraph [ref=e280]: Sheet not drawn
          - paragraph [ref=e281]: The markdown for this stage exists in the repo. The interactive version is still to come.
        - navigation [ref=e282]:
          - link "11 Next sheet CI/CD" [ref=e283] [cursor=pointer]:
            - /url: /stages/11-ci-cd
            - generic [ref=e284]: "11"
            - generic [ref=e285]:
              - generic [ref=e286]: Next sheet
              - generic [ref=e287]: CI/CD
            - img [ref=e288]
  - alert [ref=e290]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { CHECKS, RECORD_KEY } from '../src/features/documentation/record'
  3  | const STAGE = '/stages/10-documentation'
  4  | 
  5  | test('documentation retains a literal change record across hashes history and reload in both themes', async ({ page }) => {
  6  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  7  |   const literal = '<script>window.__documentationExecuted=true</script>' + 'x'.repeat(600)
  8  |   for (const theme of ['light', 'dark'] as const) {
  9  |     await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  10 |     await page.evaluate(({ key, theme }) => { localStorage.removeItem(key); localStorage.setItem('playbook:theme', JSON.stringify(theme)) }, { key: RECORD_KEY, theme })
  11 |     await page.reload({ waitUntil: 'networkidle' })
  12 |     await expect(page.locator('html')).toHaveAttribute('data-theme', theme)
> 13 |     await page.getByLabel('Change and scope', { exact: true }).fill(literal)
     |                                                                ^ Error: locator.fill: Test timeout of 120000ms exceeded.
  14 |     await page.locator('#tab-your-evidence').click()
  15 |     await page.getByLabel('Observed evidence and limits', { exact: true }).fill('Not executed; source review only')
  16 |     await page.goBack(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue(literal)
  17 |     await page.goForward(); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  18 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  19 |     await page.locator('#tab-checklist').click(); await page.getByRole('checkbox', { name: CHECKS[9].text }).check()
  20 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByRole('checkbox', { name: CHECKS[9].text })).toBeChecked()
  21 |     for (const width of [320, 390, 768, 1024, 1440, 1920, 2560]) {
  22 |       await page.setViewportSize({ width, height: 900 })
  23 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true)
  24 |     }
  25 |     expect(await page.evaluate(() => Reflect.get(window, '__documentationExecuted'))).toBeUndefined()
  26 |     page.once('dialog', dialog => dialog.accept())
  27 |     await page.getByRole('button', { name: 'Clear whole record' }).click()
  28 |     expect(await page.evaluate(key => localStorage.getItem(key), RECORD_KEY)).toBeNull()
  29 |   }
  30 |   expect(errors).toEqual([])
  31 | })
  32 | 
  33 | test('documentation keeps an unsaved cross-panel draft and offers exact manual export when permissions fail', async ({ page }) => {
  34 |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  35 |   await page.addInitScript(key => {
  36 |     const read = Storage.prototype.getItem; const write = Storage.prototype.setItem
  37 |     Storage.prototype.getItem = function(name) { if (name === key) throw new DOMException('denied', 'SecurityError'); return read.call(this, name) }
  38 |     Storage.prototype.setItem = function(name, value) { if (name === key) throw new DOMException('quota', 'QuotaExceededError'); return write.call(this, name, value) }
  39 |     Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: () => Promise.reject(new Error('denied')) } })
  40 |   }, RECORD_KEY)
  41 |   await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  42 |   await page.getByLabel('Change and scope', { exact: true }).fill('Unsaved change')
  43 |   await page.locator('#tab-your-evidence').click()
  44 |   await page.getByLabel('Owner and reviewer', { exact: true }).fill('Me')
  45 |   await page.getByRole('button', { name: 'Copy as Markdown' }).click()
  46 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Unsaved change/)
  47 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Me/)
  48 |   await expect(page.getByText(/Saving is unavailable/)).toBeVisible()
  49 |   await page.locator('#tab-your-change').click(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue('Unsaved change')
  50 |   expect(errors).toEqual([])
  51 | })
  52 | 
  53 | test('documentation exposes replaced history and reasoning after a wrong keyboard answer', async ({ page }) => {
  54 |   await page.goto(`${STAGE}#decisions`, { waitUntil: 'networkidle' })
  55 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  56 |   await page.getByRole('button', { name: 'Read ADR 005' }).click()
  57 |   await expect(page.getByRole('region', { name: 'docs/adr/005-generated-contract-reference.md' })).toBeVisible()
  58 |   await page.getByRole('button', { name: 'Read ADR 004' }).click()
  59 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  60 |   await page.locator('#tab-comments').click()
  61 |   const radios = page.locator('#panel-comments').getByRole('radio')
  62 |   await radios.first().focus(); await radios.first().press('Space'); await radios.first().press('ArrowDown')
  63 |   await expect(radios.nth(1)).toBeChecked()
  64 |   expect((await radios.nth(1).boundingBox())!.height).toBeGreaterThanOrEqual(44)
  65 |   await page.getByRole('button', { name: 'Check answer' }).click()
  66 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  67 |   await expect(page.getByText(/It supplies no evidence of silent truncation/)).toBeVisible()
  68 |   await page.locator('#tab-history').click(); await page.locator('#tab-comments').click()
  69 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  70 | })
  71 | 
```