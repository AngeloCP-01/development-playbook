# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: documentation.spec.ts >> documentation keeps an unsaved cross-panel draft and offers exact manual export when permissions fail
- Location: e2e/documentation.spec.ts:33:5

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.fill: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByLabel('Change and scope', { exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - generic [ref=e5]:
        - link "Playbook 18" [ref=e6] [cursor=pointer]:
          - /url: /
          - generic [ref=e7]:
            - generic [ref=e8]: Playbook
            - generic [ref=e9]: "18"
        - generic [ref=e10]:
          - button "System theme. Click to change." [ref=e12]:
            - img [ref=e13]
          - button "Collapse index" [ref=e15]:
            - img [ref=e16]
      - generic [ref=e19]:
        - navigation "Stage index" [ref=e20]:
          - generic [ref=e21]:
            - generic [ref=e22]: Before code
            - list "Before code" [ref=e23]:
              - listitem [ref=e24]:
                - link "01 Product Discovery" [ref=e25] [cursor=pointer]:
                  - /url: /stages/01-product-discovery
                  - generic [ref=e26]: "01"
                  - generic [ref=e28]: Product Discovery
              - listitem [ref=e29]:
                - link "02 Product Planning" [ref=e30] [cursor=pointer]:
                  - /url: /stages/02-planning
                  - generic [ref=e31]: "02"
                  - generic [ref=e33]: Product Planning
              - listitem [ref=e34]:
                - link "03 Architecture" [ref=e35] [cursor=pointer]:
                  - /url: /stages/03-architecture
                  - generic [ref=e36]: "03"
                  - generic [ref=e38]: Architecture
          - generic [ref=e39]:
            - generic [ref=e40]: Building
            - list "Building" [ref=e41]:
              - listitem [ref=e42]:
                - link "04 Project Setup" [ref=e43] [cursor=pointer]:
                  - /url: /stages/04-project-setup
                  - generic [ref=e44]: "04"
                  - generic [ref=e46]: Project Setup
              - listitem [ref=e47]:
                - link "05 Development" [ref=e48] [cursor=pointer]:
                  - /url: /stages/05-development
                  - generic [ref=e49]: "05"
                  - generic [ref=e51]: Development
              - listitem [ref=e52]:
                - link "06 Testing" [ref=e53] [cursor=pointer]:
                  - /url: /stages/06-testing
                  - generic [ref=e54]: "06"
                  - generic [ref=e56]: Testing
              - listitem [ref=e57]:
                - link "07 Code Review" [ref=e58] [cursor=pointer]:
                  - /url: /stages/07-code-review
                  - generic [ref=e59]: "07"
                  - generic [ref=e61]: Code Review
              - listitem [ref=e62]:
                - link "08 Security Audit" [ref=e63] [cursor=pointer]:
                  - /url: /stages/08-security-audit
                  - generic [ref=e64]: "08"
                  - generic [ref=e66]: Security Audit
              - listitem [ref=e67]:
                - link "09 Performance Optimization" [ref=e68] [cursor=pointer]:
                  - /url: /stages/09-performance-optimization
                  - generic [ref=e69]: "09"
                  - generic [ref=e71]: Performance Optimization
              - listitem [ref=e72]:
                - link "10 Documentation WIP" [ref=e73] [cursor=pointer]:
                  - /url: /stages/10-documentation
                  - generic [ref=e74]: "10"
                  - generic [ref=e75]:
                    - generic [ref=e76]: Documentation
                    - generic "Not written yet" [ref=e77]: WIP
          - generic [ref=e78]:
            - generic [ref=e79]: Shipping
            - list "Shipping" [ref=e80]:
              - listitem [ref=e81]:
                - link "11 CI/CD" [ref=e82] [cursor=pointer]:
                  - /url: /stages/11-ci-cd
                  - generic [ref=e83]: "11"
                  - generic [ref=e85]: CI/CD
              - listitem [ref=e86]:
                - link "12 Staging" [ref=e87] [cursor=pointer]:
                  - /url: /stages/12-staging
                  - generic [ref=e88]: "12"
                  - generic [ref=e90]: Staging
              - listitem [ref=e91]:
                - link "13 Production Deployment" [ref=e92] [cursor=pointer]:
                  - /url: /stages/13-production-deployment
                  - generic [ref=e93]: "13"
                  - generic [ref=e95]: Production Deployment
              - listitem [ref=e96]:
                - link "14 Post-Deployment Verification" [ref=e97] [cursor=pointer]:
                  - /url: /stages/14-post-deployment-verification
                  - generic [ref=e98]: "14"
                  - generic [ref=e100]: Post-Deployment Verification
          - generic [ref=e101]:
            - generic [ref=e102]: Running
            - list "Running" [ref=e103]:
              - listitem [ref=e104]:
                - link "15 Observability" [ref=e105] [cursor=pointer]:
                  - /url: /stages/15-observability
                  - generic [ref=e106]: "15"
                  - generic [ref=e108]: Observability
              - listitem [ref=e109]:
                - link "16 Incident Management" [ref=e110] [cursor=pointer]:
                  - /url: /stages/16-incident-management
                  - generic [ref=e111]: "16"
                  - generic [ref=e113]: Incident Management
              - listitem [ref=e114]:
                - link "17 Maintenance WIP" [ref=e115] [cursor=pointer]:
                  - /url: /stages/17-maintenance
                  - generic [ref=e116]: "17"
                  - generic [ref=e117]:
                    - generic [ref=e118]: Maintenance
                    - generic "Not written yet" [ref=e119]: WIP
              - listitem [ref=e120]:
                - link "18 Continuous Improvement WIP" [ref=e121] [cursor=pointer]:
                  - /url: /stages/18-continuous-improvement
                  - generic [ref=e122]: "18"
                  - generic [ref=e123]:
                    - generic [ref=e124]: Continuous Improvement
                    - generic "Not written yet" [ref=e125]: WIP
        - navigation "Reference index" [ref=e126]:
          - generic [ref=e127]:
            - generic [ref=e128]: Architecture
            - list "Architecture" [ref=e129]:
              - listitem [ref=e130]:
                - link "Software Architecture Patterns" [ref=e131] [cursor=pointer]:
                  - /url: /reference/architecture-patterns
                  - generic [ref=e133]: Software Architecture Patterns
              - listitem [ref=e134]:
                - link "Design Patterns" [ref=e135] [cursor=pointer]:
                  - /url: /reference/design-patterns
                  - generic [ref=e137]: Design Patterns
              - listitem [ref=e138]:
                - link "API Design" [ref=e139] [cursor=pointer]:
                  - /url: /reference/api-design
                  - generic [ref=e141]: API Design
              - listitem [ref=e142]:
                - link "Caching" [ref=e143] [cursor=pointer]:
                  - /url: /reference/caching
                  - generic [ref=e145]: Caching
              - listitem [ref=e146]:
                - link "Infrastructure Scaling" [ref=e147] [cursor=pointer]:
                  - /url: /reference/scaling
                  - generic [ref=e149]: Infrastructure Scaling
          - generic [ref=e150]:
            - generic [ref=e151]: Design Principles
            - list [ref=e152]:
              - listitem [ref=e153]:
                - link "SOLID Principles" [ref=e154] [cursor=pointer]:
                  - /url: /reference/solid-principles
                  - generic [ref=e156]: SOLID Principles
              - listitem [ref=e157]:
                - link "Clean Code" [ref=e158] [cursor=pointer]:
                  - /url: /reference/clean-code
                  - generic [ref=e160]: Clean Code
          - generic [ref=e161]:
            - generic [ref=e162]: Git
            - list "Git" [ref=e163]:
              - listitem [ref=e164]:
                - link "Git Cheat Sheet" [ref=e165] [cursor=pointer]:
                  - /url: /reference/git-cheatsheet
                  - generic [ref=e167]: Git Cheat Sheet
              - listitem [ref=e168]:
                - link "Git Commands" [ref=e169] [cursor=pointer]:
                  - /url: /reference/git-commands
                  - generic [ref=e171]: Git Commands
              - listitem [ref=e172]:
                - link "Git Branching & Conventions" [ref=e173] [cursor=pointer]:
                  - /url: /reference/git-branching
                  - generic [ref=e175]: Git Branching & Conventions
          - generic [ref=e176]:
            - generic [ref=e177]: Standards
            - list "Standards" [ref=e178]:
              - listitem [ref=e179]:
                - link "Coding Standards" [ref=e180] [cursor=pointer]:
                  - /url: /reference/coding-standards
                  - generic [ref=e182]: Coding Standards
              - listitem [ref=e183]:
                - link "Software Development Life Cycle" [ref=e184] [cursor=pointer]:
                  - /url: /reference/sdlc
                  - generic [ref=e186]: Software Development Life Cycle
              - listitem [ref=e187]:
                - link "Testing" [ref=e188] [cursor=pointer]:
                  - /url: /reference/testing
                  - generic [ref=e190]: Testing
              - listitem [ref=e191]:
                - link "Playwright" [ref=e192] [cursor=pointer]:
                  - /url: /reference/playwright
                  - generic [ref=e194]: Playwright
              - listitem [ref=e195]:
                - link "Code Review" [ref=e196] [cursor=pointer]:
                  - /url: /reference/code-review
                  - generic [ref=e198]: Code Review
              - listitem [ref=e199]:
                - link "Deployment Environments" [ref=e200] [cursor=pointer]:
                  - /url: /reference/deployment-environments
                  - generic [ref=e202]: Deployment Environments
              - listitem [ref=e203]:
                - link "AWS Deployment" [ref=e204] [cursor=pointer]:
                  - /url: /reference/aws-deployment
                  - generic [ref=e206]: AWS Deployment
              - listitem [ref=e207]:
                - link "Post-Deploy Verification" [ref=e208] [cursor=pointer]:
                  - /url: /reference/post-deploy-verification
                  - generic [ref=e210]: Post-Deploy Verification
              - listitem [ref=e211]:
                - link "CI/CD Pipeline" [ref=e212] [cursor=pointer]:
                  - /url: /reference/ci-cd
                  - generic [ref=e214]: CI/CD Pipeline
              - listitem [ref=e215]:
                - link "GitHub Actions" [ref=e216] [cursor=pointer]:
                  - /url: /reference/github-actions
                  - generic [ref=e218]: GitHub Actions
              - listitem [ref=e219]:
                - link "Incident Management" [ref=e220] [cursor=pointer]:
                  - /url: /reference/incident-management
                  - generic [ref=e222]: Incident Management
              - listitem [ref=e223]:
                - link "Security Audit" [ref=e224] [cursor=pointer]:
                  - /url: /reference/security
                  - generic [ref=e226]: Security Audit
          - generic [ref=e227]:
            - generic [ref=e228]: Languages
            - list "Languages" [ref=e229]:
              - listitem [ref=e230]:
                - link "JavaScript WIP" [ref=e231] [cursor=pointer]:
                  - /url: /reference/javascript
                  - generic [ref=e232]:
                    - generic [ref=e233]: JavaScript
                    - generic "Not gathered yet" [ref=e234]: WIP
              - listitem [ref=e235]:
                - link "Python WIP" [ref=e236] [cursor=pointer]:
                  - /url: /reference/python
                  - generic [ref=e237]:
                    - generic [ref=e238]: Python
                    - generic "Not gathered yet" [ref=e239]: WIP
              - listitem [ref=e240]:
                - link "Java WIP" [ref=e241] [cursor=pointer]:
                  - /url: /reference/java
                  - generic [ref=e242]:
                    - generic [ref=e243]: Java
                    - generic "Not gathered yet" [ref=e244]: WIP
              - listitem [ref=e245]:
                - link "Spring Boot WIP" [ref=e246] [cursor=pointer]:
                  - /url: /reference/spring-boot
                  - generic [ref=e247]:
                    - generic [ref=e248]: Spring Boot
                    - generic "Not gathered yet" [ref=e249]: WIP
              - listitem [ref=e250]:
                - link "Express & Node WIP" [ref=e251] [cursor=pointer]:
                  - /url: /reference/express
                  - generic [ref=e252]:
                    - generic [ref=e253]: Express & Node
                    - generic "Not gathered yet" [ref=e254]: WIP
    - main [ref=e256]:
      - article [ref=e257]:
        - generic [ref=e258]:
          - generic [ref=e259]:
            - generic [ref=e260]:
              - generic [ref=e261]:
                - generic [ref=e262]: Sheet
                - generic [ref=e263]: "10"
              - generic [ref=e264]:
                - generic [ref=e265]: Section
                - generic [ref=e266]: Building
              - generic [ref=e267]:
                - generic [ref=e268]: Cadence
                - generic [ref=e269]: Continuous
            - heading "Documentation" [level=1] [ref=e271]
          - paragraph [ref=e272]: "Write down what code cannot say: why."
          - paragraph [ref=e273]: When · Continuously, a little with every change.
        - generic [ref=e275]:
          - paragraph [ref=e276]: Sheet not drawn
          - paragraph [ref=e277]: The markdown for this stage exists in the repo. The interactive version is still to come.
        - navigation [ref=e278]:
          - link "11 Next sheet CI/CD" [ref=e279] [cursor=pointer]:
            - /url: /stages/11-ci-cd
            - generic [ref=e280]: "11"
            - generic [ref=e281]:
              - generic [ref=e282]: Next sheet
              - generic [ref=e283]: CI/CD
            - img [ref=e284]
  - alert [ref=e286]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | import { CHECKS, RECORD_KEY } from '../src/features/documentation/record'
  3  | const STAGE = '/stages/10-documentation'
  4  | 
  5  | test('documentation retains a literal change record across hashes history and reload in both themes', async ({ page }) => {
  6  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  7  |   const literal = '<script>window.__documentationExecuted=true</script>' + 'x'.repeat(600)
  8  |   for (const theme of ['light', 'dark'] as const) {
  9  |     await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  10 |     await page.evaluate(({ key, theme }) => { localStorage.removeItem(key); localStorage.setItem('playbook:theme', JSON.stringify(theme)) }, { key: RECORD_KEY, theme })
  11 |     await page.reload({ waitUntil: 'networkidle' })
  12 |     await expect(page.locator('html')).toHaveAttribute('data-theme', theme)
  13 |     await page.getByLabel('Change and scope', { exact: true }).fill(literal)
  14 |     await page.locator('#tab-your-evidence').click()
  15 |     await page.getByLabel('Observed evidence and limits', { exact: true }).fill('Not executed; source review only')
  16 |     await page.goBack(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue(literal)
  17 |     await page.goForward(); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  18 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
  19 |     await page.locator('#tab-checklist').click(); await page.getByRole('checkbox', { name: CHECKS[9].text }).check()
  20 |     await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByRole('checkbox', { name: CHECKS[9].text })).toBeChecked()
  21 |     for (const width of [320, 390, 768, 1024, 1440, 1920, 2560]) {
  22 |       await page.setViewportSize({ width, height: 900 })
  23 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true)
  24 |     }
  25 |     expect(await page.evaluate(() => Reflect.get(window, '__documentationExecuted'))).toBeUndefined()
  26 |     page.once('dialog', dialog => dialog.accept())
  27 |     await page.getByRole('button', { name: 'Clear whole record' }).click()
  28 |     expect(await page.evaluate(key => localStorage.getItem(key), RECORD_KEY)).toBeNull()
  29 |   }
  30 |   expect(errors).toEqual([])
  31 | })
  32 | 
  33 | test('documentation keeps an unsaved cross-panel draft and offers exact manual export when permissions fail', async ({ page }) => {
  34 |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  35 |   await page.addInitScript(key => {
  36 |     const read = Storage.prototype.getItem; const write = Storage.prototype.setItem
  37 |     Storage.prototype.getItem = function(name) { if (name === key) throw new DOMException('denied', 'SecurityError'); return read.call(this, name) }
  38 |     Storage.prototype.setItem = function(name, value) { if (name === key) throw new DOMException('quota', 'QuotaExceededError'); return write.call(this, name, value) }
  39 |     Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: () => Promise.reject(new Error('denied')) } })
  40 |   }, RECORD_KEY)
  41 |   await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
> 42 |   await page.getByLabel('Change and scope', { exact: true }).fill('Unsaved change')
     |                                                              ^ Error: locator.fill: Test timeout of 120000ms exceeded.
  43 |   await page.locator('#tab-your-evidence').click()
  44 |   await page.getByLabel('Owner and reviewer', { exact: true }).fill('Me')
  45 |   await page.getByRole('button', { name: 'Copy as Markdown' }).click()
  46 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Unsaved change/)
  47 |   await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Me/)
  48 |   await expect(page.getByText(/Saving is unavailable/)).toBeVisible()
  49 |   await page.locator('#tab-your-change').click(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue('Unsaved change')
  50 |   expect(errors).toEqual([])
  51 | })
  52 | 
  53 | test('documentation exposes replaced history and reasoning after a wrong keyboard answer', async ({ page }) => {
  54 |   await page.goto(`${STAGE}#decisions`, { waitUntil: 'networkidle' })
  55 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  56 |   await page.getByRole('button', { name: 'Read ADR 005' }).click()
  57 |   await expect(page.getByRole('region', { name: 'docs/adr/005-generated-contract-reference.md' })).toBeVisible()
  58 |   await page.getByRole('button', { name: 'Read ADR 004' }).click()
  59 |   await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  60 |   await page.locator('#tab-comments').click()
  61 |   const radios = page.locator('#panel-comments').getByRole('radio')
  62 |   await radios.first().focus(); await radios.first().press('Space'); await radios.first().press('ArrowDown')
  63 |   await expect(radios.nth(1)).toBeChecked()
  64 |   expect((await radios.nth(1).boundingBox())!.height).toBeGreaterThanOrEqual(44)
  65 |   await page.getByRole('button', { name: 'Check answer' }).click()
  66 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  67 |   await expect(page.getByText(/It supplies no evidence of silent truncation/)).toBeVisible()
  68 |   await page.locator('#tab-history').click(); await page.locator('#tab-comments').click()
  69 |   await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  70 | })
  71 | 
```