### Task 5: Make document selection and change tracing consultable

**Files:** Create `lookups.ts`, `LookupInspector.tsx`, `LookupPanels.tsx`, `LookupPanels.test.tsx`.

**Interfaces:** Consumes Task 3. Produces `LookupEntry`, arrays `NEEDS`, `ARTIFACTS`,
`FACTS`, `CHANGES`, `HISTORY`; `LookupInspector({ title, entries })` and panels
`ChoosePanel`, `ReferencePanel`, `ChangesPanel`, `HistoryPanel`.

- [ ] **Step 1: Write the render tests.**

```tsx
import { fireEvent, render, screen } from '@testing-library/react'
import { expect, test } from 'vitest'
import { ChoosePanel, ReferencePanel, ChangesPanel, HistoryPanel } from './LookupPanels'
import { LookupInspector } from './LookupInspector'
import { ARTIFACTS, CHANGES, FACTS, HISTORY, NEEDS } from './lookups'
test('every selector reveals the facts belonging to its actual row', () => {
  for (const entries of [NEEDS, FACTS, CHANGES, HISTORY]) {
    const view = render(<LookupInspector title="Lookup" entries={entries} />)
    for (const entry of entries) {
      fireEvent.click(screen.getByRole('tab', { name: entry.label }))
      const panel = screen.getByRole('tabpanel', { name: entry.label })
      expect(panel.textContent).toContain(entry.summary)
      for (const fact of entry.details) expect(panel.textContent).toContain(fact.text)
    }
    view.unmount()
  }
})
test('changed inspector data reaches the rendered detail instead of a hard-coded default', () => {
  render(<LookupInspector title="Injected" entries={[{ ...FACTS[0], details: [{ label: 'Source', text: 'Changed source sentinel' }] }]} />)
  expect(screen.getByRole('tabpanel').textContent).toContain('Changed source sentinel')
})
test('the reference distinguishes an unset setting from an omitted optional response', () => {
  render(<ReferencePanel />)
  expect(screen.getByText('integer 1–365')).toBeTruthy(); expect(screen.getByText('30 when unset')).toBeTruthy()
  fireEvent.click(screen.getByRole('tab', { name: 'waitlistPosition' }))
  expect(screen.getByText('positive integer')).toBeTruthy(); expect(screen.getByText('omitted when not waitlisted')).toBeTruthy()
  expect(screen.getByText(/absent, null and empty/)).toBeTruthy()
  expect(screen.getByText(/books or cancels/)).toBeTruthy(); expect(screen.getByText(/reads\/writes/)).toBeTruthy()
})
test('the six change chains include actual enforcement and source checks rather than a generation guarantee', () => {
  expect(CHANGES.map(row => row.id)).toEqual(['configuration', 'response', 'values', 'boundary', 'procedure', 'failure'])
  render(<ChangesPanel />)
  fireEvent.click(screen.getByRole('button', { name: 'Does configuration enforce itself?' }))
  fireEvent.click(screen.getByRole('button', { name: 'What does automation establish?' }))
  expect(screen.getByText(/only if the application actually invokes it/)).toBeTruthy()
  expect(screen.getByText(/Generation follows its input/)).toBeTruthy()
  expect(screen.getByText(/When working alone, you are the owner/)).toBeTruthy()
})
test('artifact choices remain optional and release material distinguishes its audiences', () => {
  render(<ChoosePanel />)
  expect(NEEDS.map(row => row.id)).toEqual(['tutorial', 'how-to', 'reference', 'explanation'])
  expect(NEEDS.map(row => row.summary.split(':')[0])).toEqual(['Tutorial', 'How-to guide', 'Reference', 'Explanation'])
  expect(ARTIFACTS.map(row => row.id)).toEqual(['readme', 'architecture', 'adr', 'conventions', 'troubleshooting', 'changelog', 'release-notes'])
  for (const row of ARTIFACTS) {
    fireEvent.click(screen.getByRole('button', { name: row.label })); expect(screen.getByText(row.summary)).toBeTruthy()
  }
  expect(screen.getByText(/not a raw commit dump/)).toBeTruthy()
  expect(screen.getByText(/not a nine-document mandate/)).toBeTruthy()
})
test('history distinguishes preservation from current instructions and points to the actual commit guidance', () => {
  render(<HistoryPanel />)
  fireEvent.click(screen.getByRole('tab', { name: 'Current instructions' }))
  expect(screen.getByText(/correct, redirect or retire/i)).toBeTruthy()
  fireEvent.click(screen.getByRole('button', { name: 'Commit context' }))
  expect(screen.getByText(/a clear subject can be enough/)).toBeTruthy()
  expect(screen.getByRole('link', { name: 'Stage 05 commit guidance' }).getAttribute('href')).toBe('/stages/05-development#commits')
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/LookupPanels.test.tsx`; capture RED.**
- [ ] **Step 3: Add `lookups.ts`.** All values remain authored illustrative facts; no app configuration is created.

```ts
export type LookupEntry = { id: string; label: string; summary: string; details: readonly { label: string; text: string }[] }
export const NEEDS: readonly LookupEntry[] = [
  { id: 'tutorial', label: 'Learn a skill', summary: 'Tutorial: learn through a guided exercise.', details: [{ label: 'Workshop example', text: 'Make a first booking in a safe sample environment.' }] },
  { id: 'how-to', label: 'Complete a task', summary: 'How-to guide: complete a known task.', details: [{ label: 'Example', text: 'Roll back a deployment using the applicable procedure.' }] },
  { id: 'reference', label: 'Look up facts', summary: 'Reference: find exact names, types, allowed values and absence behavior.', details: [{ label: 'Workshop example', text: 'Look up a setting default or an optional response field.' }] },
  { id: 'explanation', label: 'Understand a choice', summary: 'Explanation: understand a concept or reason.', details: [{ label: 'Workshop example', text: 'Understand why the factual contract reference is generated.' }] },
]
export const ARTIFACTS = [
  { id: 'readme', label: 'README / getting started', summary: 'A first working setup and a route to more detail.' },
  { id: 'architecture', label: 'Architecture overview', summary: 'Boundaries, responsibilities and relationships a reader needs.' },
  { id: 'adr', label: 'Decision record', summary: 'A significant choice and its alternatives need a lasting explanation.' },
  { id: 'conventions', label: 'Conventions / contributing', summary: 'Contributors need consistent rules, exceptions and review expectations.' },
  { id: 'troubleshooting', label: 'Troubleshooting', summary: 'A known symptom needs checks, likely causes and a safe next action.' },
  { id: 'changelog', label: 'Changelog', summary: 'Notable changes curated by version, not a raw commit dump.' },
  { id: 'release-notes', label: 'Release notes', summary: 'A particular audience needs release impact and required actions.' },
] as const
export const FACTS: readonly LookupEntry[] = [
  { id: 'setting', label: 'BOOKING_WINDOW_DAYS', summary: 'Illustrative Workshop configuration reference.', details: [
    { label: 'Shape', text: 'integer 1–365' }, { label: 'Default or absence', text: '30 when unset' }, { label: 'Source', text: 'Versioned startup configuration validator' }, { label: 'Owner / trigger', text: 'Maintainer / validator change' },
  ] },
  { id: 'response', label: 'waitlistPosition', summary: 'Illustrative Workshop response reference.', details: [
    { label: 'Shape', text: 'positive integer' }, { label: 'Default or absence', text: 'omitted when not waitlisted' }, { label: 'Source', text: 'Versioned response contract and serializer' }, { label: 'Owner / trigger', text: 'Contract owner / response change' },
  ] },
]
export const CHANGES: readonly LookupEntry[] = [
  { id: 'configuration', label: 'Configuration', summary: 'Workshop adds BOOKING_WINDOW_DAYS.', details: [
    { label: 'Source', text: 'Startup validator and its unset/invalid behavior' }, { label: 'Documents', text: 'Configuration reference, .env.example and setup guide' }, { label: 'Check', text: 'Compare integer 1–365 and default 30 with validation; test missing/invalid values.' }, { label: 'Owner / trigger', text: 'Maintainer / validator change' },
  ] },
  { id: 'response', label: 'Response contract', summary: 'Workshop adds a response field.', details: [
    { label: 'Source', text: 'Response schema and serializer behavior' }, { label: 'Documents', text: 'Generated reference and example response' }, { label: 'Check', text: 'Run generation, inspect the expected diff and verify optional-field omission.' }, { label: 'Owner / trigger', text: 'Contract owner / response change' },
  ] },
  { id: 'values', label: 'Default or allowed value', summary: 'An option changes its default or range.', details: [
    { label: 'Source', text: 'Implementation and behavioral test' }, { label: 'Documents', text: 'Existing reference and relevant how-to' }, { label: 'Check', text: 'Find old values and check new behavior, not only matching strings.' }, { label: 'Owner / trigger', text: 'Maintainer / option change' },
  ] },
  { id: 'boundary', label: 'Boundary or dependency', summary: 'A relationship in the system changes.', details: [
    { label: 'Source', text: 'Current system and decision record' }, { label: 'Documents', text: 'Architecture view, ADR and affected runbook' }, { label: 'Check', text: 'Trace affected relationships and replacement links.' }, { label: 'Owner / trigger', text: 'Area owner / boundary change' },
  ] },
  { id: 'procedure', label: 'Setup or release procedure', summary: 'Commands, access or environment change.', details: [
    { label: 'Source', text: 'Actual commands, access and environment' }, { label: 'Documents', text: 'README and linked procedures' }, { label: 'Check', text: 'Follow the documented path safely and record the result.' }, { label: 'Owner / trigger', text: 'Maintainer / procedure change' },
  ] },
  { id: 'failure', label: 'Known failure or release', summary: 'A confirmed fix or release needs useful documentation.', details: [
    { label: 'Source', text: 'Diagnosed behavior and release record' }, { label: 'Documents', text: 'Troubleshooting, changelog or release notes as needed' }, { label: 'Check', text: 'Verify the check/workaround and publish only supported impact claims.' }, { label: 'Owner / trigger', text: 'Maintainer / confirmed fix or release' },
  ] },
]
export const HISTORY: readonly LookupEntry[] = [
  { id: 'historical', label: 'Historical record', summary: 'Preserve historical ADRs and release records.', details: [{ label: 'Action', text: 'Keep the original reasons with discoverable replacement or version context.' }] },
  { id: 'current', label: 'Current instructions', summary: 'Correct, redirect or retire obsolete current procedures.', details: [{ label: 'Action', text: 'Do not leave a stale setup guide looking current. Link the replacement where readers expect it.' }] },
]
```

`LookupInspector.tsx`:

```tsx
import { Card } from '@/components/ui'
import { InlineCode } from '@/components/InlineCode'
import { SelectionTabs } from './SelectionTabs'
import type { LookupEntry } from './lookups'
export function LookupInspector({ title, entries }: { title: string; entries: readonly LookupEntry[] }) {
  return <Card><h3 className="t-head mb-4 text-lg">{title}</h3>
    <SelectionTabs label={title} items={entries.map(entry => ({ id: entry.id, label: entry.label, content: <div>
      <p className="mb-4 text-sm text-muted">{entry.summary}</p>
      <dl className="space-y-3">{entry.details.map(fact => <div key={fact.label} className="min-w-0">
        <dt className="t-label mb-1 text-subtle">{fact.label}</dt><dd className="break-words text-sm leading-relaxed text-muted"><InlineCode text={fact.text} /></dd>
      </div>)}</dl>
    </div> }))} />
  </Card>
}
```

`LookupPanels.tsx`:

```tsx
import Link from 'next/link'
import { Figure } from '@/components/Figure'
import { RevealList } from '@/components/RevealList'
import { Prose, Section } from '@/components/ui'
import { ARTIFACTS, CHANGES, FACTS, HISTORY, NEEDS } from './lookups'
import { LookupInspector } from './LookupInspector'
export function ChoosePanel() {
  return <Section title="Choose the document for the reader's task">
    <Prose><p>Documentation runs continuously, a little with each change. Start with the smallest set that answers a real reader&apos;s question: a README, significant decisions and configuration facts the application actually needs.</p></Prose>
    <div className="mt-5"><LookupInspector title="What does the reader need?" entries={NEEDS} /></div>
    <p className="my-4 text-sm text-muted"><a href="https://diataxis.fr/start-here/">Diátaxis distinguishes four reader needs</a>; it does not require four folders.</p>
    <RevealList idPrefix="documentation-artifacts" rows={ARTIFACTS.map(row => ({ id: row.id, title: row.label, body: <p>{row.summary}</p> }))} />
    <Prose><p>A small patch may need only one entry. <a href="https://keepachangelog.com/en/1.1.0/">Keep a Changelog</a> explains curated history; <a href="https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases">GitHub releases</a> provides audience-facing release material. The gathered template menu is not a nine-document mandate.</p></Prose>
  </Section>
}
export function ReferencePanel() {
  return <Section title="State exact facts and current boundaries">
    <Prose><p>A useful view names its scope, components, relationships, owner and review trigger. Link decisions for reasons; <Link href="/stages/03-architecture">Stage 03 owns architecture design</Link>.</p></Prose>
    <Figure n={1} caption="Illustrative Workshop scope: one application and its booking store. No payment or email dependency is implied.">
      <div className="flex flex-wrap items-center gap-3 border border-line bg-sunken p-4 text-sm text-fg"><span>Attendee</span><span>→ books or cancels →</span><span>Workshop app</span><span>→ reads/writes →</span><span>Booking store</span></div>
    </Figure>
    <p className="mb-4 text-sm text-muted">The maintainer reviews this view when a boundary or dependency changes. <a href="https://c4model.com/diagrams/checklist">C4&apos;s review checklist</a> helps check readability.</p>
    <LookupInspector title="Illustrative Workshop reference" entries={FACTS} />
    <Prose><p>Record the applicable version and authoritative source. Treat absent, null and empty as distinct possibilities; document the behavior your actual contract defines. Generation follows its input and does not establish that the source is correct.</p></Prose>
  </Section>
}
export function ChangesPanel() {
  return <Section title="Trace the change to documents and checks">
    <Prose><p>When working alone, you are the owner. Give each living document a review trigger. Select the change to trace its source, affected documents and check.</p></Prose>
    <div className="mt-5"><LookupInspector title="Change-to-document check" entries={CHANGES} /></div>
    <div className="mt-5"><RevealList idPrefix="documentation-drift" rows={[
      { id: 'validator', title: 'Does configuration enforce itself?', body: <p>.env.example lists configuration. A validator enforces accepted values only if the application actually invokes it. This static playbook needs no environment variables; Workshop is illustrative. Use safe placeholders, never real credentials.</p> },
      { id: 'automation', title: 'What does automation establish?', body: <p>Types check some shapes. Tests check the behavior their assertions cover. Generation follows its input. Inspect the source and expected diff; choose the check for the claim you need to trust. <a href="https://www.writethedocs.org/guide/docs-as-code/">Docs as code</a> adds version control, review and automation. <Link href="/stages/06-testing">Stage 06 owns test design</Link>.</p> },
    ]} /></div>
  </Section>
}
export function HistoryPanel() {
  return <Section title="Keep historical reasons and current instructions usable">
    <LookupInspector title="What kind of document is this?" entries={HISTORY} />
    <p className="my-4 text-sm text-muted">Skip obvious comments and duplicated inventories nobody will maintain. Current structure and exact facts still earn their cost when they answer real questions.</p>
    <RevealList idPrefix="documentation-history" rows={[{ id: 'commits', title: 'Commit context', body: <div><p>Use a body when a reason, constraint or rejected alternative matters later; a clear subject can be enough for a small self-explanatory change. History preserves mistakes and superseded intent too. Keep current instructions where readers expect them.</p><p className="mt-3"><Link href="/stages/05-development#commits">Stage 05 commit guidance</Link></p></div> }]} />
  </Section>
}
```

- [ ] **Step 4: Run focused GREEN, lint and typecheck.** Confirm all six chains and both facts remain reachable through keyboard tabs. The Step 1 tests independently pin the four forms, six change IDs and factual values.
- [ ] **Step 5: Teeth check.** Change only LookupInspector's detail renderer to a fixed first-row fact; the injected-data test must fail. Restore and rerun the file. Distinguish any additional failures instead of claiming a one-test result without running them.
- [ ] **Step 6: Independent review and commit** `feat(documentation): add document and change inspectors`. Deferred: drills, forms and stage registration.

