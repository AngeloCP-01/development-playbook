
- Work in `/Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter`, branch `feat/stage-10-documentation`. Chapter base `c092ac7`; develop base `79f9e31`. Preserve the completed chapter branch, parent changes and parent port-3200 server.
- The app remains Next.js 16, React 19 and TypeScript with existing dependencies.
- Use `web/DESIGN.md` tokens and type roles in both whiteprint and cyanotype themes. Brand indicates attention; semantic colors indicate a verdict. Text or icons must also carry that verdict.
- One judgment per panel and at most four screens at 1024×768. The twelve initial IDs below are the approved design; measured D-52 splits retain teaching and update declarations/tests/records together.
- Workshop remains the illustrative case. Toolshare stays held out of authored examples, fixtures and drills so the port can be assessed with the same scenario.
- Reuse `useLocalStorage` as the subscription mechanism; use a stable server-empty snapshot and normalize its unknown data. Do not introduce effect-body setState for hydration.
- Use one versioned key, `playbook:documentation-change:v1`; eight string fields and ten known checklist IDs. Exercises are session-only and do not alter the personal record.
- Every new copy action handles missing/denied clipboard access. Failed storage retains an editable stage-session draft with an honest warning; it must survive panel navigation.
- The canonical Markdown and hand-authored React content remain separate by the repository's established design. No runtime Markdown parser, image publication, W-6 sheet, backend or generator installation.
- All task tests and implementation sources appear inline because AGENTS.md requires full-source task slices. This intentionally exceeds the writing-plans skill's usual compact-plan preference. These are proposed sources, not executed code or TDD evidence.
- For each task: write the test, capture actual RED for the expected reason, implement, capture GREEN, run a targeted teeth mutation and restore, then independent read-only review. Keep raw logs/diffs in `docs/superpowers/reports/2026-10-20-stage-10-port-execution.md` or its linked evidence directory. Import errors prove the missing interface initially; behavior tests must fail meaningfully once a shell exists.
- Every task gets independent review even if the user chooses inline execution. Final whole-branch review covers `79f9e31..HEAD`, retaining chapter review evidence and checking the final fix wave itself.
- Every merge needs the user's separate approval; pushes and promotion to main remain the user's.

