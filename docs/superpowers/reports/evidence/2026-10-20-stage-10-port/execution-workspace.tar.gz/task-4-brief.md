### Task 4: Teach usable READMEs and visible decision replacement

**Files:** Create `documents.ts`, `DocumentExample.tsx`, `DocumentPanels.tsx`, `DocumentPanels.test.tsx`.

**Interfaces:** Consumes Task 3. Produces `DocumentExample({ example })`,
`ReadmePanel()`, `DecisionsPanel()`, `README`, `ADRS`, `DocExample` and
`documentMarkdown(example)`. `ADRS` has `old`, `replacement`, `template` entries.
Counterpart controls in the client DecisionsPanel select the other complete
specimen; displayed filenames never navigate to fictional repository routes.

- [ ] **Step 1: Write the complete render tests.**

```tsx
import { act, fireEvent, render, screen, within } from '@testing-library/react'
import { afterEach, expect, test, vi } from 'vitest'
import { DecisionsPanel, ReadmePanel } from './DocumentPanels'
import { ADRS, documentMarkdown, README } from './documents'
afterEach(() => vi.unstubAllGlobals())
test('the README keeps unknown setup facts visible and copies the same outline a maintainer reads', async () => {
  const write = vi.fn().mockResolvedValue(undefined); vi.stubGlobal('navigator', { clipboard: { writeText: write } })
  render(<ReadmePanel />)
  expect(screen.getByText(/Supported prerequisites and tool versions/).textContent).toContain('[actual prerequisites]')
  expect(screen.getByText(/Clone, install and startup commands/).textContent).toContain('[commands tested for this revision]')
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Copy README outline' })) })
  expect(write).toHaveBeenCalledWith(documentMarkdown(README))
  fireEvent.click(screen.getByRole('button', { name: 'Fresh-clone check' }))
  expect(screen.getByText(/without private instructions/)).toBeTruthy()
  expect(screen.getByText(/revision, prerequisites, configuration source, commands and expected result/)).toBeTruthy()
})
test('the old ADR itself declares its dated current status and preserves the accepted history', async () => {
  const write = vi.fn().mockResolvedValue(undefined); vi.stubGlobal('navigator', { clipboard: { writeText: write } })
  render(<DecisionsPanel />)
  const old = screen.getByRole('region', { name: ADRS.old.filename })
  expect(within(old).getByText('Status: Accepted')).toBeTruthy()
  expect(within(old).getByText('2026-10-20 — Current status: Superseded.')).toBeTruthy()
  expect(within(old).getByText('The original context, date and reasoning above are preserved.')).toBeTruthy()
  fireEvent.click(within(old).getByRole('button', { name: 'Read ADR 005' }))
  const current = screen.getByRole('region', { name: ADRS.replacement.filename })
  expect(within(current).getByText('Status: Accepted')).toBeTruthy()
  expect(within(current).getByText('Date: 2026-10-20')).toBeTruthy()
  expect(screen.getByRole('tab', { name: 'ADR 005' }).getAttribute('aria-selected')).toBe('true')
  expect(document.activeElement).toBe(screen.getByRole('tab', { name: 'ADR 005' }))
  await act(async () => { fireEvent.click(within(current).getByRole('button', { name: 'Copy ADR 005' })) })
  expect(write).toHaveBeenCalledWith(documentMarkdown(ADRS.replacement))
  fireEvent.click(within(current).getByRole('button', { name: 'Read ADR 004' }))
  expect(screen.getByRole('region', { name: ADRS.old.filename })).toBeTruthy()
  expect(documentMarkdown(ADRS.old)).toContain('[ADR 005](005-generated-contract-reference.md)')
  expect(documentMarkdown(ADRS.replacement)).toContain('[ADR 004](004-manual-field-reference.md)')
})
test('the blank ADR is explicitly a template with project facts to supply rather than a copied Workshop decision', () => {
  render(<DecisionsPanel />)
  fireEvent.click(screen.getByRole('tab', { name: 'Blank template' }))
  const template = screen.getByRole('region', { name: ADRS.template.filename })
  for (const heading of ['Context', 'Decision', 'Reasoning', 'Consequences', 'Alternatives']) expect(within(template).getByRole('heading', { name: heading })).toBeTruthy()
  expect(template.textContent).toContain('[actual date]')
  expect(template.textContent).not.toContain('Status: Accepted')
  expect(template.textContent).not.toContain('Workshop')
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/DocumentPanels.test.tsx`; capture RED.**
- [ ] **Step 3: Add full data and components.** `documents.ts`:

```ts
export type DocExample = {
  id: string; filename: string; title: string; meta: readonly string[]
  blocks: readonly { heading: string; paragraphs: readonly string[] }[]
  related?: { prefix: string; label: string; filename: string; target: 'old' | 'replacement' }
}
export const README: DocExample = {
  id: 'readme', filename: 'README.md outline', title: 'Project name',
  meta: ['What this does, who uses it, and the smallest useful outcome.'],
  blocks: [
    { heading: 'Running locally', paragraphs: [
      'Supported prerequisites and tool versions: [actual prerequisites].',
      'Access and safe configuration source: [how a maintainer obtains them].',
      'Clone, install and startup commands: [commands tested for this revision].',
      'Expected result and first useful check: [observable result].',
    ] },
    { heading: 'Architecture', paragraphs: ['Scope, main boundaries and external dependencies: [current view].', 'Decision records: [link to the decision log or relevant ADRs].'] },
    { heading: 'Deploying', paragraphs: ['Release and rollback procedures: [links, permissions and compatibility limits].', 'Logs and health checks: [where to look].', 'Help or responsible maintainer: [contact role or support route].'] },
  ],
}
export const ADRS: Record<'old' | 'replacement' | 'template', DocExample> = {
  old: {
    id: '004', filename: 'docs/adr/004-manual-field-reference.md', title: 'ADR 004: maintain the initial field reference by hand',
    meta: ['Date: 2026-09-01', 'Status: Accepted'],
    related: { prefix: 'Replacement', label: 'ADR 005', filename: '005-generated-contract-reference.md', target: 'replacement' },
    blocks: [
      { heading: 'Context', paragraphs: ['The initial contract is small. The team has no reference generator.'] },
      { heading: 'Decision', paragraphs: ['Maintain the initial field reference beside the contract.'] },
      { heading: 'Consequences', paragraphs: ['Every contract change requires a separate reference edit and review.'] },
      { heading: 'Supersession notice (appended)', paragraphs: ['2026-10-20 — Current status: Superseded.', 'The original context, date and reasoning above are preserved.'] },
    ],
  },
  replacement: {
    id: '005', filename: 'docs/adr/005-generated-contract-reference.md', title: 'ADR 005: generate the factual contract reference',
    meta: ['Date: 2026-10-20', 'Status: Accepted'],
    related: { prefix: 'Supersedes', label: 'ADR 004', filename: '004-manual-field-reference.md', target: 'old' },
    blocks: [
      { heading: 'Context', paragraphs: ['New settings and response fields make two edited field lists easy to disagree.'] },
      { heading: 'Decision', paragraphs: ['Generate the factual reference from the versioned contract.'] },
      { heading: 'Reasoning', paragraphs: ['Keep names, types and defaults tied to one source.'] },
      { heading: 'Consequences', paragraphs: ['We must run generation and inspect its result when the contract changes.', 'Explanations and examples still need human review.'] },
      { heading: 'Alternatives', paragraphs: ['Keep editing the field list by hand, accepting the duplicate review work.'] },
    ],
  },
  template: {
    id: 'template', filename: 'docs/adr/NNN-title.md template', title: 'ADR NNN: [significant choice]',
    meta: ['Date: [actual date]', 'Status: [Proposed, Rejected, Accepted or Superseded]'],
    blocks: [
      { heading: 'Context', paragraphs: ['[Situation, constraints and revision in scope.]'] },
      { heading: 'Decision', paragraphs: ['[The choice under consideration or adopted.]'] },
      { heading: 'Reasoning', paragraphs: ['[Why this choice fits those constraints.]'] },
      { heading: 'Consequences', paragraphs: ['[Costs, obligations and follow-up checks.]'] },
      { heading: 'Alternatives', paragraphs: ['[Options considered and reasons not chosen.]'] },
    ],
  },
}
export function documentMarkdown(example: DocExample): string {
  return [`# ${example.title}`, ...example.meta,
    ...(example.related ? [`${example.related.prefix}: [${example.related.label}](${example.related.filename})`] : []), '',
    ...example.blocks.flatMap(block => [`## ${block.heading}`, ...block.paragraphs, '']),
  ].join('\n')
}
```

`DocumentExample.tsx`:

```tsx
import type { ReactNode } from 'react'
import { Card } from '@/components/ui'
import { CopyMarkdown } from './CopyMarkdown'
import { documentMarkdown, type DocExample } from './documents'
export function DocumentExample({ example, relatedControl }: { example: DocExample; relatedControl?: ReactNode }) {
  return <section aria-label={example.filename} className="min-w-0">
    <Card><p className="t-data mb-3 break-words text-sm text-muted">{example.filename}</p>
      <h3 className="t-head mb-3 text-lg">{example.title}</h3>
      {example.meta.map(line => <p key={line} className="break-words text-sm text-muted">{line}</p>)}
      {example.related && <p className="mt-2 break-words text-sm text-muted">{example.related.prefix}: {example.related.label} ({example.related.filename})</p>}
      {relatedControl}
      {example.blocks.map(block => <div key={block.heading} className="mt-4">
        <h4 className="t-ui mb-1 text-sm font-semibold">{block.heading}</h4>
        {block.paragraphs.map(line => <p key={line} className="break-words text-sm leading-relaxed text-muted">{line}</p>)}
      </div>)}
      <CopyMarkdown text={documentMarkdown(example)} label={example.id === 'readme' ? 'Copy README outline' : `Copy ${example.id === 'template' ? 'ADR template' : `ADR ${example.id}`}`} manualLabel={`${example.filename} Markdown`} />
    </Card>
  </section>
}
```

`DocumentPanels.tsx`:

```tsx
'use client'
import Link from 'next/link'
import { useRef } from 'react'
import { RevealList } from '@/components/RevealList'
import { Term } from '@/components/Term'
import { Prose, Section } from '@/components/ui'
import { DocumentExample } from './DocumentExample'
import { ADRS, README } from './documents'
import { SelectionTabs } from './SelectionTabs'
export function ReadmePanel() {
  return <Section title="Verify the README">
    <Prose><p>The README is the entry point. Link detailed procedures when a short section would hide conditions. The outline below has project facts you must supply and check.</p></Prose>
    <div className="mt-5"><DocumentExample example={README} /></div>
    <div className="mt-5"><RevealList idPrefix="documentation-readme" rows={[{ id: 'fresh', title: 'Fresh-clone check', body: <div><p>Try a fresh clone without private instructions. Record revision, prerequisites, configuration source, commands and expected result. The first unresolved step becomes a fix.</p><p className="mt-3">A listed command is not evidence that anyone ran it. <Link href="/stages/04-project-setup">Stage 04 owns setup</Link>; use <Link href="/stages/13-production-deployment">Stage 13 for releases</Link>, <Link href="/stages/14-post-deployment-verification">Stage 14 for recovery checks</Link> and <Link href="/stages/16-incident-management">Stage 16 for incidents</Link>.</p></div> }]} /></div>
  </Section>
}
export function DecisionsPanel() {
  const root = useRef<HTMLDivElement>(null)
  function select(target: 'old' | 'replacement') {
    const tab = root.current?.querySelector<HTMLButtonElement>(`[data-selection-id="${target}"]`)
    tab?.click(); tab?.focus()
  }
  return <Section title="Replace a decision without rewriting its history">
    <Prose><p>A significant boundary, dependency, interface or deployment choice earns an <Term id="adr">ADR</Term>. Start with one page; include the reasons and consequences. Use sequential docs/adr/NNN-title.md names without reusing a number.</p><p>These are illustrative Workshop records. Preserve the old reasoning, append a dated current-status notice, link both records and update any existing decision index.</p></Prose>
    <div ref={root} className="mt-5">
      <SelectionTabs label="Decision records" items={([
        ['old', 'ADR 004'], ['replacement', 'ADR 005'], ['template', 'Blank template'],
      ] as const).map(([id, label]) => ({ id, label, content: <div>
        <DocumentExample example={ADRS[id]} relatedControl={ADRS[id].related && <button type="button" onClick={() => select(ADRS[id].related!.target)} className="mt-3 min-h-11 border border-line px-4 text-sm">Read {ADRS[id].related!.label}</button>} />
      </div> }))} />
    </div>
    <div className="mt-5"><RevealList idPrefix="documentation-status" rows={[
      { id: 'format', title: 'Format and status', body: <div><p>Use Context, Decision, Reasoning, Consequences and Alternatives with a date. Proposed means under consideration; Rejected preserves a declined proposal&apos;s reason; Accepted means adopted; Superseded links to a later replacement.</p><p className="mt-3">Proposals can change during review. Accepted historical reasons stay. The later notice states current status, while the original acceptance remains historical.</p><p className="mt-3"><a href="https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions">Nygard&apos;s ADR guidance</a> explains small decision records. The appended notice is this playbook&apos;s preservation convention.</p></div> },
    ]} /></div>
  </Section>
}
```

- [ ] **Step 4: Focused GREEN, lint and typecheck.** The Step 1 assertions cover copying the selected replacement and exclude the status legend from its Markdown.
- [ ] **Step 5: Teeth check.** Omit only the old specimen's Supersession notice block in DocumentExample rendering; the scoped old-ADR test must fail despite the intact status legend. Restore and rerun GREEN. Copy remains sourced from the same document model.
- [ ] **Step 6: Independent review and commit** `feat(documentation): teach readme checks and adr replacement`. Deferred: reference/change inspectors and registration.

