const fs=require('fs'),path=require('path');
const root=process.cwd(),web=path.join(root,'web'),out=path.join(root,'.superpowers/sdd/2026-10-20-stage-10-interactive-port/final-fix-evidence');
const {chromium,expect}=require(web+'/node_modules/@playwright/test');
const widths=[320,390,768,1024,1440,1920,2560],rows=[],errors=[],pairs=new Map(),keyResults=[];
async function measure(page,meta){await page.evaluate(()=>document.fonts.ready);const m=await page.evaluate(()=>{
const panel=document.querySelector('main > *')||document.querySelector('main');
const visible=e=>e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0&&getComputedStyle(e).visibility!=='hidden';
const cv=document.createElement('canvas');cv.width=cv.height=1;const ctx=cv.getContext('2d',{willReadFrequently:true});
const raster=(color,bg)=>{ctx.fillStyle=`rgb(${bg})`;ctx.fillRect(0,0,1,1);ctx.fillStyle=color;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data].slice(0,3)};
const bgUnder=e=>{const chain=[];for(let n=e;n;n=n.parentElement)chain.unshift(n);let bg=[255,255,255];for(const n of chain)bg=raster(getComputedStyle(n).backgroundColor,bg);return bg};
const colors=new Map();for(const e of document.querySelectorAll('main *')){if(!visible(e))continue;const cs=getComputedStyle(e);if(+cs.opacity<0.5||e.closest(':disabled'))continue;let text=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();if(e.matches('input,textarea'))text=e.value||e.placeholder||text;if(text.length<1)continue;const bg=bgUnder(e),fg=raster(cs.color,bg),size=parseFloat(cs.fontSize),weight=parseInt(cs.fontWeight)||400,key=[fg,bg,size,weight].join('|');if(!colors.has(key))colors.set(key,{fg,bg,size,weight,sample:text.slice(0,120)});}
const inline=e=>{const sentence=e.closest('p,li');if(!sentence)return false;let n=e;while(n&&n!==sentence){if([...n.parentElement.childNodes].some(c=>c.nodeType===3&&c.textContent.trim()))return true;n=n.parentElement;}return false;};
const targets=[...document.querySelectorAll('main a,main button,main input,main textarea')].filter(visible).map(e=>{const b=e.getBoundingClientRect();return {name:e.getAttribute('aria-label')||(e.labels&&[...e.labels].map(l=>l.textContent).join(' '))||e.textContent||e.placeholder||'',height:b.height,width:b.width,tag:e.tagName,exempt:inline(e)||e.classList.contains('sr-only')};});
const active=document.querySelector('[id^="panel-"][role="tabpanel"]');
return {fields:[...document.querySelectorAll('main textarea')].filter(visible).map(e=>({name:[...e.labels].map(l=>l.textContent).join(' '),readonly:e.readOnly,value:e.value})),feedback:[...document.querySelectorAll('main [role=status]')].filter(visible).map(e=>e.textContent),warning:[...document.querySelectorAll('main .text-warn')].filter(visible).map(e=>e.textContent),overflow:document.documentElement.scrollWidth-innerWidth,screenWidth:innerWidth,panelHeight:active?.getBoundingClientRect().height,colors:[...colors.values()],targets};});
const lum=c=>c.map(v=>v/255).map(v=>v<=.03928?v/12.92:((v+.055)/1.055)**2.4).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
for(const c of m.colors){const a=lum(c.fg),b=lum(c.bg);c.ratio=(Math.max(a,b)+.05)/(Math.min(a,b)+.05);c.need=c.size>=24||(c.size>=18.66&&c.weight>=700)?3:4.5;pairs.set(`${meta.theme}|${c.fg}|${c.bg}|${c.size}|${c.weight}`,c);}
const result={...meta,...m,contrastFailures:m.colors.filter(c=>c.ratio<c.need),smallTargets:meta.width<1024?m.targets.filter(t=>(t.height<43.99||t.width<43.99)&&!t.exempt):[]};rows.push(result);if(result.overflow>0||result.contrastFailures.length||result.smallTargets.length)console.log('FINDING '+JSON.stringify({meta,overflow:result.overflow,contrast:result.contrastFailures,small:result.smallTargets}));
fs.writeFileSync(path.join(out,'matrix-progress.json'),JSON.stringify({last:meta,count:rows.length}));
}
async function keyboard(page,id,meta){const inner=page.locator(`#panel-${id} [role=tablist]`).first();if(await inner.count()){const tabs=inner.getByRole('tab');await tabs.first().focus();await tabs.first().press('End');const end=await tabs.last().getAttribute('aria-selected');await tabs.last().press('Home');const home=await tabs.first().getAttribute('aria-selected');await tabs.first().press('ArrowRight');const right=await tabs.nth(1).getAttribute('aria-selected');await tabs.nth(1).press('ArrowLeft');const left=await tabs.first().getAttribute('aria-selected');keyResults.push({...meta,id,kind:'tabs End Home Right Left',end,home,right,left,focus:await page.evaluate(()=>{const e=document.activeElement,c=getComputedStyle(e);return {text:e.textContent,outline:c.outline,boxShadow:c.boxShadow}})});}
const dis=page.locator(`#panel-${id} button[aria-expanded]`).first();if(await dis.count()){const before=await dis.getAttribute('aria-expanded');await dis.focus();await dis.press('Enter');const enter=await dis.getAttribute('aria-expanded');await dis.press('Space');keyResults.push({...meta,id,kind:'disclosure Enter Space',before,enter,after:await dis.getAttribute('aria-expanded'),focus:await dis.evaluate(e=>({outline:getComputedStyle(e).outline,boxShadow:getComputedStyle(e).boxShadow}))});}}
(async()=>{const browser=await chromium.launch({headless:true});
for(const theme of ['light','dark'])for(const width of widths){
 const context=await browser.newContext({viewport:{width,height:768},colorScheme:theme});
 await context.addInitScript(theme=>localStorage.setItem('playbook:theme',JSON.stringify(theme)),theme);
 const page=await context.newPage();page.on('pageerror',e=>errors.push({theme,width,type:'pageerror',text:e.message}));page.on('console',m=>{if(m.type()==='error')errors.push({theme,width,type:'console',text:m.text()})});
 await page.goto('http://localhost:3100/stages/10-documentation#reference',{waitUntil:'networkidle'});
 await expect(page.locator('html')).toHaveAttribute('data-theme',theme);
 const panel=page.locator('#panel-reference');
 for(const pattern of [/reference.*exact names, types, allowed values and defaults/i,/tutorials guide a learning exercise/i,/explanations cover concepts and reasons/i])await expect(panel.getByText(pattern)).toBeVisible();
 const tabs=panel.locator('[data-selection-id]');expect(await tabs.count()).toBe(2);
 await keyboard(page,'reference',{theme,width});
 for(let i=0;i<await tabs.count();i++){
  await tabs.nth(i).click();await expect(tabs.nth(i)).toHaveAttribute('aria-selected','true');
  for(const pattern of [/reference.*exact names, types, allowed values and defaults/i,/tutorials guide a learning exercise/i,/explanations cover concepts and reasons/i])await expect(panel.getByText(pattern)).toBeVisible();
  const selection=await tabs.nth(i).getAttribute('data-selection-id');await measure(page,{theme,width,id:'reference',state:selection});
  await page.screenshot({path:path.join(out,`${theme}-${width}-${selection}.png`),fullPage:true});
 }
 await context.close();console.log(`COMPLETED ${theme} ${width}`);
}
fs.writeFileSync(path.join(out,'reference-matrix.json'),JSON.stringify({rows,errors,keyResults,distinctPairs:[...pairs.values()]},null,2));
const failures=rows.filter(r=>r.overflow>0||r.contrastFailures.length||r.smallTargets.length),D52=rows.filter(r=>r.width===1024).map(r=>({theme:r.theme,state:r.state,height:r.panelHeight,screens:r.panelHeight/768}));
for(const k of keyResults){expect(k.end).toBe('true');expect(k.home).toBe('true');expect(k.right).toBe('true');expect(k.left).toBe('true');expect(k.focus.outline).not.toMatch(/none|0px/);}
expect(rows.length).toBe(28);expect(errors).toEqual([]);expect(failures).toEqual([]);for(const d of D52)expect(d.screens).toBeLessThanOrEqual(4);
const summary={measurements:rows.length,contexts:14,selections:2,themes:2,widths,distinctPairs:pairs.size,failures:failures.length,consoleErrors:errors.filter(e=>e.type==='console').length,pageErrors:errors.filter(e=>e.type==='pageerror').length,D52,keyboardCases:keyResults.length,keyboardActions:keyResults.length*4,screenshots:rows.length};
fs.writeFileSync(path.join(out,'reference-summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1});
