# Setup observations

The first evidence-directory attempt used the web working directory with repository-relative paths and failed before writing source or running a test. The corrected root was the parent directory. A shell wrapper then assigned zsh's read-only status variable after the actual RED run; the test output remained captured. The rerun uses run_exit and confirms the same meaningful missing-classification failure. Neither wrapper error is TDD evidence.

The first draft of the test used toBeVisible, which this repository does not install as a Vitest matcher. Before any source edit, the assertion was changed to the existing suite's getByText plus toBeTruthy pattern and RED was rerun. Real visibility is separately asserted by Playwright in the final affected-panel matrix.

The previous 3100 listener PID 49997 was absent at initial inspection; port 3100 was free. The parent 3200 listener remained PID 93201. The sandbox denied ps; the authorized read-only escalated process inspection confirmed the absence of 49997. No server was killed at that stage.
