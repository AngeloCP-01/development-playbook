import { fireEvent, render, screen } from '@testing-library/react'
import { expect, test } from 'vitest'
import { LookupInspector } from './LookupInspector'
import { CHANGES, FACTS } from './lookups'
test('keyboard reaches every authored change and reference detail', () => {
  for (const entries of [CHANGES, FACTS]) {
    const view = render(<LookupInspector title="Keyboard probe" entries={entries} />)
    const tabs = screen.getByRole('tablist')
    for (const entry of entries) {
      const panel = screen.getByRole('tabpanel', { name: entry.label })
      expect(panel.textContent).toContain(entry.summary)
      for (const fact of entry.details) expect(panel.textContent).toContain(fact.text)
      fireEvent.keyDown(tabs, { key: 'ArrowRight' })
    }
    expect(screen.getByRole('tabpanel', { name: entries[0].label })).toBeTruthy()
    view.unmount()
  }
})
