# Stage 10 fresh lookup assessment

Assessment started 2026-10-22; report completed 2026-10-23 after the session interruption. Teaching source: the visible public UI at `http://localhost:3100/stages/10-documentation#choose`. This is a lookup assessment, not a production-readiness or accessibility audit.

I read only the brief, its two case/question files, and the Browser skill. The configured Playwright MCP fallback was used as directed. I did not inspect source, chapter Markdown, other reports, browser bundles, private state, network bodies, or external links. The controller supplied BUILD_ID `YDyl-9Cl-MRjn8rpkfEza`; I did not independently inspect build internals.

## Supplied case (verbatim)

Toolshare is a neighborhood tool-lending web app. Members reserve tools and volunteers record pickup and return. One maintainer built it; a second volunteer should be able to run it locally, understand the system boundary, and support a release without private instructions. A change replaces direct reminder-email sending with a durable queue after provider timeouts caused uncertain delivery. The old architectural decision to send directly remains in the repository. The same change adds REMINDER_QUEUE_URL, changes a documented retry option from 3 attempts to 5, and adds a new reminder-status response field. Toolshare wants the smallest useful documentation set and must not publish member contact details or real credentials. No framework, actual commands, URL, credentials, tests, deployment platform or measured incident outcomes are supplied.

## First-load guard and scoring

The first navigation used `page.goto` through the permitted code tool, waited for the visible `Stage steps` tablist, and returned only tab labels and their public `aria-controls` values. No body or panel snapshot was returned. I then wrote `port-reader-lookup-first-choices.md` before reading any panel body. The returned rail exposed labels, not descriptive hints. Frozen choices remain unchanged.

| Question | Frozen first-choice label | Score |
| --- | --- | --- |
| 1 | 02 Verify the README | HIT |
| 2 | 03 Replace a decision | HIT |
| 3 | 04 State exact facts | MISFILED |
| 4 | 06 Trace the change | HIT |
| 5 | 08 Check the evidence | HIT |

HIT means the first-choice panel supplies the answer through its visible controls. MISFILED here means a sufficient explicit answer was found elsewhere. Q3's first panel supplies a useful reference example, but the direct document-type distinction is in another panel; this is a minor lookup issue, not missing teaching.

## 1. A second maintainer cannot run the app from a fresh clone. Where do I find what the setup guide must include and how to verify it?

**Score: HIT.** Navigation: `02 Verify the README` → `Fresh-clone check`.

The panel calls the README the entry point and says to link detailed procedures when a short section would hide conditions. Its `README.md outline` visibly includes:

- Project purpose, users, and smallest useful outcome.
- Supported prerequisites and tool versions; access and safe configuration source; clone, install and startup commands tested for the revision; expected result and first useful check.
- Current scope, boundaries and external dependencies; links to decisions.
- Release and rollback procedure links, permissions and compatibility limits; logs and health checks; responsible maintainer or support route.

The expanded `Fresh-clone check` says: “Try a fresh clone without private instructions. Record revision, prerequisites, configuration source, commands and expected result. The first unresolved step becomes a fix.” It also states: “A listed command is not evidence that anyone ran it.” Visible links allocate setup, releases, recovery checks and incidents to Stages 04, 13, 14 and 16 respectively; I did not follow them.

**Answer for Toolshare:** put the runnable entry path in the README, with linked longer procedures where needed. Have the second volunteer follow the fresh-clone path without private instructions and record the stated evidence. Supply Toolshare's real commands, prerequisites, safe access route and observable result rather than copying placeholders.

**Remaining omissions:** no teaching gap observed. Toolshare's commands, versions, configuration-access route, responsible contact and expected result are unsupplied scenario facts. This UI cannot establish that Toolshare actually runs.

## 2. We replaced an earlier architecture decision. What should I write now, and how does a reader discover that the old decision no longer applies?

**Score: HIT.** Navigation: `03 Replace a decision` → `Read ADR 005` → `Format and status` → `Blank template`. The initially visible record was `ADR 004`; these are illustrative Workshop records, not Toolshare decisions.

The panel directs a significant boundary, dependency, interface or deployment choice into a small ADR with sequential `docs/adr/NNN-title.md` names, without reusing numbers. Its instruction is: “Preserve the old reasoning, append a dated current-status notice, link both records and update any existing decision index.”

The old example visibly retains its original `Status: Accepted`, Context, Decision and Consequences, then separately shows `Supersession notice (appended)` and “2026-10-20 — Current status: Superseded.” Its `Replacement: ADR 005` is accompanied by `Read ADR 005`. The replacement shows `Status: Accepted`, `Supersedes: ADR 004`, a `Read ADR 004` button, and Context, Decision, Reasoning, Consequences and Alternatives. The blank template also requires an actual date and status.

`Format and status` distinguishes Proposed, Rejected, Accepted and Superseded. It explicitly says the later notice states current status while the original acceptance remains historical.

**Answer for Toolshare:** write a new sequential ADR for durable queued reminders. Record the supplied timeout/uncertain-delivery context, actual decision, reasons, consequences, alternatives and actual date/status. Link back to the direct-send ADR. Preserve the old reasoning and append its dated Superseded notice with a link to the new ADR; update an existing decision index. The old record's replacement link and notice make the changed status discoverable.

**Remaining omissions:** no teaching gap observed. Toolshare's ADR numbers, exact date, evaluated alternatives and operational consequences must come from its actual decision. The case does not prove improved delivery or recovery; none should be invented.

## 3. A user needs the exact allowed values and defaults for a retry option. Should that live in a tutorial, reference page or explanation?

**Score: MISFILED.** Frozen navigation: `04 State exact facts`. Recovery navigation: `Choose a document` → `Look up facts`; I also selected `Understand a choice`. `Learn a skill` was the initially visible reader-need selection in that panel.

The first panel has `Illustrative Workshop reference`, with a selected `BOOKING_WINDOW_DAYS` tab. It shows `Shape: integer 1–365`, `Default or absence: 30 when unset`, a versioned validator as Source, and Maintainer / validator change as Owner / trigger. It also says to record applicable version and authoritative source, distinguish absent/null/empty according to the actual contract, and not mistake generation for source correctness. This demonstrates the content of a reference well, but does not explicitly distinguish the three document types in the question.

The sufficient explicit answer is in `Choose a document` → `Look up facts`: “Reference: find exact names, types, allowed values and absence behavior.” Its example is “Look up a setting default or an optional response field.” In the same reader-need tablist, `Learn a skill` says “Tutorial: learn through a guided exercise,” and `Understand a choice` says “Explanation: understand a concept or reason.”

**Answer for Toolshare:** use a reference page for the retry option's exact supported values and default, tied to its authoritative source and applicable version. A tutorial serves a guided learning exercise; explanation serves the reasons behind a concept or choice. The supplied change from 3 attempts to 5 does not by itself specify every allowed value, absence behavior, or whether that number is a default or a fixed limit; confirm those against the actual implementation and tests.

**Remaining omissions:** the teaching exists in the port; finding M1 concerns its location. Toolshare's full retry contract remains an unsupplied project fact.

## 4. This change adds configuration and a response field. Which documents need updates, who owns them, and what checks detect drift?

**Score: HIT.** Navigation: `06 Trace the change` → `Configuration` (initially selected) → `Does configuration enforce itself?` → `What does automation establish?` → `Response contract` → `Default or allowed value` → `Boundary or dependency` → `Setup or release procedure` → `Known failure or release`.

The introduction says: “When working alone, you are the owner. Give each living document a review trigger.” The visible mappings supply both direct parts of the question and the other changes in the Toolshare case:

| Visible control | Documents shown | Owner / trigger shown | Check shown |
| --- | --- | --- | --- |
| Configuration | Configuration reference, `.env.example` and setup guide | Maintainer / validator change | Compare accepted values/default with validation; test missing/invalid values |
| Response contract | Generated reference and example response | Contract owner / response change | Run generation, inspect expected diff and verify optional-field omission |
| Default or allowed value | Existing reference and relevant how-to | Maintainer / option change | Find old values and check new behavior, not only matching strings |
| Boundary or dependency | Architecture view, ADR and affected runbook | Area owner / boundary change | Trace affected relationships and replacement links |
| Setup or release procedure | README and linked procedures | Maintainer / procedure change | Follow documented path safely and record result |
| Known failure or release | Troubleshooting, changelog or release notes as needed | Maintainer / confirmed fix or release | Verify check/workaround and publish only supported impact claims |

The configuration example's numeric range/default belong to Workshop, not to `REMINDER_QUEUE_URL`. Its Source is the startup validator and unset/invalid behavior. The response Source is the schema and serializer behavior. The expanded configuration disclosure says `.env.example` lists configuration, whereas a validator enforces values only if the application invokes it; it explicitly calls for safe placeholders, never real credentials. The automation disclosure says types check some shapes, tests cover their assertions, generation follows its input, and the check must match the claim.

**Answer for Toolshare:** update the configuration reference, safe `.env.example` and setup path for `REMINDER_QUEUE_URL`; update the response reference and example against the actual schema/serializer; update the retry reference and relevant how-to; review the architecture view, replacement ADR and affected runbook for the queue boundary. Update release/troubleshooting material only as the confirmed change requires. Assign the visible maintainer/contract/area ownership roles explicitly; in the current solo arrangement the maintainer owns the work. Use validator behavior, response generation/diff review where a generator exists, omission checks when applicable, old-value searches plus behavioral checks, relationship/replacement-link tracing, and a safely followed procedure.

**Remaining omissions:** no teaching gap observed. The UI's Workshop example uses generated reference, but the Toolshare case supplies no generator; the example is not evidence that one exists. Actual validator constraints, required/optional response semantics, owner identities, check commands and run results must be obtained from Toolshare. No specific framework or deployment tool is justified by this case.

## 5. An AI assistant drafted documentation claiming a fix was validated. What evidence must I check before publishing it?

**Score: HIT.** Navigation: `08 Check the evidence` → `Ground and review the draft` → `Record the limits of validation`. I then completed all three visible cases with the matching `Read`, `Compile` and `Execute` radio choices, `Check answer`, and `Next case` controls. All three displayed `Correct` with explanatory feedback.

The panel asks for the source and version in scope and tells the assistant to label missing facts. `Ground and review the draft` requires a named reviewer to compare the draft against the relevant diff, contract, code, verified procedure or approved notes. It requires synthetic identifiers and removal of real credentials, contact details and private payloads. Permissions, limits, defaults, provider behavior, incident outcomes and release promises need traceable sources; template infrastructure/test claims must be replaced with project facts.

The practice distinguishes these claims:

- Read: comparison with an identified source; not compilation or execution.
- Compile: stated compiler/type checks for that example; not a successful procedure or production behavior.
- Execute: command, revision, environment and observed result; an isolated run does not establish production recovery.

`Record the limits of validation` repeats the execution evidence fields and says an assistant needs the same evidence as anyone else. It links production verification to Stage 14; I did not follow that link. The practice's sample commands and revisions are explicitly hypothetical, not Toolshare evidence.

**Answer for Toolshare:** check who reviewed the draft, which actual source/version supports each claim, what validation was performed, and its recorded limits. For claimed execution, require the real command, revision, environment and observed result. Do not publish a production-recovery or incident-outcome claim based on a comparison, compiler pass, isolated example, or the assistant's assertion. Remove member contact details, real credentials and private payloads before publication.

**Remaining omissions:** no teaching gap observed. The case provides no validation run, tests, measured outcomes or production environment. “Validated” is unsupported until that evidence is supplied; it cannot be filled by the illustrative practice.

## Findings

**M1 — Minor: the explicit document-type choice is outside the first location suggested by the exact-facts lookup.** The frozen Q3 choice was `04 State exact facts`. That panel provides a strong reference example, including allowed range and default, but the explicit “Reference: find exact names, types, allowed values and absence behavior” classification and tutorial/explanation distinction require returning to `Choose a document` and using its reader-need tabs. This added one panel change and a reader-need selection. A visible cross-link or short distinction in `State exact facts` would complete this lookup locally. The port does teach the answer; this is not a missing-content finding.

No Critical or Important findings were observed in these five lookups. No scenario-specific unknown above is counted as a teaching defect.

## Instrument limits and closeout

One generic tabpanel snapshot failed because the decision panel contains a nested tabpanel; it returned an ambiguity error, not content. I then targeted the already observed public stage-panel ID. One return navigation using the initially captured numbered label timed out; a fresh visible rail inspection showed previously visited tabs named without their leading number, and `Choose a document` worked. Neither failure blocked the assessment or was silently counted as an answer.

I did not inspect every Stage 10 panel, follow cross-stage/external links, verify Toolshare implementation, run checks against Toolshare, or treat illustrative Workshop facts as project facts. The assessment covers the five supplied lookup questions through public controls.

The owned MCP page was closed at completion. The close tool returned `No open tabs. Navigate to a URL to create one.` No builds, commits, application edits or subagents were used. Only the named first-choice and report files were written.
