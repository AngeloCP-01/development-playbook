# Task 3 report: accessible selection and reliable copying

**Status:** DONE

**Commit:** `a90f45e` — `feat(documentation): add selection and copy controls`

Implemented the planned `CopyMarkdown` and `SelectionTabs` components and render tests. Copy status is associated with current text; denied or missing clipboard access exposes current literal Markdown for manual copying; stale results are ignored. Tabs expose named, associated panels and support ArrowLeft, ArrowRight, Home, and End with focus movement.

## TDD evidence

Tests were written before implementation. The initial import-resolution RED (modules absent) was followed by this meaningful behavioral RED against minimal `null` shells:

```text
> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/SelectionTabs.test.tsx (1 test | 1 failed) 64ms
 ❯ |dom| src/features/documentation/CopyMarkdown.test.tsx (4 tests | 4 failed) 71ms
   × copies exactly the current text and stops describing old content as copied after an edit
   × denied or missing clipboard access offers current literal Markdown for manual copying
   × an older rejected operation cannot replace a newer successful copy
   × an empty record can disable export without creating a false status

 FAIL CopyMarkdown: Unable to find an accessible element with the role "button"
 FAIL SelectionTabs: Unable to find an accessible element with the role "tab" and name "Old"

 Test Files  2 failed (2)
      Tests  5 failed (5)
```

The failures were for the expected reason: the shells rendered no buttons, status, tabs, or panels, so none of the tested visible contracts existed.

Focused GREEN after implementation:

```text
> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

 Test Files  2 passed (2)
      Tests  5 passed (5)
   Start at  10:27:07
   Duration  1.01s (transform 81ms, setup 246ms, import 61ms, tests 190ms, environment 1.28s)
```

## Teeth checks

1. Removed the sequence guard only from the clipboard rejection branch. The out-of-order test alone failed because the older denial replaced the newer success:

```text
> pnpm test src/features/documentation/CopyMarkdown.test.tsx -t 'an older rejected operation cannot replace a newer successful copy'

 ❯ |dom| src/features/documentation/CopyMarkdown.test.tsx (4 tests | 1 failed | 3 skipped) 70ms
AssertionError: expected 'Copy is unavailable. Select the curre…' to contain 'Copied this version'
Expected: "Copied this version"
Received: "Copy is unavailable. Select the current Markdown below and copy it manually."
      Tests  1 failed | 3 skipped (4)
```

2. Forced the panel to render `items[0].content`. The keyboard/content test alone failed after ArrowRight:

```text
> pnpm test src/features/documentation/SelectionTabs.test.tsx -t 'each choice exposes its own named panel and keyboard navigation moves both focus and content'

 ❯ |dom| src/features/documentation/SelectionTabs.test.tsx (1 test | 1 failed) 78ms
AssertionError: expected 'Old content' to be 'New content' // Object.is equality
Expected: "New content"
Received: "Old content"
      Tests  1 failed (1)
```

Both mutations were restored. The focused tests then passed 5/5 again; final full-suite verification is below.

## Verification

```text
> pnpm lint
> eslint --max-warnings 0
```

```text
> pnpm typecheck
> next typegen && tsc --noEmit

Generating route types...
✓ Types generated successfully
```

Initial `pnpm format:check` reported formatting issues in the four new files. Ran Prettier on those paths, then:

```text
> pnpm format:check
> prettier --check .

Checking formatting...
All matched files use Prettier code style!
```

The first full-suite invocation yielded after 30 seconds and its session id was not retained, so completion could not be checked. The tracked rerun completed successfully:

```text
> pnpm test
> vitest run

 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 Test Files  212 passed (212)
      Tests  1532 passed (1532)
   Start at  10:29:12
   Duration  30.06s (transform 15.24s, setup 16.37s, import 46.59s, tests 43.48s, environment 72.31s)
```

## Changed files and self-review

- `web/src/features/documentation/CopyMarkdown.tsx`
- `web/src/features/documentation/CopyMarkdown.test.tsx`
- `web/src/features/documentation/SelectionTabs.tsx`
- `web/src/features/documentation/SelectionTabs.test.tsx`

Read the formatted sources after restoring both mutations. Tests exercise rendered user behavior. APIs and semantic tokens match the task brief. No shared helper or other feature was changed. Independent review is the controller's next step.

The raw staged diff is preserved in `task-3.patch` beside this report. `git diff --cached --check` passed. Only the four listed source/test files are staged for commit; this report and patch remain untracked for separate archival. Deferred: document examples and personal forms.

## Supplemental teeth evidence: both focused files per mutation

The controller requested a second pass without `-t`, so the untouched component suite also had to pass during each mutation. Each run below used the complete focused command and exited 1 with exactly one failed test and four passing tests. Each source file was restored before applying the next mutation.

### Copy rejection sequence guard

Mutation diff:

```diff
diff --git a/web/src/features/documentation/CopyMarkdown.tsx b/web/src/features/documentation/CopyMarkdown.tsx
index 26d9f64..cec9a9b 100644
--- a/web/src/features/documentation/CopyMarkdown.tsx
+++ b/web/src/features/documentation/CopyMarkdown.tsx
@@ -23,7 +23,7 @@ export function CopyMarkdown({
       await navigator.clipboard.writeText(text)
       if (sequence === attempt.current) setResult({ text, manual: false })
     } catch {
-      if (sequence === attempt.current) setResult({ text, manual: true })
+      setResult({ text, manual: true })
     }
   }
```

Command and raw output (exit code 1):

```text
> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/CopyMarkdown.test.tsx (4 tests | 1 failed) 137ms
   × an older rejected operation cannot replace a newer successful copy 9ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/CopyMarkdown.test.tsx > an older rejected operation cannot replace a newer successful copy
AssertionError: expected 'Copy is unavailable. Select the curre…' to contain 'Copied this version'

Expected: "Copied this version"
Received: "Copy is unavailable. Select the current Markdown below and copy it manually."

 Test Files  1 failed | 1 passed (2)
      Tests  1 failed | 4 passed (5)
   Start at  10:33:36
   Duration  1.08s (transform 66ms, setup 218ms, import 46ms, tests 253ms, environment 1.17s)

 ELIFECYCLE  Command failed with exit code 1.
```

Restoration check: `git diff --exit-code HEAD -- web/src/features/documentation/CopyMarkdown.tsx` exited 0. The working-file and committed-source SHA-256 values both equaled `37f493a0c53c5a4476c3bbf0bcb5fa3aff57764ab7f05ab5065c617ee0b613e1`.

### Selected tab panel content

Mutation diff:

```diff
diff --git a/web/src/features/documentation/SelectionTabs.tsx b/web/src/features/documentation/SelectionTabs.tsx
index 25ac832..09ac380 100644
--- a/web/src/features/documentation/SelectionTabs.tsx
+++ b/web/src/features/documentation/SelectionTabs.tsx
@@ -62,7 +62,7 @@ export function SelectionTabs({
         tabIndex={0}
         className="min-w-0 focus-visible:outline-2 focus-visible:outline-brand"
       >
-        {items[index].content}
+        {items[0].content}
       </div>
     </div>
```

Command and raw output (exit code 1):

```text
> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx

 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/SelectionTabs.test.tsx (1 test | 1 failed) 79ms
   × each choice exposes its own named panel and keyboard navigation moves both focus and content 78ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/SelectionTabs.test.tsx > each choice exposes its own named panel and keyboard navigation moves both focus and content
AssertionError: expected 'Old content' to be 'New content' // Object.is equality

Expected: "New content"
Received: "Old content"

 Test Files  1 failed (1)
      Tests  1 failed | 4 passed (5)
   Start at  10:33:57
   Duration  1.04s (transform 84ms, setup 347ms, import 50ms, tests 189ms, environment 1.27s)

 ELIFECYCLE  Command failed with exit code 1.
```

Restoration check: `git diff --exit-code HEAD -- web/src/features/documentation/SelectionTabs.tsx` exited 0. The working-file and committed-source SHA-256 values both equaled `80ec95182d42290bbc6108f4efc1c8062b81ccbfe7261bf1d0dfa201d2d66063`.

No source changes remain from either mutation; no files were staged and no commit was created during this supplemental pass.

## Saved raw rerun for SelectionTabs mutation

The SelectionTabs mutation output is retained verbatim in `task-3-selection-mutation.log`; its exit code is in `task-3-selection-mutation.exit` (`1`). This saved rerun clarifies the full two-file summary. The earlier excerpt in this report was not retained as a raw log; use the saved `.log` as the authoritative record.

```text

> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx
> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/SelectionTabs.test.tsx (1 test | 1 failed) 236ms
   × each choice exposes its own named panel and keyboard navigation moves both focus and content 235ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/SelectionTabs.test.tsx > each choice exposes its own named panel and keyboard navigation moves both focus and content
AssertionError: expected 'Old content' to be 'New content' // Object.is equality

Expected: "New content"
Received: "Old content"

 ❯ src/features/documentation/SelectionTabs.test.tsx:21:69
     19|   fireEvent.keyDown(old, { key: 'ArrowRight' })
     20|   expect(document.activeElement).toBe(next)
     21|   expect(screen.getByRole('tabpanel', { name: 'New' }).textContent).to…
       |                                                                     ^
     22|     'New content',
     23|   )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed | 1 passed (2)
      Tests  1 failed | 4 passed (5)
   Start at  10:35:30
   Duration  2.21s (transform 201ms, setup 1.20s, import 133ms, tests 543ms, environment 2.07s)

 ELIFECYCLE  Command failed with exit code 1.
```

After restoration, the component file hash matched HEAD: `80ec95182d42290bbc6108f4efc1c8062b81ccbfe7261bf1d0dfa201d2d66063` (working file and `git show HEAD:...` each produced this value), and `git diff --exit-code HEAD -- web/src/features/documentation/SelectionTabs.tsx` exited 0.

Restored focused GREEN raw output is retained in `task-3-selection-restored-green.log`; exit code is in `task-3-selection-restored-green.exit` (`0`):

```text

> pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx
> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  2 passed (2)
      Tests  5 passed (5)
   Start at  10:35:47
   Duration  1.31s (transform 88ms, setup 380ms, import 70ms, tests 314ms, environment 1.51s)
```

The product source is restored byte-for-byte. No files were staged and no commit was created during the rerun.
