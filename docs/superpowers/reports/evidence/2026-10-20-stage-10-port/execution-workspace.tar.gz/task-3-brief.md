### Task 3: Provide accessible selection and reliable copying

**Files:** Create `CopyMarkdown.tsx`, `CopyMarkdown.test.tsx`, `SelectionTabs.tsx`, `SelectionTabs.test.tsx`.

**Interfaces:** `CopyMarkdown({ text, label?, manualLabel?, disabled? })` is
stage-local. `SelectionTabs({ label, items })` accepts readonly
`{ id: string; label: string; content: ReactNode }[]`; a unique nonempty item
set is authored by its callers. No callback prop crosses a server boundary.

- [ ] **Step 1: Write both test files.** `CopyMarkdown.test.tsx`:

```tsx
import { act, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, beforeEach, expect, test, vi } from 'vitest'
import { CopyMarkdown } from './CopyMarkdown'
let write = vi.fn<(text: string) => Promise<void>>()
beforeEach(() => { write = vi.fn<(text: string) => Promise<void>>().mockResolvedValue(undefined); vi.stubGlobal('navigator', { clipboard: { writeText: write } }) })
afterEach(() => vi.unstubAllGlobals())
test('copies exactly the current text and stops describing old content as copied after an edit', async () => {
  const view = render(<CopyMarkdown text="First" />)
  await act(async () => { fireEvent.click(screen.getByRole('button')) })
  expect(write).toHaveBeenCalledWith('First'); expect(screen.getByRole('status').textContent).toContain('Copied this version')
  view.rerender(<CopyMarkdown text="Second" />)
  expect(screen.getByRole('status').textContent).toBe('')
})
test('denied or missing clipboard access offers current literal Markdown for manual copying', async () => {
  for (const missing of [false, true]) {
    if (missing) vi.stubGlobal('navigator', {})
    else write.mockRejectedValue(new Error('denied'))
    const view = render(<CopyMarkdown text="<script>literal</script>" />)
    await act(async () => { fireEvent.click(screen.getByRole('button')) })
    const manual = screen.getByLabelText('Markdown record') as HTMLTextAreaElement
    expect(manual.readOnly).toBe(true); expect(manual.value).toBe('<script>literal</script>')
    expect(view.container.querySelector('script')).toBeNull()
    view.rerender(<CopyMarkdown text="Edited draft" />)
    expect((screen.getByLabelText('Markdown record') as HTMLTextAreaElement).value).toBe('Edited draft')
    view.unmount()
  }
})
test('an older rejected operation cannot replace a newer successful copy', async () => {
  let rejectOld!: (reason: unknown) => void
  write.mockImplementationOnce(() => new Promise<void>((_, reject) => { rejectOld = reject }))
  render(<CopyMarkdown text="Current" />)
  fireEvent.click(screen.getByRole('button'))
  await act(async () => { fireEvent.click(screen.getByRole('button')) })
  await act(async () => rejectOld(new Error('old denial')))
  expect(screen.getByRole('status').textContent).toContain('Copied this version')
  expect(screen.queryByRole('textbox')).toBeNull()
})
test('an empty record can disable export without creating a false status', () => {
  render(<CopyMarkdown text="Empty" disabled />)
  expect((screen.getByRole('button') as HTMLButtonElement).disabled).toBe(true)
  expect(screen.getByRole('status').textContent).toBe('')
})
```

`SelectionTabs.test.tsx`:

```tsx
import { fireEvent, render, screen } from '@testing-library/react'
import { expect, test } from 'vitest'
import { SelectionTabs } from './SelectionTabs'
test('each choice exposes its own named panel and keyboard navigation moves both focus and content', () => {
  render(<SelectionTabs label="Document choices" items={[
    { id: 'old', label: 'Old', content: <p>Old content</p> },
    { id: 'new', label: 'New', content: <p>New content</p> },
  ]} />)
  const old = screen.getByRole('tab', { name: 'Old' }); const next = screen.getByRole('tab', { name: 'New' })
  expect(old.getAttribute('aria-controls')).not.toBe(next.getAttribute('aria-controls'))
  fireEvent.keyDown(old, { key: 'ArrowRight' })
  expect(document.activeElement).toBe(next); expect(screen.getByRole('tabpanel', { name: 'New' }).textContent).toBe('New content')
  fireEvent.keyDown(next, { key: 'Home' }); expect(document.activeElement).toBe(old)
  expect(screen.queryByText('New content')).toBeNull()
  fireEvent.keyDown(old, { key: 'End' }); expect(document.activeElement).toBe(next)
  expect(next.getAttribute('aria-selected')).toBe('true')
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/CopyMarkdown.test.tsx src/features/documentation/SelectionTabs.test.tsx`; capture RED.**
- [ ] **Step 3: Add the complete implementations.** `CopyMarkdown.tsx`:

```tsx
'use client'
import { useId, useRef, useState } from 'react'
export function CopyMarkdown({ text, label = 'Copy as Markdown', manualLabel = 'Markdown record', disabled = false }: { text: string; label?: string; manualLabel?: string; disabled?: boolean }) {
  const id = useId(); const attempt = useRef(0)
  const [result, setResult] = useState<{ text: string; manual: boolean } | null>(null)
  async function copy() {
    const sequence = ++attempt.current
    try {
      await navigator.clipboard.writeText(text)
      if (sequence === attempt.current) setResult({ text, manual: false })
    } catch {
      if (sequence === attempt.current) setResult({ text, manual: true })
    }
  }
  const message = result?.manual ? 'Copy is unavailable. Select the current Markdown below and copy it manually.' : result?.text === text ? 'Copied this version to clipboard.' : ''
  return <div className="mt-4 min-w-0">
    <button type="button" disabled={disabled} onClick={() => void copy()} className="min-h-11 border border-line px-4 text-sm disabled:cursor-default disabled:text-subtle">{label}</button>
    <p role="status" aria-label={`Copy status: ${label}`} className="mt-2 text-sm text-muted">{message}</p>
    {result?.manual && <div className="mt-3"><label htmlFor={id} className="mb-2 block text-sm font-medium">{manualLabel}</label><textarea id={id} readOnly value={text} rows={6} className="w-full border border-line bg-sunken px-3 py-2 text-sm leading-relaxed text-fg focus-visible:outline-2 focus-visible:outline-brand" /></div>}
  </div>
}
```

`SelectionTabs.tsx`:

```tsx
'use client'
import { useId, useState, type ReactNode, type KeyboardEvent } from 'react'
export type SelectionItem = { id: string; label: string; content: ReactNode }
export function SelectionTabs({ label, items }: { label: string; items: readonly SelectionItem[] }) {
  const root = useId(); const [selected, setSelected] = useState(0)
  const index = selected < items.length ? selected : 0
  if (items.length === 0) return <p>No examples are available.</p>
  function keys(event: KeyboardEvent<HTMLDivElement>) {
    const next = event.key === 'ArrowRight' ? (index + 1) % items.length : event.key === 'ArrowLeft' ? (index + items.length - 1) % items.length : event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : null
    if (next === null) return
    event.preventDefault(); setSelected(next)
    event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=tab]')[next]?.focus()
  }
  return <div className="min-w-0">
    <div role="tablist" aria-label={label} onKeyDown={keys} className="mb-4 flex flex-wrap gap-2">
      {items.map((item, i) => <button key={item.id} data-selection-id={item.id} type="button" role="tab" id={`${root}-tab-${item.id}`} aria-controls={`${root}-panel-${item.id}`} aria-selected={i === index} tabIndex={i === index ? 0 : -1} onClick={() => setSelected(i)} className={`min-h-11 min-w-0 break-words border border-line px-3 py-2 text-left text-sm ${i === index ? 'border-brand bg-brand-tint text-fg' : 'bg-raised text-muted'}`}>{item.label}</button>)}
    </div>
    <div role="tabpanel" id={`${root}-panel-${items[index].id}`} aria-labelledby={`${root}-tab-${items[index].id}`} tabIndex={0} className="min-w-0 focus-visible:outline-2 focus-visible:outline-brand">{items[index].content}</div>
  </div>
}
```

- [ ] **Step 4: Focused GREEN, lint and typecheck.** No shared copy helper or other feature is modified.
- [ ] **Step 5: Teeth check.** Remove only the sequence check in the copy rejection branch; the out-of-order test alone must fail. Restore and rerun both files. Separately force `SelectionTabs` to draw `items[0].content`; the keyboard/content test must fail, then restore.
- [ ] **Step 6: Independent review and commit** `feat(documentation): add selection and copy controls`. Deferred: document examples and personal forms.

