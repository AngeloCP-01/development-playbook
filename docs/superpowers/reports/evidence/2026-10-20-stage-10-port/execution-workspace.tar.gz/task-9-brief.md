### Task 9: Verify the whole port and preserve a reviewable handoff

**Files:** Create `docs/superpowers/reports/2026-10-20-stage-10-port-execution.md`
(if not already created by execution),
`docs/superpowers/reports/2026-10-20-stage-10-port-reader-rerun.md` and
`docs/stage-10-status.md`. Update `docs/task.md`, `docs/tracker.md`, `KICKOFF.md`
only from verified results. Retain the Task 8 browser spec in the application gate.

**Interfaces:** Consumes the built registered stage and all task evidence.
Produces chapter-heading coverage (declared in Task 8 COVERAGE and expanded with evidence), exact RED/GREEN/teeth logs, live UI matrices,
reader reports with finding dispositions, final review and explicit branch state.
This task changes records/verification; no product behavior is assumed missing.
Any fix first gets its own failing regression test and independent review.

- [ ] **Step 1: Create the heading coverage table in `docs/stage-10-status.md`.**
Use the approved spec's twelve-row matrix, with columns for actual implementation
file, panel ID, interaction and proving test/browser observation. Account for all
nine teaching subsections plus Entry criteria, Artifacts, Definition of done,
Scaling to a team and eight Traps. No cell is satisfied solely by the research
appendix or a future W-6 sheet. Record deliberate hand-port duplication.
- [ ] **Step 2: Run the gate below and archive raw output.** Record commit/tree,
production/development build identity, ports and tool versions. The parent server
on 3200 remains untouched. If Fonts access or a browser launch requires sandbox
escalation, use the approved scope and preserve the failed attempt; a startup
failure is not evidence of a product bug or a passing UI check.
- [ ] **Step 3: Run and record the expanded-state matrix.** At 320/390/768/1024/
1440/1920/2560 and both themes, visit all twelve panels, select every lookup row,
all three ADR specimens, every wrong/right practice verdict, every reveal, team
notes, filled forms, storage warnings and manual-copy text. Check overflow,
keyboard focus and semantic names, all distinct text/background contrast pairs,
44px targets below lg and D-52 at 1024×768. Shared sweeps cover selectable tabs
and disclosures; focused browser checks cover radio feedback, draft warnings and
manual textareas they do not discover automatically. Record which states were
actually measured, screenshots/geometry/contrast evidence and any limitations.
If D-52 fails, split at the observed seam, preserve existing deep links, update
STEP_IDS/steps/tests/coverage and recheck every affected panel. Do not increase an
exception ceiling to make the new stage pass.
- [ ] **Step 4: Check curated and inline source destinations against the accepted
primary pages.** Preserve URLs and date/results in execution evidence. Review
links to Stage 03/04/05/06/13/14/16 against actual web IDs. Stage 05's commit step
was confirmed as `commits` during planning; retain an observed browser check.
- [ ] **Step 5: Dispatch two fresh read-only cold readers, allowed by the
repository's required independent-reader process.** Both receive the exact
Toolshare scenario and five questions from
`docs/superpowers/reports/2026-10-20-stage-10-correction-rerun.md`, verbatim. One
builds the required artifacts from the port; the other records navigation and
scores each question HIT/PARTIAL/MISFILED/MISS. Give only the running Stage 10 URL
and public interactions, not source code, chapter answers or private coaching.
For a browser-controlled reader follow the available browser skill and use
separate browser contexts; if tools cannot isolate contexts, run them sequentially.
Keep literal prompts, outputs, artifacts, source restrictions and finding IDs.
No access failure counts as a clean reader report.
- [ ] **Step 6: Resolve confirmed findings with provenance.** Recheck claims
against the actual port and canonical chapter; distinguish introduced defects,
pre-existing issues and plan-authored omissions. Reject disproved findings with
evidence. A substantive teaching gap returns to scoped chapter correction before
it is ported. Reuse the same case/questions on fixes; do not train the authored
example to Toolshare. Run a fresh regression test, teeth check and relevant
browser checks over the final fix wave itself.
- [ ] **Step 7: Request final whole-branch review of `79f9e31..HEAD`.** Use the
requesting-code-review skill; include approved spec/plan, coverage, task reviews,
chapter evidence and actual current results. Severity/IDs/provenance and a Ready
to merge / Ready with fixes verdict are required. Resolve blockers through the
receiving-code-review process and independently verify fixes. No unfinished or
failed reviewer turn counts as approval.
- [ ] **Step 8: Humanizer review authored prose and update records.** The
execution report retains raw terminal output, source mutations/restorations,
reader findings and review dispositions. Record Deferred: W-6 companion and
publication, W-6.4, five language sheets, stages 17/18, unrelated repairs,
integration and deployment. Name feature-tree versus develop counts explicitly.
Use writing-for-agents for KICKOFF; point to evidence rather than repeating the
entire history. Preserve a hash-checked archive before any optional scratch
cleanup; never delete the only raw evidence.
- [ ] **Step 9: Commit evidence and handoff separately** with `docs(plan)` /
`docs(tracker)` scopes as appropriate. Verify clean tree, exact commits off
`79f9e31`, tests/build and review state. Invoke finishing-a-development-branch
only when implementation/review are complete. Ask before any merge; do not push,
merge to main, delete the parent branch/worktree or deploy on this authority.

## Verification (after all tasks)

Run from `web/`, sequentially where builds share `.next`:

```bash
pnpm format:check
pnpm lint
pnpm typecheck
pnpm test
pnpm build
pnpm test:e2e
pnpm test:dev-console
```

Expected: each command exits 0; the feature tree's new tests and 16 ready stages
are included, the production sweep observes every declared rail, no horizontal
overflow/contrast/touch/console/panel-weight failures, and the dev sweep has zero
React validation warnings. Record actual totals, not predicted counts. The
production check of the deployed site is not this gate. The shared audit may need
a measured runtime budget review if additional panels exceed its present 120s;
prove that cause before changing any timeout, and keep coverage intact.

After any final application fix, rebuild and rerun the affected browser checks
before claiming the earlier all-green audit covers it. After records-only edits,
run tracker-ledger guards, real local Markdown destinations and authored whitespace;
explain that application-tree identity preserves earlier UI evidence. Confirm
all internal source citations use chapter headings where appropriate (D-42).

## Plan self-review and execution handoff

The controller completed these checks before offering this plan; see the
[plan self-review record](../reports/2026-10-20-stage-10-port-plan-review.md).
These checks validate the written plan, not an executed implementation:

- [x] Spec coverage: all approved behaviors map to Tasks 1–9; no prototype,
  image-publication or shared-hook repair is silently included.
- [x] Step scan: sources are complete, every consumed export exists in an earlier
  task, every claimed RED has the right reason and each task has a review gate.
- [x] Type/source consistency: parse and check the embedded source with the local
  TypeScript version using a temporary/virtual file map; inspect JSX and imports.
  This is planning validation, not an executed implementation or TDD evidence.
- [x] Review Focus: each of the five conditions has its concrete test in the
  owning task. Resolve missing or contradictory assertions before handoff.
- [x] Proportion/prose: full inline source follows AGENTS.md; remove vague
  follow-up instructions and duplicate helper bodies. Apply humanizer to prose.

**Execution choice to present:** Subagent-driven versus inline. Recommend
**subagent-driven** for this nine-task plan: record/storage, clipboard races,
ADR status and registration are separate reviewable boundaries, while repeated
fresh review helps catch a plausible-looking but incorrect teaching claim.
Tasks remain sequential at their interface gates; this is not authorization for
parallel writers or merging. Inline remains available and still gets per-task
independent reviews under AGENTS.md. The user approved this spec, not an unseen
plan; plan review and the execution-method decision are the next checkpoint.
