# Task 4 implementation report

Status: implemented; awaiting the controller's independent review. Base: a90f45e.

Implemented four requested files only: a document model and Markdown serializer, semantic named specimen regions, a README outline and fresh-clone disclosure, and ADR tabs with counterpart controls. The controls select the complete related specimen and focus its selected tab. Filenames remain text. Copy actions reuse Task 3's clipboard fallback. The new counterpart buttons include `t-ui` per the controller ruling; existing Task 3 controls were left unchanged.

The tests were written before the implementation. The import-only RED established the missing interface, then minimal shells produced the meaningful behavior RED: all three tests failed because the README prerequisite content, named old-ADR region and blank-template tab were absent. These failures were for the right reason: the requested panel behavior did not exist. Only clipboard writes are stubbed, at the browser boundary; the panels, tabs, specimen model and copy component are real.

The teeth mutation filtered only the old specimen's supersession block from `DocumentExample` rendering. The complete focused file ran without a test filter: the old-ADR test failed because its own named region no longer contained `2026-10-20 — Current status: Superseded.`; the other two tests passed. The status legend and document data were unchanged. The original source was restored byte for byte with matching SHA256, and the complete focused file passed again.

Full suite: 1535/1535 tests across 213 files. Lint, typecheck and format check each exited 0. All complete command stdout/stderr and exit codes are retained in adjacent task-4 logs; excerpts below are copied directly from those logs without reconstruction. Production browser, development-console, contrast, responsive and panel-size checks belong to Task 9 after Task 8 registration; none was claimed here.

Self-review: compared all four sources against the task brief and controller ruling; checked named regions, specimen-scoped supersession, reciprocal Markdown links, tab focus, placeholder template facts and existing copy fallback integration. The only deviation from the proposed production source is the required `t-ui` class and formatting. No source concern found. Independent review remains the controller's responsibility.

Humanizer review: read the prescribed teaching prose as a draft, checked for inflated claims, filler, synthetic transitions and repeated rhetorical patterns, then retained the plain instructions as the final text. Enumerations carry actual document fields. The dated supersession string retains its specified em dash because the controller requires exact teaching strings. Canonical meaning, facts and labels are unchanged. The report uses direct descriptions and separates observed results from deferred work.

Deferred: reference/change inspectors (Task 5), stage registration (Task 8), full live-build checks and the existing Task 3 typography M1 (Task 9). No merge, push or deployment.

Runner correction: the first extraction script ran from `web/` with a root-relative workspace path, so it did not create a test and the runner reported no files. That output is retained in `task-4-import-red.log` (exit 1) and is not TDD evidence. The corrected import run is `task-4-missing-import-red.log`; the meaningful shell RED is `task-4-behavior-red.log`.

Files created:

- `web/src/features/documentation/documents.ts`
- `web/src/features/documentation/DocumentExample.tsx`
- `web/src/features/documentation/DocumentPanels.tsx`
- `web/src/features/documentation/DocumentPanels.test.tsx`

Exact source diff: `task-4-source.diff`.

## Initial missing interface RED

```text
$ pnpm test src/features/documentation/DocumentPanels.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentPanels.test.tsx (0 test)

⎯⎯⎯⎯⎯⎯ Failed Suites 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentPanels.test.tsx [ src/features/documentation/DocumentPanels.test.tsx ]
Error: Failed to resolve import "./DocumentPanels" from "src/features/documentation/DocumentPanels.test.tsx". Does the file exist?
  Plugin: vite:import-analysis
  File: /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web/src/features/documentation/DocumentPanels.test.tsx:3:44
  1  |  import { act, fireEvent, render, screen, within } from "@testing-library/react";
  2  |  import { afterEach, expect, test, vi } from "vitest";
  3  |  import { DecisionsPanel, ReadmePanel } from "./DocumentPanels";
     |                                               ^
  4  |  import { ADRS, documentMarkdown, README } from "./documents";
  5  |  var _jsxFileName = "/Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web/src/features/documen...
 ❯ TransformPluginContext._formatLog node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30416:39
 ❯ TransformPluginContext.error node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30413:14
 ❯ normalizeUrl node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27438:18
 ❯ node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27506:30
 ❯ TransformPluginContext.transform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27474:4
 ❯ EnvironmentPluginContainer.transform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30201:14
 ❯ loadAndTransform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:20124:26

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed (1)
      Tests  no tests
   Start at  10:37:57
   Duration  899ms (transform 31ms, setup 156ms, import 0ms, tests 0ms, environment 598ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

## Meaningful shell RED

```text
$ pnpm test src/features/documentation/DocumentPanels.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentPanels.test.tsx (3 tests | 3 failed) 65ms
   × the README keeps unknown setup facts visible and copies the same outline a maintainer reads 14ms
   × the old ADR itself declares its dated current status and preserves the accepted history 48ms
   × the blank ADR is explicitly a template with project facts to supply rather than a copied Workshop decision 3ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 3 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentPanels.test.tsx > the README keeps unknown setup facts visible and copies the same outline a maintainer reads
TestingLibraryElementError: Unable to find an element with the text: /Supported prerequisites and tool versions/. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.

Ignored nodes: comments, script, style
[36m<body>[39m
  [36m<div />[39m
[36m</body>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/DocumentPanels.test.tsx:9:17
      7|   const write = vi.fn().mockResolvedValue(undefined); vi.stubGlobal('n…
      8|   render(<ReadmePanel />)
      9|   expect(screen.getByText(/Supported prerequisites and tool versions/)…
       |                 ^
     10|   expect(screen.getByText(/Clone, install and startup commands/).textC…
     11|   await act(async () => { fireEvent.click(screen.getByRole('button', {…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/3]⎯

 FAIL  |dom| src/features/documentation/DocumentPanels.test.tsx > the old ADR itself declares its dated current status and preserves the accepted history
TestingLibraryElementError: Unable to find an accessible element with the role "region" and name "docs/adr/004-manual-field-reference.md"

There are no accessible roles. But there might be some inaccessible roles. If you wish to access them, then set the `hidden` option to `true`. Learn more about this here: https://testing-library.com/docs/dom-testing-library/api-queries#byrole

Ignored nodes: comments, script, style
[36m<body>[39m
  [36m<div />[39m
[36m</body>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/DocumentPanels.test.tsx:20:22
     18|   const write = vi.fn().mockResolvedValue(undefined); vi.stubGlobal('n…
     19|   render(<DecisionsPanel />)
     20|   const old = screen.getByRole('region', { name: ADRS.old.filename })
       |                      ^
     21|   expect(within(old).getByText('Status: Accepted')).toBeTruthy()
     22|   expect(within(old).getByText('2026-10-20 — Current status: Supersede…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[2/3]⎯

 FAIL  |dom| src/features/documentation/DocumentPanels.test.tsx > the blank ADR is explicitly a template with project facts to supply rather than a copied Workshop decision
TestingLibraryElementError: Unable to find an accessible element with the role "tab" and name "Blank template"

There are no accessible roles. But there might be some inaccessible roles. If you wish to access them, then set the `hidden` option to `true`. Learn more about this here: https://testing-library.com/docs/dom-testing-library/api-queries#byrole

Ignored nodes: comments, script, style
[36m<body>[39m
  [36m<div />[39m
[36m</body>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/DocumentPanels.test.tsx:39:26
     37| test('the blank ADR is explicitly a template with project facts to sup…
     38|   render(<DecisionsPanel />)
     39|   fireEvent.click(screen.getByRole('tab', { name: 'Blank template' }))
       |                          ^
     40|   const template = screen.getByRole('region', { name: ADRS.template.fi…
     41|   for (const heading of ['Context', 'Decision', 'Reasoning', 'Conseque…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[3/3]⎯


 Test Files  1 failed (1)
      Tests  3 failed (3)
   Start at  10:38:08
   Duration  785ms (transform 29ms, setup 126ms, import 15ms, tests 65ms, environment 489ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

## Focused GREEN

```text
$ pnpm test src/features/documentation/DocumentPanels.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  1 passed (1)
      Tests  3 passed (3)
   Start at  10:38:26
   Duration  1.10s (transform 112ms, setup 116ms, import 185ms, tests 175ms, environment 504ms)


EXIT STATUS: 0
```

## Full focused teeth mutation

```text
$ pnpm test src/features/documentation/DocumentPanels.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentPanels.test.tsx (3 tests | 1 failed) 186ms
   × the old ADR itself declares its dated current status and preserves the accepted history 39ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentPanels.test.tsx > the old ADR itself declares its dated current status and preserves the accepted history
TestingLibraryElementError: Unable to find an element with the text: 2026-10-20 — Current status: Superseded.. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.

Ignored nodes: comments, script, style
[36m<section[39m
  [33maria-label[39m=[32m"docs/adr/004-manual-field-reference.md"[39m
  [33mclass[39m=[32m"min-w-0"[39m
[36m>[39m
  [36m<div[39m
    [33mclass[39m=[32m"border border-line bg-raised p-5 sm:p-6 "[39m
  [36m>[39m
    [36m<p[39m
      [33mclass[39m=[32m"t-data mb-3 break-words text-sm text-muted"[39m
    [36m>[39m
      [0mdocs/adr/004-manual-field-reference.md[0m
    [36m</p>[39m
    [36m<h3[39m
      [33mclass[39m=[32m"t-head mb-3 text-lg"[39m
    [36m>[39m
      [0mADR 004: maintain the initial field reference by hand[0m
    [36m</h3>[39m
    [36m<p[39m
      [33mclass[39m=[32m"break-words text-sm text-muted"[39m
    [36m>[39m
      [0mDate: 2026-09-01[0m
    [36m</p>[39m
    [36m<p[39m
      [33mclass[39m=[32m"break-words text-sm text-muted"[39m
    [36m>[39m
      [0mStatus: Accepted[0m
    [36m</p>[39m
    [36m<p[39m
      [33mclass[39m=[32m"mt-2 break-words text-sm text-muted"[39m
    [36m>[39m
      [0mReplacement[0m
      [0m: [0m
      [0mADR 005[0m
      [0m ([0m
      [0m005-generated-contract-reference.md[0m
      [0m)[0m
    [36m</p>[39m
    [36m<button[39m
      [33mclass[39m=[32m"t-ui mt-3 min-h-11 border border-line px-4 text-sm"[39m
      [33mtype[39m=[32m"button"[39m
    [36m>[39m
      [0mRead [0m
      [0mADR 005[0m
    [36m</button>[39m
    [36m<div[39m
      [33mclass[39m=[32m"mt-4"[39m
    [36m>[39m
      [36m<h4[39m
        [33mclass[39m=[32m"t-ui mb-1 text-sm font-semibold"[39m
      [36m>[39m
        [0mContext[0m
      [36m</h4>[39m
      [36m<p[39m
        [33mclass[39m=[32m"break-words text-sm leading-relaxed text-muted"[39m
      [36m>[39m
        [0mThe initial contract is small. The team has no reference generator.[0m
      [36m</p>[39m
    [36m</div>[39m
    [36m<div[39m
      [33mclass[39m=[32m"mt-4"[39m
    [36m>[39m
      [36m<h4[39m
        [33mclass[39m=[32m"t-ui mb-1 text-sm font-semibold"[39m
      [36m>[39m
        [0mDecision[0m
      [36m</h4>[39m
      [36m<p[39m
        [33mclass[39m=[32m"break-words text-sm leading-relaxed text-muted"[39m
      [36m>[39m
        [0mMaintain the initial field reference beside the contract.[0m
      [36m</p>[39m
    [36m</div>[39m
    [36m<div[39m
      [33mclass[39m=[32m"mt-4"[39m
    [36m>[39m
      [36m<h4[39m
        [33mclass[39m=[32m"t-ui mb-1 text-sm font-semibold"[39m
      [36m>[39m
        [0mConsequences[0m
      [36m</h4>[39m
      [36m<p[39m
        [33mclass[39m=[32m"break-words text-sm leading-relaxed text-muted"[39m
      [36m>[39m
        [0mEvery contract change requires a separate reference edit and review.[0m
      [36m</p>[39m
    [36m</div>[39m
    [36m<div[39m
      [33mclass[39m=[32m"mt-4 min-w-0"[39m
    [36m>[39m
      [36m<button[39m
        [33mclass[39m=[32m"min-h-11 border border-line px-4 text-sm disabled:cursor-default disabled:text-subtle"[39m
        [33mtype[39m=[32m"button"[39m
      [36m>[39m
        [0mCopy ADR 004[0m
      [36m</button>[39m
      [36m<p[39m
        [33maria-label[39m=[32m"Copy status: Copy ADR 004"[39m
        [33mclass[39m=[32m"mt-2 text-sm text-muted"[39m
        [33mrole[39m=[32m"status"[39m
      [36m/>[39m
    [36m</div>[39m
  [36m</div>[39m
[36m</section>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/DocumentPanels.test.tsx:35:17
     33|   expect(within(old).getByText('Status: Accepted')).toBeTruthy()
     34|   expect(
     35|     within(old).getByText('2026-10-20 — Current status: Superseded.'),
       |                 ^
     36|   ).toBeTruthy()
     37|   expect(

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed (1)
      Tests  1 failed | 2 passed (3)
   Start at  10:38:49
   Duration  1.15s (transform 110ms, setup 106ms, import 173ms, tests 186ms, environment 587ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

## Restored focused GREEN

```text
$ pnpm test src/features/documentation/DocumentPanels.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  1 passed (1)
      Tests  3 passed (3)
   Start at  10:38:52
   Duration  963ms (transform 96ms, setup 78ms, import 159ms, tests 290ms, environment 340ms)


EXIT STATUS: 0
```

## Full suite

```text
$ pnpm test

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  213 passed (213)
      Tests  1535 passed (1535)
   Start at  10:39:09
   Duration  53.53s (transform 29.14s, setup 29.15s, import 66.70s, tests 95.87s, environment 139.54s)


EXIT STATUS: 0
```

## Lint

```text
$ pnpm lint

> web@0.1.0 lint /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> eslint --max-warnings 0


EXIT STATUS: 0
```

## Typecheck

```text
$ pnpm typecheck

> web@0.1.0 typecheck /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> next typegen && tsc --noEmit

Generating route types...
✓ Types generated successfully

EXIT STATUS: 0
```

## Formatting

```text
$ pnpm format:check

> web@0.1.0 format:check /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> prettier --check .

Checking formatting...
All matched files use Prettier code style!

EXIT STATUS: 0
```

## Byte-exact restoration

```text
before sha256: ac7df3d9492274a2c7684f590659731a26c2f0c46f60cd4b74131af3ac27c0b8
after sha256: ac7df3d9492274a2c7684f590659731a26c2f0c46f60cd4b74131af3ac27c0b8
byte-exact restoration: PASS
exit code: 0
```

## Commit

Created `bab3beb feat(documentation): teach readme checks and adr replacement`. The commit contains exactly the four task paths. Hooks formatted all four without changes and lint passed. Parent report modifications remain uncommitted and untouched.

```text
╭───────────────────────────────────────╮
│ lefthook  v2.1.10   hook:  [1mpre-commit[m │
╰───────────────────────────────────────╯
┃  format ❯ 
src/features/documentation/DocumentExample.tsx 67ms (unchanged)
src/features/documentation/DocumentPanels.test.tsx 50ms (unchanged)
src/features/documentation/DocumentPanels.tsx 61ms (unchanged)
src/features/documentation/documents.ts 29ms (unchanged)

┃  lint ❯ 

[38;2;56;56;56m  ────────────────────────────────────[m
summary: (done in 3.26 seconds)
✓ format (1.06 seconds)
✓ lint (3.24 seconds)
[feat/stage-10-documentation bab3beb] feat(documentation): teach readme checks and adr replacement
 4 files changed, 477 insertions(+)
 create mode 100644 web/src/features/documentation/DocumentExample.tsx
 create mode 100644 web/src/features/documentation/DocumentPanels.test.tsx
 create mode 100644 web/src/features/documentation/DocumentPanels.tsx
 create mode 100644 web/src/features/documentation/documents.ts

EXIT STATUS: 0
```
