import subprocess,os,json,time
from pathlib import Path
out=Path('../.superpowers/sdd/2026-10-20-stage-10-interactive-port/task-9-evidence')
env=os.environ.copy();env.pop('NO_COLOR',None)
results=[]
for name in ['format:check','lint','typecheck','test','build','test:e2e','test:dev-console']:
 start=time.time();log=out/('gate-'+name.replace(':','-')+'.log')
 with log.open('w') as f:
  f.write('$ pnpm '+name+'\n');f.flush()
  p=subprocess.run(['pnpm',name],stdout=f,stderr=subprocess.STDOUT,env=env)
  f.write('\nEXIT_CODE='+str(p.returncode)+'\n')
 results.append({'command':'pnpm '+name,'exit':p.returncode,'seconds':round(time.time()-start,2),'log':str(log)})
 (out/'gate-results.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results[-1]),flush=True)
