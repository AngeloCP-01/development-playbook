import os,subprocess,signal,time,urllib.request,json,hashlib
from pathlib import Path
root=Path.cwd();out=root/'.superpowers/sdd/2026-10-20-stage-10-interactive-port/task-9-evidence';web=root/'web';env=os.environ.copy();env.pop('NO_COLOR',None);results=[];server=None;server_log=None

def command(name,args,cwd=root):
 with (out/(name+'.log')).open('w') as f:
  f.write('$ '+' '.join(args)+'\n');f.flush();p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);f.write('\nEXIT_CODE='+str(p.returncode)+'\n')
 item={'name':name,'command':args,'exit':p.returncode}
 if 'build' in name:item['buildId']=(web/'.next/BUILD_ID').read_text().strip()
 results.append(item);(out/'font-cycle-results.json').write_text(json.dumps(results,indent=2));print(item,flush=True);return p.returncode

def start(name):
 global server,server_log
 server_log=(out/(name+'-server.log')).open('w');server=subprocess.Popen(['pnpm','start','-p','3100'],cwd=web,env=env,stdout=server_log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:
   if urllib.request.urlopen('http://localhost:3100/').status==200:return
  except Exception:pass
  time.sleep(.2)
 raise RuntimeError('server failed')

def stop():
 global server
 if server:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=20);server=None;server_log.close()

copy=web/'src/features/documentation/CopyMarkdown.tsx';tabs=web/'src/features/documentation/SelectionTabs.tsx';initialc=copy.read_bytes();initialt=tabs.read_bytes();(out/'font-initial-source.diff').write_bytes(subprocess.run(['git','diff','--',str(copy),str(tabs)],capture_output=True).stdout)
basec=initialc.replace(b'className="t-ui min-h-11 border',b'className="min-h-11 border');baset=initialt.replace(b'className={`t-ui min-h-11 min-w-0',b'className={`min-h-11 min-w-0');assert basec!=initialc and baset!=initialt
copy.write_bytes(basec);tabs.write_bytes(baset)
try:
 assert command('font-red-build',['pnpm','build'],web)==0
 start('font-red');assert command('font-red',['node',str(out/'fonts.cjs')])==1;stop()
 # Implement the minimum token additions only after the actual guarded RED.
 copy.write_bytes(copy.read_bytes().replace(b'className="min-h-11 border',b'className="t-ui min-h-11 border'));tabs.write_bytes(tabs.read_bytes().replace(b'className={`min-h-11 min-w-0',b'className={`t-ui min-h-11 min-w-0'))
 greenc=copy.read_bytes();greent=tabs.read_bytes();assert greenc==initialc and greent==initialt
 assert command('font-green-build',['pnpm','build'],web)==0
 start('font-green');assert command('font-green',['node',str(out/'fonts.cjs')])==0;stop()
 copy.write_bytes(greenc.replace(b'className="t-ui min-h-11 border',b'className="min-h-11 border'))
 command('font-teeth-diff',['git','diff','--',str(copy),str(tabs)])
 assert command('font-teeth-build',['pnpm','build'],web)==0
 start('font-teeth');assert command('font-teeth',['node',str(out/'fonts.cjs')])==1;stop()
finally:
 stop();copy.write_bytes(initialc);tabs.write_bytes(initialt)
manifest=json.loads((out/'application-matrix.json').read_text());actual={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in manifest['files']};same=actual==manifest['files'];(out/'font-restoration.json').write_text(json.dumps({'allApplicationFilesMatchMatrix':same,'sourceIdentity':hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest(),'copySha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'tabsSha256':hashlib.sha256(tabs.read_bytes()).hexdigest()},indent=2));assert same
assert command('font-restored-build',['pnpm','build'],web)==0
try:
 start('font-restored');assert command('font-restored',['node',str(out/'fonts.cjs')])==0;assert command('font-restored-targets',['node',str(out/'targets.cjs')])==0
finally:stop()
