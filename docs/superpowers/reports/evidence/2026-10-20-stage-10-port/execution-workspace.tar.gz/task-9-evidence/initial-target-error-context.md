# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: audit.spec.ts >> interactive elements are at least 44px tall below lg
- Location: e2e/audit.spec.ts:65:5

# Error details

```
Error: /stages/10-documentation#history: Stage 05 commit guidance, Stage 05 commit guidance
/stages/10-documentation#checklist: Stage 16 incident response

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 4

- Array []
+ Array [
+   "/stages/10-documentation#history: Stage 05 commit guidance, Stage 05 commit guidance",
+   "/stages/10-documentation#checklist: Stage 16 incident response",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=e3]:
    - generic [ref=e4]:
      - button "Open navigation" [ref=e5]:
        - img [ref=e6]
      - link "Playbook 18" [ref=e7] [cursor=pointer]:
        - /url: /
        - generic [ref=e8]:
          - generic [ref=e9]: Playbook
          - generic [ref=e10]: "18"
      - button "System theme. Click to change." [ref=e12]:
        - img [ref=e13]
    - complementary [ref=e15]:
      - generic [ref=e16]:
        - link "Playbook 18" [ref=e17] [cursor=pointer]:
          - /url: /
          - generic [ref=e18]:
            - generic [ref=e19]: Playbook
            - generic [ref=e20]: "18"
        - button "Close navigation" [ref=e22]:
          - img [ref=e23]
      - generic [ref=e26]:
        - navigation "Stage index" [ref=e27]:
          - generic [ref=e28]:
            - generic [ref=e29]: Before code
            - list "Before code" [ref=e30]:
              - listitem [ref=e31]:
                - link "01 Product Discovery" [ref=e32] [cursor=pointer]:
                  - /url: /stages/01-product-discovery
                  - generic [ref=e33]: "01"
                  - generic [ref=e35]: Product Discovery
              - listitem [ref=e36]:
                - link "02 Product Planning" [ref=e37] [cursor=pointer]:
                  - /url: /stages/02-planning
                  - generic [ref=e38]: "02"
                  - generic [ref=e40]: Product Planning
              - listitem [ref=e41]:
                - link "03 Architecture" [ref=e42] [cursor=pointer]:
                  - /url: /stages/03-architecture
                  - generic [ref=e43]: "03"
                  - generic [ref=e45]: Architecture
          - generic [ref=e46]:
            - generic [ref=e47]: Building
            - list "Building" [ref=e48]:
              - listitem [ref=e49]:
                - link "04 Project Setup" [ref=e50] [cursor=pointer]:
                  - /url: /stages/04-project-setup
                  - generic [ref=e51]: "04"
                  - generic [ref=e53]: Project Setup
              - listitem [ref=e54]:
                - link "05 Development" [ref=e55] [cursor=pointer]:
                  - /url: /stages/05-development
                  - generic [ref=e56]: "05"
                  - generic [ref=e58]: Development
              - listitem [ref=e59]:
                - link "06 Testing" [ref=e60] [cursor=pointer]:
                  - /url: /stages/06-testing
                  - generic [ref=e61]: "06"
                  - generic [ref=e63]: Testing
              - listitem [ref=e64]:
                - link "07 Code Review" [ref=e65] [cursor=pointer]:
                  - /url: /stages/07-code-review
                  - generic [ref=e66]: "07"
                  - generic [ref=e68]: Code Review
              - listitem [ref=e69]:
                - link "08 Security Audit" [ref=e70] [cursor=pointer]:
                  - /url: /stages/08-security-audit
                  - generic [ref=e71]: "08"
                  - generic [ref=e73]: Security Audit
              - listitem [ref=e74]:
                - link "09 Performance Optimization" [ref=e75] [cursor=pointer]:
                  - /url: /stages/09-performance-optimization
                  - generic [ref=e76]: "09"
                  - generic [ref=e78]: Performance Optimization
              - listitem [ref=e79]:
                - link "10 Documentation" [ref=e80] [cursor=pointer]:
                  - /url: /stages/10-documentation
                  - generic [ref=e81]: "10"
                  - generic [ref=e83]: Documentation
          - generic [ref=e84]:
            - generic [ref=e85]: Shipping
            - list "Shipping" [ref=e86]:
              - listitem [ref=e87]:
                - link "11 CI/CD" [ref=e88] [cursor=pointer]:
                  - /url: /stages/11-ci-cd
                  - generic [ref=e89]: "11"
                  - generic [ref=e91]: CI/CD
              - listitem [ref=e92]:
                - link "12 Staging" [ref=e93] [cursor=pointer]:
                  - /url: /stages/12-staging
                  - generic [ref=e94]: "12"
                  - generic [ref=e96]: Staging
              - listitem [ref=e97]:
                - link "13 Production Deployment" [ref=e98] [cursor=pointer]:
                  - /url: /stages/13-production-deployment
                  - generic [ref=e99]: "13"
                  - generic [ref=e101]: Production Deployment
              - listitem [ref=e102]:
                - link "14 Post-Deployment Verification" [ref=e103] [cursor=pointer]:
                  - /url: /stages/14-post-deployment-verification
                  - generic [ref=e104]: "14"
                  - generic [ref=e106]: Post-Deployment Verification
          - generic [ref=e107]:
            - generic [ref=e108]: Running
            - list "Running" [ref=e109]:
              - listitem [ref=e110]:
                - link "15 Observability" [ref=e111] [cursor=pointer]:
                  - /url: /stages/15-observability
                  - generic [ref=e112]: "15"
                  - generic [ref=e114]: Observability
              - listitem [ref=e115]:
                - link "16 Incident Management" [ref=e116] [cursor=pointer]:
                  - /url: /stages/16-incident-management
                  - generic [ref=e117]: "16"
                  - generic [ref=e119]: Incident Management
              - listitem [ref=e120]:
                - link "17 Maintenance WIP" [ref=e121] [cursor=pointer]:
                  - /url: /stages/17-maintenance
                  - generic [ref=e122]: "17"
                  - generic [ref=e123]:
                    - generic [ref=e124]: Maintenance
                    - generic "Not written yet" [ref=e125]: WIP
              - listitem [ref=e126]:
                - link "18 Continuous Improvement WIP" [ref=e127] [cursor=pointer]:
                  - /url: /stages/18-continuous-improvement
                  - generic [ref=e128]: "18"
                  - generic [ref=e129]:
                    - generic [ref=e130]: Continuous Improvement
                    - generic "Not written yet" [ref=e131]: WIP
        - navigation "Reference index" [ref=e132]:
          - generic [ref=e133]:
            - generic [ref=e134]: Architecture
            - list "Architecture" [ref=e135]:
              - listitem [ref=e136]:
                - link "Software Architecture Patterns" [ref=e137] [cursor=pointer]:
                  - /url: /reference/architecture-patterns
                  - generic [ref=e139]: Software Architecture Patterns
              - listitem [ref=e140]:
                - link "Design Patterns" [ref=e141] [cursor=pointer]:
                  - /url: /reference/design-patterns
                  - generic [ref=e143]: Design Patterns
              - listitem [ref=e144]:
                - link "API Design" [ref=e145] [cursor=pointer]:
                  - /url: /reference/api-design
                  - generic [ref=e147]: API Design
              - listitem [ref=e148]:
                - link "Caching" [ref=e149] [cursor=pointer]:
                  - /url: /reference/caching
                  - generic [ref=e151]: Caching
              - listitem [ref=e152]:
                - link "Infrastructure Scaling" [ref=e153] [cursor=pointer]:
                  - /url: /reference/scaling
                  - generic [ref=e155]: Infrastructure Scaling
          - generic [ref=e156]:
            - generic [ref=e157]: Design Principles
            - list [ref=e158]:
              - listitem [ref=e159]:
                - link "SOLID Principles" [ref=e160] [cursor=pointer]:
                  - /url: /reference/solid-principles
                  - generic [ref=e162]: SOLID Principles
              - listitem [ref=e163]:
                - link "Clean Code" [ref=e164] [cursor=pointer]:
                  - /url: /reference/clean-code
                  - generic [ref=e166]: Clean Code
          - generic [ref=e167]:
            - generic [ref=e168]: Git
            - list "Git" [ref=e169]:
              - listitem [ref=e170]:
                - link "Git Cheat Sheet" [ref=e171] [cursor=pointer]:
                  - /url: /reference/git-cheatsheet
                  - generic [ref=e173]: Git Cheat Sheet
              - listitem [ref=e174]:
                - link "Git Commands" [ref=e175] [cursor=pointer]:
                  - /url: /reference/git-commands
                  - generic [ref=e177]: Git Commands
              - listitem [ref=e178]:
                - link "Git Branching & Conventions" [ref=e179] [cursor=pointer]:
                  - /url: /reference/git-branching
                  - generic [ref=e181]: Git Branching & Conventions
          - generic [ref=e182]:
            - generic [ref=e183]: Standards
            - list "Standards" [ref=e184]:
              - listitem [ref=e185]:
                - link "Coding Standards" [ref=e186] [cursor=pointer]:
                  - /url: /reference/coding-standards
                  - generic [ref=e188]: Coding Standards
              - listitem [ref=e189]:
                - link "Software Development Life Cycle" [ref=e190] [cursor=pointer]:
                  - /url: /reference/sdlc
                  - generic [ref=e192]: Software Development Life Cycle
              - listitem [ref=e193]:
                - link "Testing" [ref=e194] [cursor=pointer]:
                  - /url: /reference/testing
                  - generic [ref=e196]: Testing
              - listitem [ref=e197]:
                - link "Playwright" [ref=e198] [cursor=pointer]:
                  - /url: /reference/playwright
                  - generic [ref=e200]: Playwright
              - listitem [ref=e201]:
                - link "Code Review" [ref=e202] [cursor=pointer]:
                  - /url: /reference/code-review
                  - generic [ref=e204]: Code Review
              - listitem [ref=e205]:
                - link "Deployment Environments" [ref=e206] [cursor=pointer]:
                  - /url: /reference/deployment-environments
                  - generic [ref=e208]: Deployment Environments
              - listitem [ref=e209]:
                - link "AWS Deployment" [ref=e210] [cursor=pointer]:
                  - /url: /reference/aws-deployment
                  - generic [ref=e212]: AWS Deployment
              - listitem [ref=e213]:
                - link "Post-Deploy Verification" [ref=e214] [cursor=pointer]:
                  - /url: /reference/post-deploy-verification
                  - generic [ref=e216]: Post-Deploy Verification
              - listitem [ref=e217]:
                - link "CI/CD Pipeline" [ref=e218] [cursor=pointer]:
                  - /url: /reference/ci-cd
                  - generic [ref=e220]: CI/CD Pipeline
              - listitem [ref=e221]:
                - link "GitHub Actions" [ref=e222] [cursor=pointer]:
                  - /url: /reference/github-actions
                  - generic [ref=e224]: GitHub Actions
              - listitem [ref=e225]:
                - link "Incident Management" [ref=e226] [cursor=pointer]:
                  - /url: /reference/incident-management
                  - generic [ref=e228]: Incident Management
              - listitem [ref=e229]:
                - link "Security Audit" [ref=e230] [cursor=pointer]:
                  - /url: /reference/security
                  - generic [ref=e232]: Security Audit
          - generic [ref=e233]:
            - generic [ref=e234]: Languages
            - list "Languages" [ref=e235]:
              - listitem [ref=e236]:
                - link "JavaScript WIP" [ref=e237] [cursor=pointer]:
                  - /url: /reference/javascript
                  - generic [ref=e238]:
                    - generic [ref=e239]: JavaScript
                    - generic "Not gathered yet" [ref=e240]: WIP
              - listitem [ref=e241]:
                - link "Python WIP" [ref=e242] [cursor=pointer]:
                  - /url: /reference/python
                  - generic [ref=e243]:
                    - generic [ref=e244]: Python
                    - generic "Not gathered yet" [ref=e245]: WIP
              - listitem [ref=e246]:
                - link "Java WIP" [ref=e247] [cursor=pointer]:
                  - /url: /reference/java
                  - generic [ref=e248]:
                    - generic [ref=e249]: Java
                    - generic "Not gathered yet" [ref=e250]: WIP
              - listitem [ref=e251]:
                - link "Spring Boot WIP" [ref=e252] [cursor=pointer]:
                  - /url: /reference/spring-boot
                  - generic [ref=e253]:
                    - generic [ref=e254]: Spring Boot
                    - generic "Not gathered yet" [ref=e255]: WIP
              - listitem [ref=e256]:
                - link "Express & Node WIP" [ref=e257] [cursor=pointer]:
                  - /url: /reference/express
                  - generic [ref=e258]:
                    - generic [ref=e259]: Express & Node
                    - generic "Not gathered yet" [ref=e260]: WIP
    - main [ref=e261]:
      - article [ref=e262]:
        - generic [ref=e263]:
          - paragraph [ref=e264]: Languages
          - heading "Express & Node" [level=1] [ref=e265]
          - paragraph [ref=e266]: Middleware order, routing, and what blocks the event loop.
        - generic [ref=e269]:
          - paragraph [ref=e270]: Sheet not drawn
          - paragraph [ref=e271]: This sheet is registered so the gap is visible. The content has not been gathered yet.
  - alert [ref=e272]
```

# Test source

```ts
  52  |       await page.goto(path, { waitUntil: 'networkidle' })
  53  |       const overflow = await page.evaluate(() => {
  54  |         const de = document.documentElement
  55  |         return de.scrollWidth - de.clientWidth
  56  |       })
  57  |       if (overflow !== 0) failures.push(`${path} @ ${width}px by ${overflow}px`)
  58  |     }
  59  |     expect(failures, failures.join('\n')).toEqual([])
  60  |   })
  61  | }
  62  | 
  63  | // ── touch targets ──────────────────────────────────────────────────────────
  64  | 
  65  | test('interactive elements are at least 44px tall below lg', async ({
  66  |   page,
  67  | }) => {
  68  |   await page.setViewportSize({ width: 390, height: 844 })
  69  |   const failures: string[] = []
  70  |   for (const path of await auditPages(page)) {
  71  |     await page.goto(path, { waitUntil: 'networkidle' })
  72  |     // A target that is only reachable behind an accordion is still a target.
  73  |     // This check never expanded anything either, which is how a sub-44px
  74  |     // <Term> inside a collapsed TeamNotes stayed unmeasured.
  75  |     const small: string[] = []
  76  |     await forEachPanelState(page, async () => {
  77  |       small.push(
  78  |         ...(await page.evaluate(() => {
  79  |           /** Inline in a sentence: somewhere between the target and the `p` or
  80  |            *  `li` holding it, there is running text beside it. `Term` wraps itself
  81  |            *  in a span, so the text is a level or two up rather than a direct
  82  |            *  sibling — an accordion control never finds any, because its heading
  83  |            *  and its row hold nothing but the control. */
  84  |           const inlineInSentence = (el: Element) => {
  85  |             const sentence = el.closest('p, li')
  86  |             if (!sentence) return false
  87  |             let node: Element | null = el
  88  |             while (node && node !== sentence) {
  89  |               const beside = [...(node.parentElement?.childNodes ?? [])].some(
  90  |                 (n) =>
  91  |                   n.nodeType === 3 && (n.textContent ?? '').trim().length > 0,
  92  |               )
  93  |               if (beside) return true
  94  |               node = node.parentElement
  95  |             }
  96  |             return false
  97  |           }
  98  | 
  99  |           const inScroller = (el: Element) => {
  100 |             let e = el.parentElement
  101 |             while (e) {
  102 |               const o = getComputedStyle(e).overflowX
  103 |               if (o === 'auto' || o === 'scroll') return true
  104 |               e = e.parentElement
  105 |             }
  106 |             return false
  107 |           }
  108 |           return [
  109 |             ...document.querySelectorAll(
  110 |               'a,button,[role=tab],[role=radio],textarea',
  111 |             ),
  112 |           ]
  113 |             .filter((el) => {
  114 |               const b = el.getBoundingClientRect()
  115 |               return (
  116 |                 b.width > 0 &&
  117 |                 b.height > 0 &&
  118 |                 b.height < 44 &&
  119 |                 !String(el.className).includes('sr-only') &&
  120 |                 !inScroller(el) &&
  121 |                 // WCAG 2.5.8 exempts targets sitting inline in a sentence — their
  122 |                 // size is constrained by the surrounding text's line-height. This
  123 |                 // covers <Term> buttons inside prose, and `li` as well as `p`
  124 |                 // because a sentence in a list is still a sentence.
  125 |                 //
  126 |                 // But "inside a sentence element" is not "inline in a sentence". A
  127 |                 // bare `p, li` exempted 880 elements to excuse one — including 74
  128 |                 // accordion controls and 67 exercise radios and checkboxes, which
  129 |                 // are list-wrapped by construction. That is the same hole the
  130 |                 // earlier aria-controls exemption had, which this comment used to
  131 |                 // disown while reproducing it.
  132 |                 //
  133 |                 // Role does not separate them either: `Term` is itself a
  134 |                 // disclosure, so excluding `aria-expanded` re-gates the very
  135 |                 // buttons this exemption exists for. What actually distinguishes
  136 |                 // them is whether the control sits *among text* — a `Term` has
  137 |                 // sentence either side of it, while an accordion control is the
  138 |                 // only thing its heading or row contains.
  139 |                 !inlineInSentence(el)
  140 |               )
  141 |             })
  142 |             .map((el) =>
  143 |               (el.textContent || el.getAttribute('aria-label') || '?')
  144 |                 .trim()
  145 |                 .slice(0, 30),
  146 |             )
  147 |         })),
  148 |       )
  149 |     })
  150 |     if (small.length > 0) failures.push(`${path}: ${small.join(', ')}`)
  151 |   }
> 152 |   expect(failures, failures.join('\n')).toEqual([])
      |                                         ^ Error: /stages/10-documentation#history: Stage 05 commit guidance, Stage 05 commit guidance
  153 | })
  154 | 
  155 | // ── contrast ───────────────────────────────────────────────────────────────
  156 | 
  157 | for (const scheme of ['light', 'dark'] as const) {
  158 |   test(`every text/background pair passes WCAG AA in ${scheme} mode`, async ({
  159 |     browser,
  160 |   }) => {
  161 |     const context = await browser.newContext({ colorScheme: scheme })
  162 |     const page = await context.newPage()
  163 |     const failures: string[] = []
  164 | 
  165 |     for (const path of await auditPages(page)) {
  166 |       await page.goto(path, { waitUntil: 'networkidle' })
  167 |       // Term definition panels and accordion bodies are surfaces too.
  168 |       const rows: {
  169 |         fg: number[]
  170 |         bg: number[]
  171 |         size: number
  172 |         weight: number
  173 |         sample: string
  174 |       }[] = []
  175 |       await forEachPanelState(page, async () => {
  176 |         rows.push(
  177 |           ...(await page.evaluate(() => {
  178 |             // This comment used to claim the parser resolved oklab "via the browser
  179 |             // itself". It did not — it *rejected* oklab and returned null, so every
  180 |             // such colour was skipped rather than checked. Tailwind emits oklab for
  181 |             // any alpha colour, so the rule was: add an opacity and leave the audit.
  182 |             //
  183 |             // Rasterising is the honest version of what the comment promised. Paint
  184 |             // the background, paint the colour over it, read the pixel: the browser
  185 |             // resolves whatever colour space it likes and composites the alpha in
  186 |             // the same step, and what comes back is what the eye receives. It is
  187 |             // also the technique TD-16 was originally measured with by hand.
  188 |             const raster = (color: string, bg: number[]) => {
  189 |               const cv = document.createElement('canvas')
  190 |               cv.width = cv.height = 1
  191 |               const ctx = cv.getContext('2d', { willReadFrequently: true })!
  192 |               ctx.fillStyle = `rgb(${bg[0]},${bg[1]},${bg[2]})`
  193 |               ctx.fillRect(0, 0, 1, 1)
  194 |               const before = ctx.fillStyle
  195 |               ctx.fillStyle = color
  196 |               // On a colour the browser cannot parse, fillStyle keeps its previous
  197 |               // value — which would silently report the background as the
  198 |               // foreground and pass at 1:1. Refuse to guess instead.
  199 |               if (ctx.fillStyle === before && color !== `rgb(${bg.join(', ')}`)
  200 |                 return null
  201 |               ctx.fillRect(0, 0, 1, 1)
  202 |               const d = ctx.getImageData(0, 0, 1, 1).data
  203 |               return [d[0], d[1], d[2]]
  204 |             }
  205 | 
  206 |             const parse = (c: string) => {
  207 |               const m = (c.match(/-?[\d.]+/g) || []).map(Number)
  208 |               return m.length >= 3 && !/okl|lab|lch/.test(c)
  209 |                 ? { rgb: m.slice(0, 3), a: m[3] ?? 1 }
  210 |                 : null
  211 |             }
  212 | 
  213 |             const out: {
  214 |               fg: number[]
  215 |               bg: number[]
  216 |               size: number
  217 |               weight: number
  218 |               sample: string
  219 |             }[] = []
  220 |             const seen = new Set<string>()
  221 | 
  222 |             const bgUnder = (start: Element): number[] | null => {
  223 |               let e: Element | null = start
  224 |               while (e) {
  225 |                 const c = parse(getComputedStyle(e).backgroundColor)
  226 |                 if (c && c.a > 0.5) return c.rgb
  227 |                 e = e.parentElement
  228 |               }
  229 |               return null
  230 |             }
  231 | 
  232 |             // Placeholders are text, and the loop below cannot see them: it keys
  233 |             // off `el.textContent`, and an empty field has none. They are also the
  234 |             // worst thing to lose, because in this app the placeholder carries the
  235 |             // worked example — it shows the reader what a good answer looks like.
  236 |             for (const el of document.querySelectorAll('input, textarea')) {
  237 |               const ph = (el as HTMLInputElement).placeholder
  238 |               if (!ph) continue
  239 |               const cs = getComputedStyle(el, '::placeholder')
  240 |               const bg = bgUnder(el)
  241 |               if (!bg) continue
  242 |               const rgb = raster(cs.color, bg)
  243 |               if (!rgb) continue
  244 |               const key = `ph|${rgb}|${bg}|${Math.round(parseFloat(cs.fontSize))}`
  245 |               if (seen.has(key)) continue
  246 |               seen.add(key)
  247 |               out.push({
  248 |                 fg: rgb,
  249 |                 bg,
  250 |                 size: parseFloat(cs.fontSize),
  251 |                 weight: parseInt(cs.fontWeight) || 400,
  252 |                 sample: `placeholder: ${ph.slice(0, 20)}`,
```