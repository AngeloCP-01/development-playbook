import os,subprocess,signal,time,urllib.request,json,hashlib
from pathlib import Path
root=Path.cwd();out=root/'.superpowers/sdd/2026-10-20-stage-10-interactive-port/task-9-evidence';web=root/'web';env=os.environ.copy();env.pop('NO_COLOR',None)
results=[];server=None;server_log=None

def command(name,args,cwd=root):
 with (out/(name+'.log')).open('w') as f:
  f.write('$ '+' '.join(args)+'\n');f.flush();p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);f.write('\nEXIT_CODE='+str(p.returncode)+'\n')
 results.append({'name':name,'command':args,'exit':p.returncode});(out/'target-cycle-results.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True);return p.returncode

def start(name):
 global server,server_log
 server_log=(out/(name+'-server.log')).open('w');server=subprocess.Popen(['pnpm','start','-p','3100'],cwd=web,env=env,stdout=server_log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:
   if urllib.request.urlopen('http://localhost:3100/').status==200:return
  except Exception:pass
  time.sleep(.2)
 raise RuntimeError('server failed')

def stop():
 global server
 if server:
  os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=20);server=None;server_log.close()

lookup=web/'src/features/documentation/LookupPanels.tsx';record=web/'src/features/documentation/RecordPanels.tsx';oldl=lookup.read_bytes();oldr=record.read_bytes()
(out/'I3-LookupPanels-before.tsx').write_bytes(oldl);(out/'I3-RecordPanels-before.tsx').write_bytes(oldr)
fixedl=oldl.decode().replace('href="/stages/05-development#commits">','href="/stages/05-development#commits" className="inline-flex min-h-11 items-center">')
fixedr=oldr.decode().replace('href="/stages/16-incident-management" className="t-ui"','href="/stages/16-incident-management" className="t-ui inline-flex min-h-11 items-center"')
try:
 start('I3-red');assert command('I3-red',['node',str(out/'targets.cjs')])==1;stop()
 lookup.write_text(fixedl);record.write_text(fixedr)
 assert command('I3-format',['pnpm','exec','prettier','--write','src/features/documentation/LookupPanels.tsx','src/features/documentation/RecordPanels.tsx'],web)==0
 greenl=lookup.read_bytes();greenr=record.read_bytes();(out/'I3-LookupPanels-green.tsx').write_bytes(greenl);(out/'I3-RecordPanels-green.tsx').write_bytes(greenr)
 assert command('I3-build-green',['pnpm','build'],web)==0
 start('I3-green');assert command('I3-green',['node',str(out/'targets.cjs')])==0;assert command('fonts-after',['node',str(out/'fonts.cjs')])==0;stop()
 lookup.write_bytes(greenl.replace(b'className="inline-flex min-h-11 items-center"',b'className="inline-flex items-center"'))
 assert lookup.read_bytes()!=greenl
 command('I3-mutation-diff',['git','diff','--','web/src/features/documentation/LookupPanels.tsx'])
 assert command('I3-build-teeth',['pnpm','build'],web)==0
 start('I3-teeth');assert command('I3-teeth',['node',str(out/'targets.cjs')])==1;stop()
finally:
 stop()
 if 'greenl' in locals():lookup.write_bytes(greenl);record.write_bytes(greenr)
(out/'I3-restoration.json').write_text(json.dumps({'lookupRestored':lookup.read_bytes()==greenl,'recordRestored':record.read_bytes()==greenr,'lookupSha256':hashlib.sha256(greenl).hexdigest(),'recordSha256':hashlib.sha256(greenr).hexdigest()},indent=2))
assert command('I3-build-restored',['pnpm','build'],web)==0
try:
 start('I3-restored');assert command('I3-restored',['node',str(out/'targets.cjs')])==0
finally:stop()
