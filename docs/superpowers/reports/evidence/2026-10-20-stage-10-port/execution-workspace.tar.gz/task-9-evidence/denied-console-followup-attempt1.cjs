const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = process.cwd();
const out = path.join(root, '.superpowers/sdd/2026-10-20-stage-10-interactive-port/task-9-evidence');
const { chromium, expect } = require(path.join(root, 'web/node_modules/@playwright/test'));
const expectedBuild = 'YDyl-9Cl-MRjn8rpkfEza';
const recordKey = 'playbook:documentation-change:v1';
const panels = ['your-change', 'your-evidence', 'checklist'];
const widths = [320, 390, 768, 1024, 1440, 1920, 2560];
const saving = 'Saving is unavailable. This draft stays editable across these panels; export it before leaving or reloading.';
const clearing = 'The visible record is cleared, but the saved copy could return after reload. Clearing storage is unavailable; retry or remove it in browser settings.';
const manualMessage = 'Copy is unavailable. Select the current Markdown below and copy it manually.';
const reference = JSON.parse(fs.readFileSync(path.join(out, 'application-reader-handoff.json'), 'utf8'));
const records = [], errors = [], contexts = [];
function identity() {
  const files = Object.fromEntries(Object.keys(reference.files).map(file => [file, crypto.createHash('sha256').update(fs.readFileSync(path.join(root, file))).digest('hex')]));
  return { buildId: fs.readFileSync(path.join(root, 'web/.next/BUILD_ID'), 'utf8').trim(), sourceIdentity: crypto.createHash('sha256').update('{'+Object.keys(files).sort().map(key => JSON.stringify(key)+': '+JSON.stringify(files[key])).join(', ')+'}').digest('hex'), filesMatch: Object.entries(files).every(([file, digest]) => digest === reference.files[file]), files };
}
async function observe(page, meta) {
  const panel = page.locator('#panel-' + meta.id);
  const data = await panel.evaluate(el => ({
    warnings: [...el.querySelectorAll('.text-warn')].map(n => n.textContent).filter(Boolean),
    statuses: [...el.querySelectorAll('[role=status]')].map(n => n.textContent),
    fields: [...el.querySelectorAll('textarea')].map(n => ({ value: n.value, readonly: n.readOnly, name: [...n.labels].map(l => l.textContent).join(' ') })),
    buttons: [...el.querySelectorAll('button')].map(n => ({ name: n.textContent.trim(), disabled: n.disabled })),
    checked: [...el.querySelectorAll('input[type=checkbox]')].filter(n => n.checked).length,
    denied: { ...window.__documentationDeniedProbe },
    clipboardMissing: navigator.clipboard === undefined,
  }));
  records.push({ ...meta, ...data });
}
(async () => {
  let browser;
  const before = identity();
  const result = { started: new Date().toISOString(), expectedBuild, before, records, errors, contexts };
  try {
    assert.equal(before.buildId, expectedBuild, 'disk production build must remain the agreed build');
    assert.equal(before.sourceIdentity, reference.sourceIdentity);
    assert.equal(before.filesMatch, true, 'all 567 application files must match the accepted handoff manifest');
    const response = await fetch('http://localhost:3100/');
    assert.equal(response.status, 200);
    assert.ok((await response.text()).includes(expectedBuild), 'served production HTML must match agreed BUILD_ID');
    browser = await chromium.launch({ headless: true });
    for (const theme of ['light', 'dark']) for (const width of widths) {
      const context = await browser.newContext({ viewport: { width, height: 768 }, colorScheme: theme });
      await context.addInitScript(({ theme, recordKey }) => {
        localStorage.setItem('playbook:theme', JSON.stringify(theme));
        window.__documentationDeniedProbe = { read: 0, write: 0, clear: 0 };
        const read = Storage.prototype.getItem;
        const write = Storage.prototype.setItem;
        const remove = Storage.prototype.removeItem;
        Storage.prototype.getItem = function(key) { if (key === recordKey) { window.__documentationDeniedProbe.read++; throw new DOMException('denied', 'SecurityError'); } return read.call(this, key); };
        Storage.prototype.setItem = function(key, value) { if (key === recordKey) { window.__documentationDeniedProbe.write++; throw new DOMException('quota', 'QuotaExceededError'); } return write.call(this, key, value); };
        Storage.prototype.removeItem = function(key) { if (key === recordKey) { window.__documentationDeniedProbe.clear++; throw new DOMException('denied', 'SecurityError'); } return remove.call(this, key); };
        Object.defineProperty(navigator, 'clipboard', { configurable: true, value: undefined });
      }, { theme, recordKey });
      const page = await context.newPage();
      // Both listeners are attached before the first navigation and stay until context close.
      page.on('pageerror', e => errors.push({ theme, width, url: page.url(), kind: 'pageerror', message: e.message }));
      page.on('console', message => { if (message.type() === 'error') errors.push({ theme, width, url: page.url(), kind: 'console.error', message: message.text() }); });
      const startCount = records.length;
      for (const id of panels) {
        const meta = { theme, width, id };
        await page.goto('http://localhost:3100/stages/10-documentation#' + id, { waitUntil: 'networkidle' });
        const panel = page.locator('#panel-' + id);
        await expect(panel).toBeVisible();
        await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
        await expect(panel.getByText(saving, { exact: true })).toBeVisible();
        await expect(panel.getByRole('button', { name: 'Copy as Markdown', exact: true })).toBeDisabled();
        assert.ok(await page.evaluate(() => window.__documentationDeniedProbe.read > 0));
        assert.equal(await page.evaluate(() => navigator.clipboard === undefined), true);
        await observe(page, { ...meta, state: 'read-warning' });
        const writes = await page.evaluate(() => window.__documentationDeniedProbe.write);
        const sentinel = `Denied console probe ${theme} ${width} ${id}`;
        if (id === 'checklist') { await panel.getByRole('checkbox').first().check(); await expect(panel.getByRole('checkbox').first()).toBeChecked(); }
        else { const field = panel.locator('textarea:not([readonly])').first(); await field.fill(sentinel); await expect(field).toHaveValue(sentinel); }
        assert.ok(await page.evaluate(() => window.__documentationDeniedProbe.write) > writes, 'write failure must actually be exercised');
        await expect(panel.getByText(saving, { exact: true })).toBeVisible();
        await expect(panel.getByRole('button', { name: 'Copy as Markdown', exact: true })).toBeEnabled();
        await expect(panel.getByRole('button', { name: 'Clear whole record', exact: true })).toBeEnabled();
        await observe(page, { ...meta, state: 'write-warning' });
        await panel.getByRole('button', { name: 'Copy as Markdown', exact: true }).click();
        await expect(panel.getByRole('status', { name: 'Copy status: Copy as Markdown', exact: true })).toHaveText(manualMessage);
        const manual = panel.getByLabel('Markdown record', { exact: true });
        await expect(manual).toBeVisible();
        await expect(manual).toHaveAttribute('readonly', '');
        const text = await manual.inputValue();
        assert.ok(text.includes('# Documentation change plan'));
        if (id === 'checklist') assert.ok(text.includes('- [x]'), 'manual export must contain the selected check');
        else assert.ok(text.includes(sentinel), 'manual export must contain the actual unsaved field');
        await observe(page, { ...meta, state: 'missing-api-manual' });
        const clears = await page.evaluate(() => window.__documentationDeniedProbe.clear);
        page.once('dialog', dialog => dialog.accept());
        await panel.getByRole('button', { name: 'Clear whole record', exact: true }).click();
        await expect(panel.getByText(clearing, { exact: true })).toBeVisible();
        assert.ok(await page.evaluate(() => window.__documentationDeniedProbe.clear) > clears, 'clear failure must actually be exercised');
        await expect(panel.getByRole('button', { name: 'Copy as Markdown', exact: true })).toBeDisabled();
        await expect(panel.getByRole('button', { name: 'Clear whole record', exact: true })).toBeEnabled();
        if (id === 'checklist') assert.equal(await panel.getByRole('checkbox').evaluateAll(nodes => nodes.filter(n => n.checked).length), 0);
        else for (const field of await panel.locator('textarea:not([readonly])').all()) await expect(field).toHaveValue('');
        await expect(manual).toBeVisible();
        assert.ok(!(await manual.inputValue()).includes(sentinel));
        assert.ok(!(await manual.inputValue()).includes('- [x]'));
        await observe(page, { ...meta, state: 'clear-warning' });
      }
      await page.waitForTimeout(150);
      await context.close();
      const observed = records.length - startCount;
      assert.equal(observed, 12, 'each theme/width context must actually observe all 3 panels x 4 states');
      contexts.push({ theme, width, observed, consoleErrorListener: true, pageErrorListener: true });
      console.log(JSON.stringify({ context: { theme, width }, observed, errorsSoFar: errors.length }));
    }
    result.after = identity();
    assert.equal(result.after.filesMatch, true);
    assert.equal(result.after.sourceIdentity, reference.sourceIdentity);
    assert.equal(result.after.buildId, expectedBuild);
    assert.equal(contexts.length, 14);
    assert.equal(records.length, 168);
    assert.ok(records.length > 0);
    assert.deepEqual(errors, [], 'denied contexts must emit neither pageerror nor console.error');
    result.status = 'PASS';
    result.summary = { contexts: contexts.length, panels: panels.length, themes: 2, widths, observedStates: records.length, consoleErrors: errors.filter(e => e.kind === 'console.error').length, pageErrors: errors.filter(e => e.kind === 'pageerror').length, buildId: expectedBuild, applicationFiles: Object.keys(reference.files).length, sourceFilesMatchBeforeAndAfter: before.filesMatch && result.after.filesMatch };
    console.log(JSON.stringify(result.summary, null, 2));
  } catch (error) { result.status = 'FAIL'; result.failure = String(error.stack || error); console.error(error); process.exitCode = 1; }
  finally { if (browser) await browser.close(); result.finished = new Date().toISOString(); fs.writeFileSync(path.join(out, 'denied-console-followup.json'), JSON.stringify(result, null, 2)); }
})();
