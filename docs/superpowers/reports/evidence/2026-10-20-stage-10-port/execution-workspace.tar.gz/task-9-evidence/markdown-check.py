from pathlib import Path
import re,urllib.parse,json
paths=[Path('docs/stage-10-status.md'),Path('docs/superpowers/reports/2026-10-20-stage-10-port-execution.md')]
links=[];failures=[]
for p in paths:
 s=re.sub(r'```[\s\S]*?```','',p.read_text())
 for raw in re.findall(r'\[[^\]]+\]\(([^)]+)\)',s):
  target=raw.split()[0].strip('<>');u=urllib.parse.urlsplit(target)
  if u.scheme or target.startswith('#'):continue
  q=(p.parent/urllib.parse.unquote(u.path)).resolve();row={'source':str(p),'target':target,'exists':q.is_file()};links.append(row)
  if not row['exists']:failures.append(row)
print(json.dumps({'localLinks':links,'failures':failures},indent=2))
raise SystemExit(bool(failures))
