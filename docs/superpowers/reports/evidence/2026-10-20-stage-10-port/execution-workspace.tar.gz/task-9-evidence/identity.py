from pathlib import Path
import hashlib,json,subprocess,datetime,sys,urllib.request
label=sys.argv[1];base=Path('.superpowers/sdd/2026-10-20-stage-10-interactive-port');out=base/'task-9-evidence'
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['web/src','web/public'] for p in sorted(Path(d).rglob('*')) if p.is_file()}
for p in map(Path,['web/next.config.ts','web/postcss.config.mjs','web/tsconfig.json','web/package.json','web/pnpm-lock.yaml']):files[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
parent=Path('/Users/angelito/personal/Development-Playbook');old=json.loads((base/'parent-before.json').read_text());after={p:hashlib.sha256((parent/p).read_bytes()).hexdigest() for p in old}
info={'time':datetime.datetime.now().astimezone().isoformat(),'head':subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True).stdout.strip(),'buildId':Path('web/.next/BUILD_ID').read_text().strip(),'files':files,'sourceIdentity':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest(),'parentHashesPreserved':old==after,'parentHashes':after}
try:info['servedBuildMatches']=info['buildId'] in urllib.request.urlopen('http://localhost:3100/').read().decode()
except Exception as e:info['servedBuildCheck']=str(e)
(out/('application-'+label+'.json')).write_text(json.dumps(info,indent=2));print(json.dumps({k:v for k,v in info.items() if k not in ['files','parentHashes']},indent=2))
