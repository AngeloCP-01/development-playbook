### Task 8: Assemble and register the complete stage as one unit

**Files:** Create `closing.tsx`, `steps.ts`, `Documentation.tsx`,
`Documentation.test.tsx`, `coverage.test.ts`, `web/e2e/documentation.spec.ts`. Modify
`web/src/features/stage-content.ts`, `web/src/features/step-ids.ts`,
`web/src/lib/stages.ts`, `web/src/lib/references.ts`, and
`web/e2e/audit-pages.spec.ts`.

**Interfaces:** Consumes every prior panel. Produces `Documentation()`, `STEPS`,
`STEP_IDS`/`StepId`, `COVERAGE`, `TrapsPanel()` and registration for `10-documentation`.
The exported stage entry remains synchronous. No new route, title or theme token.
The production flow spec created here is also Task 9's verification instrument.

- [ ] **Step 1: Write the complete `Documentation.test.tsx`.**

```tsx
import { fireEvent, render, screen } from '@testing-library/react'
import { afterEach, expect, test } from 'vitest'
import { getStage } from '@/lib/stages'
import { getReferences } from '@/lib/references'
import { STAGE_CONTENT } from '../stage-content'
import { STEP_IDS_BY_SLUG } from '../step-ids'
import { Documentation } from './Documentation'
import { STEP_IDS } from './steps'
import { TRAPS } from './closing'
afterEach(() => { window.localStorage.clear(); window.history.replaceState(null, '', '/') })
test('documentation is a continuous registered stage whose declared rail includes every approved judgment', () => {
  const ids = ['choose', 'readme', 'decisions', 'reference', 'comments', 'changes', 'history', 'ai', 'your-change', 'your-evidence', 'checklist', 'traps']
  expect([...STEP_IDS]).toEqual(ids)
  expect(STEP_IDS_BY_SLUG['10-documentation']).toEqual(ids)
  expect(getStage('10-documentation')).toMatchObject({ ready: true, cadence: 'Continuous', timing: 'Continuously, a little with every change.', blurb: 'Help the next person use the system, and preserve the reasons behind it.' })
  expect(STAGE_CONTENT['10-documentation']).toBe(Documentation)
  render(<Documentation />)
  const rail = screen.getByRole('tablist', { name: 'Stage steps' })
  expect([...rail.querySelectorAll('[role=tab]')].map(tab => tab.id)).toEqual(ids.map(id => `tab-${id}`))
  for (const id of ids) {
    fireEvent.click(document.getElementById(`tab-${id}`)!)
    expect(document.getElementById(`panel-${id}`)).toBeTruthy()
    expect(document.getElementById(`panel-${id}`)!.querySelector('button,input,textarea,[role=tablist]')).toBeTruthy()
  }
})
test('all eight traps reveal corrective action and the references add five distinct sources', () => {
  render(<Documentation />); fireEvent.click(document.getElementById('tab-traps')!)
  expect(TRAPS.map(t => t.id)).toEqual(['late', 'why-only', 'templates', 'history', 'generation', 'claims', 'privacy', 'evidence'])
  for (const trap of TRAPS) { fireEvent.click(screen.getByRole('button', { name: trap.title })); expect(screen.getByText(trap.detail)).toBeTruthy() }
  expect(getReferences('10-documentation').map(r => r.url)).toEqual([
    'https://diataxis.fr/start-here/',
    'https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes',
    'https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions',
    'https://c4model.com/diagrams/checklist',
    'https://www.writethedocs.org/guide/docs-as-code/',
  ])
  for (const reference of getReferences('10-documentation')) expect(screen.getByRole('link', { name: new RegExp(reference.title) }).getAttribute('href')).toBe(reference.url)
})
```

**Write `coverage.test.ts` before assembly too:**

```ts
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { expect, test } from 'vitest'
import { CHECKS } from './record'
import { COVERAGE, STEP_IDS } from './steps'
function headings(md: string): string[] {
  let fence: { marker: string; size: number } | undefined
  const result: string[] = []
  for (const line of md.split('\n')) {
    const delimiter = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/)
    if (delimiter) {
      const marker = delimiter[1][0]; const size = delimiter[1].length
      if (!fence) fence = { marker, size }
      else if (fence.marker === marker && size >= fence.size && delimiter[2].trim() === '') fence = undefined
      continue
    }
    const heading = !fence && line.match(/^#{2,3} (.+)$/)
    if (heading && heading[1] !== 'The work') result.push(heading[1])
  }
  return result
}
test('every canonical section has a real panel while specimen headings stay inside their fence', () => {
  expect(headings('## Entry criteria\n```markdown\n## Fake\n```\n### Real')).toEqual(['Entry criteria', 'Real'])
  const chapter = readFileSync(resolve(process.cwd(), '../docs/10-documentation.md'), 'utf8')
  expect(Object.keys(COVERAGE)).toEqual(headings(chapter))
  for (const ids of Object.values(COVERAGE)) {
    expect(ids.length).toBeGreaterThan(0)
    for (const id of ids) expect(STEP_IDS).toContain(id)
  }
  const expectedChecks = chapter.split('## Definition of done')[1].split('## Scaling to a team')[0]
  expect(CHECKS.map(check => check.text)).toEqual([...expectedChecks.matchAll(/^- \[ \] (.+)$/gm)].map(match => match[1]))
})
```

**Write `web/e2e/documentation.spec.ts` now, before registration:**

```ts
import { expect, test } from '@playwright/test'
import { CHECKS, RECORD_KEY } from '../src/features/documentation/record'
const STAGE = '/stages/10-documentation'

test('documentation retains a literal change record across hashes history and reload in both themes', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  const literal = '<script>window.__documentationExecuted=true</script>' + 'x'.repeat(600)
  for (const theme of ['light', 'dark'] as const) {
    await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
    await page.evaluate(({ key, theme }) => { localStorage.removeItem(key); localStorage.setItem('playbook:theme', JSON.stringify(theme)) }, { key: RECORD_KEY, theme })
    await page.reload({ waitUntil: 'networkidle' })
    await expect(page.locator('html')).toHaveAttribute('data-theme', theme)
    await page.getByLabel('Change and scope', { exact: true }).fill(literal)
    await page.locator('#tab-your-evidence').click()
    await page.getByLabel('Observed evidence and limits', { exact: true }).fill('Not executed; source review only')
    await page.goBack(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue(literal)
    await page.goForward(); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
    await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByLabel('Observed evidence and limits', { exact: true })).toHaveValue('Not executed; source review only')
    await page.locator('#tab-checklist').click(); await page.getByRole('checkbox', { name: CHECKS[9].text }).check()
    await page.reload({ waitUntil: 'networkidle' }); await expect(page.getByRole('checkbox', { name: CHECKS[9].text })).toBeChecked()
    for (const width of [320, 390, 768, 1024, 1440, 1920, 2560]) {
      await page.setViewportSize({ width, height: 900 })
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true)
    }
    expect(await page.evaluate(() => Reflect.get(window, '__documentationExecuted'))).toBeUndefined()
    page.once('dialog', dialog => dialog.accept())
    await page.getByRole('button', { name: 'Clear whole record' }).click()
    expect(await page.evaluate(key => localStorage.getItem(key), RECORD_KEY)).toBeNull()
  }
  expect(errors).toEqual([])
})

test('documentation keeps an unsaved cross-panel draft and offers exact manual export when permissions fail', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message))
  await page.addInitScript(key => {
    const read = Storage.prototype.getItem; const write = Storage.prototype.setItem
    Storage.prototype.getItem = function(name) { if (name === key) throw new DOMException('denied', 'SecurityError'); return read.call(this, name) }
    Storage.prototype.setItem = function(name, value) { if (name === key) throw new DOMException('quota', 'QuotaExceededError'); return write.call(this, name, value) }
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: () => Promise.reject(new Error('denied')) } })
  }, RECORD_KEY)
  await page.goto(`${STAGE}#your-change`, { waitUntil: 'networkidle' })
  await page.getByLabel('Change and scope', { exact: true }).fill('Unsaved change')
  await page.locator('#tab-your-evidence').click()
  await page.getByLabel('Owner and reviewer', { exact: true }).fill('Me')
  await page.getByRole('button', { name: 'Copy as Markdown' }).click()
  await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Unsaved change/)
  await expect(page.getByLabel('Markdown record', { exact: true })).toHaveValue(/Me/)
  await expect(page.getByText(/Saving is unavailable/)).toBeVisible()
  await page.locator('#tab-your-change').click(); await expect(page.getByLabel('Change and scope', { exact: true })).toHaveValue('Unsaved change')
  expect(errors).toEqual([])
})

test('documentation exposes replaced history and reasoning after a wrong keyboard answer', async ({ page }) => {
  await page.goto(`${STAGE}#decisions`, { waitUntil: 'networkidle' })
  await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  await page.getByRole('button', { name: 'Read ADR 005' }).click()
  await expect(page.getByRole('region', { name: 'docs/adr/005-generated-contract-reference.md' })).toBeVisible()
  await page.getByRole('button', { name: 'Read ADR 004' }).click()
  await expect(page.getByText('2026-10-20 — Current status: Superseded.')).toBeVisible()
  await page.locator('#tab-comments').click()
  const radios = page.locator('#panel-comments').getByRole('radio')
  await radios.first().focus(); await radios.first().press('Space'); await radios.first().press('ArrowDown')
  await expect(radios.nth(1)).toBeChecked()
  expect((await radios.nth(1).boundingBox())!.height).toBeGreaterThanOrEqual(44)
  await page.getByRole('button', { name: 'Check answer' }).click()
  await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
  await expect(page.getByText(/It supplies no evidence of silent truncation/)).toBeVisible()
  await page.locator('#tab-history').click(); await page.locator('#tab-comments').click()
  await expect(page.getByText('0 of 1 decisions correct')).toBeVisible()
})
```

- [ ] **Step 2: Capture RED from the unit stage test and targeted browser spec against the current unregistered build.** Run `pnpm test src/features/documentation/Documentation.test.tsx`, then `pnpm exec playwright test e2e/documentation.spec.ts`. A production build may need the same permitted Google Fonts network access as the chapter round. Do not count a network/build-start failure as the expected UI RED; the intended browser failure is missing Stage 10 controls in the placeholder. Keep the old negative-placeholder test unchanged until registration.
- [ ] **Step 3: Add full assembly sources.** `closing.tsx`:

```tsx
import { RevealList } from '@/components/RevealList'
import { Section } from '@/components/ui'
export const TRAPS = [
  { id: 'late', title: 'Documentation waits until the end', detail: 'Record the reason and evidence with the change.' },
  { id: 'why-only', title: 'The why-only rule hides usable instructions', detail: 'Setup instructions and exact reference facts answer legitimate reader needs. Keep comment advice scoped to comments.' },
  { id: 'templates', title: 'Every template becomes mandatory', detail: 'Choose artifacts for real readers and tasks; maintain the smallest set that works.' },
  { id: 'history', title: 'Cleaning instructions deletes decision history', detail: 'Preserve the record and expose its replacement. Retire misleading current procedures separately.' },
  { id: 'generation', title: 'Generated output looks automatically correct', detail: 'Inspect the source and expected output diff; check behavior where the claim depends on behavior.' },
  { id: 'claims', title: 'Template infrastructure and test claims survive copying', detail: 'Replace sample assertions with project facts and observed evidence.' },
  { id: 'privacy', title: 'Realistic examples disclose private data', detail: 'Use synthetic data and review the result before publication.' },
  { id: 'evidence', title: 'A successful-looking draft stands in for validation', detail: 'Find the evidence behind each operational claim; record what remains unknown.' },
] as const
export function TrapsPanel() {
  return <Section title="Spot documentation traps"><RevealList idPrefix="documentation-traps" rows={TRAPS.map(trap => ({ id: trap.id, title: trap.title, body: <p>{trap.detail}</p> }))} /></Section>
}
```

`steps.ts`:

```ts
import { createElement } from 'react'
import type { Step } from '@/components/Stepper'
import { ReadmePanel, DecisionsPanel } from './DocumentPanels'
import { ChoosePanel, ReferencePanel, ChangesPanel, HistoryPanel } from './LookupPanels'
import { AIPanel, CommentsPanel } from './PracticePanels'
import { RecordPanel, ChecklistPanel } from './RecordPanels'
import { TrapsPanel } from './closing'
export const STEP_IDS = ['choose', 'readme', 'decisions', 'reference', 'comments', 'changes', 'history', 'ai', 'your-change', 'your-evidence', 'checklist', 'traps'] as const
export type StepId = (typeof STEP_IDS)[number]
export const STEPS: (Step & { id: StepId })[] = [
  { id: 'choose', label: 'Choose a document', hint: 'Start from a reader and a task', content: createElement(ChoosePanel) },
  { id: 'readme', label: 'Verify the README', hint: 'Check setup from a fresh clone', content: createElement(ReadmePanel) },
  { id: 'decisions', label: 'Replace a decision', hint: 'Preserve history and expose current status', content: createElement(DecisionsPanel) },
  { id: 'reference', label: 'State exact facts', hint: 'Name sources, versions and absence behavior', content: createElement(ReferencePanel) },
  { id: 'comments', label: 'Explain the exception', hint: 'Practise the four useful comment patterns', content: createElement(CommentsPanel) },
  { id: 'changes', label: 'Trace the change', hint: 'Connect facts to documents and checks', content: createElement(ChangesPanel) },
  { id: 'history', label: 'Keep history usable', hint: 'Preserve records and repair current instructions', content: createElement(HistoryPanel) },
  { id: 'ai', label: 'Check the evidence', hint: 'Ground AI drafts and qualify validation', content: createElement(AIPanel) },
  { id: 'your-change', label: 'Plan your change', hint: 'Record your reader, documents and source', content: createElement(RecordPanel, { view: 'change' }) },
  { id: 'your-evidence', label: 'Plan the check', hint: 'Record checks, evidence, ownership and triggers', content: createElement(RecordPanel, { view: 'evidence' }) },
  { id: 'checklist', label: 'Review this change', hint: 'Separate per-change and periodic checks', content: createElement(ChecklistPanel) },
  { id: 'traps', label: 'Spot the trap', hint: 'Recognize assumptions that need correction', content: createElement(TrapsPanel) },
]
```


Append this complete export to `steps.ts`; headings are the canonical citation
unit, not line numbers or names invented by the port:

```ts
export const COVERAGE: Record<string, readonly StepId[]> = {
  'Entry criteria': ['choose'],
  'Choose the document for the reader’s task': ['choose'],
  'Keep the README usable': ['readme'],
  'Record decisions and supersede them visibly': ['decisions'],
  'Keep architecture and contract references current': ['reference'],
  'Write comments for non-obvious reasons': ['comments'],
  'Update and verify documentation with the change': ['changes', 'your-change', 'your-evidence'],
  'Choose what to omit or archive': ['history'],
  'Commit messages preserve change context': ['history'],
  'AI in documentation': ['ai'],
  'Artifacts': ['choose', 'readme', 'decisions', 'reference', 'comments'],
  'Definition of done': ['checklist'],
  'Scaling to a team': ['checklist'],
  'Traps': ['traps'],
}
```

`Documentation.tsx`:

```tsx
import { References } from '@/components/References'
import { Stepper } from '@/components/Stepper'
import { DocumentationSession } from './DocumentationSession'
import { STEPS } from './steps'
export function Documentation() {
  return <><DocumentationSession><Stepper steps={STEPS} /></DocumentationSession><div className="mt-12"><References slug="10-documentation" /></div></>
}
```

Apply these exact additions to existing files, preserving every other entry:

```ts
// stage-content.ts: import and map member
import { Documentation } from './documentation/Documentation'
// In STAGE_CONTENT:
'10-documentation': Documentation,

// step-ids.ts: import and map member
import { STEP_IDS as DOCUMENTATION } from './documentation/steps'
// In STEP_IDS_BY_SLUG:
'10-documentation': DOCUMENTATION,

// stages.ts, Stage 10 only:
blurb: 'Help the next person use the system, and preserve the reasons behind it.',
ready: true,
```

Add this complete entry to `REFERENCES` in `web/src/lib/references.ts`:

```ts
'10-documentation': [
  { title: 'Diátaxis', source: 'Diátaxis', url: 'https://diataxis.fr/start-here/', adds: 'The four reader needs and how to separate guidance that serves incompatible tasks.' },
  { title: 'About READMEs', source: 'GitHub Docs', url: 'https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes', adds: 'Repository entry-point guidance for purpose, getting started, help and maintainers.' },
  { title: 'Documenting Architecture Decisions', source: 'Michael Nygard · Cognitect', url: 'https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions', adds: 'The original rationale for small decision records and preserving superseded decisions.' },
  { title: 'C4 diagram review checklist', source: 'C4 model', url: 'https://c4model.com/diagrams/checklist', adds: 'Specific review questions for scope, notation, elements and labeled relationships.' },
  { title: 'Docs as code', source: 'Write the Docs', url: 'https://www.writethedocs.org/guide/docs-as-code/', adds: 'How version control, review and automation support a documentation workflow.' },
],
```

In `web/e2e/audit-pages.spec.ts` change only the negative-placeholder fixture
and its explanatory comment: `readStepIds(page, '10-documentation')` becomes
`readStepIds(page, '17-maintenance')`, confirmed at `stages.ts:188`. Update the
comment to name Stage 17 and retain the
`rejects.toThrow(/renders no steps/)` assertion. Do not remove the negative guard.

- [ ] **Step 4: Run the complete feature test folder plus shared guards:** `pnpm test src/features/documentation src/features/rails.test.tsx src/lib/stages.test.ts src/lib/references.test.ts src/lib/stage-metadata.test.ts`. Then lint, typecheck, full tests and targeted browser GREEN. The placeholder fixture remains Stage 17 while it is unready.
- [ ] **Step 5: Teeth check.** Remove only TRAPS' detail from the rendered row body; the trap-render test must fail while the underlying array remains correct. Restore and rerun. Separately remove one actual step object without changing STEP_IDS; the rendered-rail guard must fail. Record actual failure counts and restore the exact reviewed source.
- [ ] **Step 6: Independent review and commit** `feat(documentation): register the interactive stage`. The feature tree now has 16 ready stages; develop remains 15/18. Deferred: final browser matrices/readers/whole-branch review, integration and W-6 publication.

