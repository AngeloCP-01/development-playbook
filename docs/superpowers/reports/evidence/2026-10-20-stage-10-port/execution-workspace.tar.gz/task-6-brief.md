### Task 6: Practise comment judgments and evidence classification

**Files:** Create `practice.ts`, `DecisionDrill.tsx`, `PracticePanels.tsx`, `DecisionDrill.test.tsx`.

**Interfaces:** Consumes Task 2's `PracticeRun` and context. Produces immutable
`COMMENT_CASES`, `EVIDENCE_CASES`, `DecisionCase`, `DecisionDrill({ setId, title,
cases })`, `CommentsPanel()` and `AIPanel()`. Known set IDs are `comments` and
`evidence`; committed choices/drafts/index live in the mounted provider.

- [ ] **Step 1: Write full `DecisionDrill.test.tsx`.**

```tsx
import { fireEvent, render, screen } from '@testing-library/react'
import { useState } from 'react'
import { expect, test } from 'vitest'
import { DecisionDrill } from './DecisionDrill'
import { DocumentationSession } from './DocumentationSession'
import { COMMENT_CASES, EVIDENCE_CASES } from './practice'
function Mount({ cases = COMMENT_CASES }: { cases?: typeof COMMENT_CASES }) {
  const [show, setShow] = useState(true)
  return <DocumentationSession><button onClick={() => setShow(v => !v)}>Switch stage panel</button>{show && <DecisionDrill setId="test" title="Practice" cases={cases} />}</DocumentationSession>
}
test('every authored case reveals reasoning after a wrong committed choice and reset removes draft and verdict', () => {
  for (const item of [...COMMENT_CASES, ...EVIDENCE_CASES]) {
    const view = render(<Mount cases={[item]} />)
    expect(screen.queryByText(item.rationale)).toBeNull()
    const wrong = item.options.find(option => option.id !== item.answer)!
    fireEvent.click(screen.getByRole('radio', { name: wrong.text }))
    expect(screen.queryByText(item.rationale)).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'Check answer' }))
    expect(screen.getByText(item.rationale)).toBeTruthy()
    expect(screen.getByText('0 of 1 decisions correct')).toBeTruthy()
    expect((screen.getByRole('radio', { name: wrong.text }) as HTMLInputElement).disabled).toBe(true)
    fireEvent.click(screen.getByRole('button', { name: 'Reset practice' }))
    expect(screen.queryByText(item.rationale)).toBeNull()
    expect((screen.getByRole('radio', { name: wrong.text }) as HTMLInputElement).checked).toBe(false)
    expect(screen.queryByText('0 of 1 decisions correct')).toBeNull()
    view.unmount()
  }
})
test('committed score and an uncommitted next-case draft survive leaving the stage panel', () => {
  render(<Mount />)
  fireEvent.click(screen.getByRole('radio', { name: COMMENT_CASES[0].options.find(o => o.id === COMMENT_CASES[0].answer)!.text }))
  fireEvent.click(screen.getByText('Check answer')); expect(screen.getByText('1 of 1 decisions correct')).toBeTruthy()
  fireEvent.click(screen.getByText('Next case'))
  fireEvent.click(screen.getByRole('radio', { name: COMMENT_CASES[1].options[0].text }))
  fireEvent.click(screen.getByText('Switch stage panel')); fireEvent.click(screen.getByText('Switch stage panel'))
  expect((screen.getByRole('radio', { name: COMMENT_CASES[1].options[0].text }) as HTMLInputElement).checked).toBe(true)
  expect(screen.queryByText(COMMENT_CASES[1].rationale)).toBeNull()
  expect(screen.getByText('1 of 1 decisions correct')).toBeTruthy()
  fireEvent.click(screen.getByText('Previous case')); expect(screen.getByText(COMMENT_CASES[0].rationale)).toBeTruthy()
})
test('the authored sets cover the four comment reasons and three distinct evidence levels', () => {
  expect(COMMENT_CASES.map(c => c.id)).toEqual(['external', 'deviation', 'logic', 'limit'])
  expect(EVIDENCE_CASES.map(c => c.answer)).toEqual(['read', 'compile', 'execute'])
  expect(COMMENT_CASES[0].rationale).toContain('500-character')
  expect(EVIDENCE_CASES[2].rationale).toContain('does not establish production recovery')
  for (const item of [...COMMENT_CASES, ...EVIDENCE_CASES]) {
    expect(item.options.filter(o => o.id === item.answer)).toHaveLength(1)
    expect(new Set(item.options.map(o => o.id)).size).toBe(item.options.length)
  }
})

test('AI drafting requires a reviewer source and privacy checks beyond the practice score', async () => {
  const { AIPanel } = await import('./PracticePanels')
  render(<DocumentationSession><AIPanel /></DocumentationSession>)
  fireEvent.click(screen.getByRole('button', { name: 'Ground and review the draft' }))
  fireEvent.click(screen.getByRole('button', { name: 'Record the limits of validation' }))
  expect(screen.getByText(/A named reviewer/)).toBeTruthy()
  expect(screen.getByText(/Use synthetic identifiers/)).toBeTruthy()
  expect(screen.getByText(/label missing facts/)).toBeTruthy()
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/DecisionDrill.test.tsx`; capture RED.**
- [ ] **Step 3: Add complete authored cases and UI.** `practice.ts`:

```ts
export type DecisionCase = { id: string; prompt: string; excerpt: string; options: readonly { id: string; text: string }[]; answer: string; rationale: string }
export const COMMENT_CASES: readonly DecisionCase[] = [
  { id: 'external', prompt: 'Which explanation is supported by the comment?', excerpt: '// Keep the larger record in our external store and put only its ID in\n// metadata, whose value limit is 500 characters.', options: [
    { id: 'constraint', text: 'The external ID avoids storing a larger value in metadata.' },
    { id: 'outage', text: 'A particular past outage proved that Stripe silently truncates values.' },
  ], answer: 'constraint', rationale: 'Stripe documents a 500-character metadata value limit and recommends an external record ID for larger data. The comment explains that outside constraint. It supplies no evidence of silent truncation, an incident or a retry diagnosis.' },
  { id: 'deviation', prompt: 'Why preserve two forms of the title?', excerpt: '// Preserve the entered title for display. Apply normalization only\n// to the separate lookup key.', options: [
    { id: 'separate-key', text: 'The lookup key and displayed title serve different purposes.' },
    { id: 'restatement', text: 'The comment just repeats the variable assignment.' },
  ], answer: 'separate-key', rationale: 'This explains a deliberate deviation: normalization serves lookup while the original input serves display. Rename unclear code when a good name carries the meaning; retain a comment for intent a name cannot capture.' },
  { id: 'logic', prompt: 'Which condition must a later change preserve?', excerpt: "// This example's date interval includes both endpoints; account for\n// that when converting it to a half-open range.", options: [
    { id: 'exclusive', text: 'The last day is already excluded.' },
    { id: 'inclusive', text: 'Both endpoints are included in this illustrative interval.' },
  ], answer: 'inclusive', rationale: 'The comment explains tricky interval logic and its conversion constraint. It does not establish the date semantics of an unrelated application.' },
  { id: 'limit', prompt: 'What does the caller need to learn?', excerpt: '// This illustrative export handles at most 1000 rows. Expose that cap\n// to callers and revisit it before accepting larger exports.', options: [
    { id: 'unlimited', text: 'The export accepts arbitrary sizes.' },
    { id: 'cap', text: 'The example has a 1000-row cap that must be exposed and revisited.' },
  ], answer: 'cap', rationale: 'A known limitation belongs where callers can discover it. This is an illustrative limit, not a measured property of the playbook.' },
]
const evidenceOptions = [ { id: 'read', text: 'Read: compared with an identified source' }, { id: 'compile', text: 'Compile: passed the stated compiler checks' }, { id: 'execute', text: 'Execute: ran with an observed result' } ] as const
export const EVIDENCE_CASES: readonly DecisionCase[] = [
  { id: 'read', prompt: 'What does this hypothetical review establish?', excerpt: 'The reviewer compared the draft with the identified contract revision. No example was compiled or command run.', options: evidenceOptions, answer: 'read', rationale: 'Read evidence establishes comparison with an identified source. It does not establish compilation or execution.' },
  { id: 'compile', prompt: 'What does this hypothetical compiler report establish?', excerpt: 'A named synthetic example passed tsc --noEmit at the recorded revision. No runtime behavior was exercised.', options: evidenceOptions, answer: 'compile', rationale: 'Compile evidence establishes the stated compiler/type checks for that example. It does not establish a successful procedure or production behavior.' },
  { id: 'execute', prompt: 'What does this hypothetical isolated run establish?', excerpt: 'Command: node check-example.mjs. Revision: illustrative-r1. Environment: isolated synthetic fixture. Observed result: expected sample output, exit 0.', options: evidenceOptions, answer: 'execute', rationale: 'Execute evidence names a command, revision, environment and observed result. This isolated example does not establish production recovery; record its limits.' },
]
```

`DecisionDrill.tsx`:

```tsx
'use client'
import { useId } from 'react'
import { Card } from '@/components/ui'
import { EMPTY_PRACTICE, useDocumentationSession } from './DocumentationSession'
import type { DecisionCase } from './practice'
export function DecisionDrill({ setId, title, cases }: { setId: string; title: string; cases: readonly DecisionCase[] }) {
  const root = useId(); const { practices, setPractice } = useDocumentationSession()
  const run = practices[setId] ?? EMPTY_PRACTICE
  const item = cases[run.index]
  if (!item) return <p>No cases are available.</p>
  const committed = Object.hasOwn(run.choices, item.id)
  const choice = committed ? run.choices[item.id] : run.drafts[item.id]
  const answered = cases.filter(c => Object.hasOwn(run.choices, c.id)).length
  const correct = cases.filter(c => run.choices[c.id] === c.answer).length
  const validDraft = item.options.some(o => o.id === run.drafts[item.id])
  return <Card><p className="t-label mb-2 text-brand">Illustrative practice</p><h3 className="t-head mb-3 text-lg">{title}</h3>
    <p className="t-data mb-3 text-sm text-muted">Case {run.index + 1} of {cases.length}</p>
    <p aria-live="polite" className="mb-3 text-sm text-muted">{answered ? `${correct} of ${answered} decisions correct` : ''}</p>
    <pre className="mb-4 whitespace-pre-wrap break-words border border-line bg-sunken p-3 text-sm leading-relaxed text-fg">{item.excerpt}</pre>
    <fieldset disabled={committed} className="min-w-0 space-y-2"><legend className="mb-3 text-sm font-medium">{item.prompt}</legend>
      {item.options.map(option => <label key={option.id} className="relative flex min-h-11 cursor-pointer items-start gap-3 border border-line p-3 text-sm focus-within:outline-2 focus-within:outline-brand">
        <input type="radio" name={`${root}-${item.id}`} checked={choice === option.id} onChange={() => setPractice(setId, old => ({ ...old, drafts: { ...old.drafts, [item.id]: option.id } }))} disabled={committed} className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0" />
        <span aria-hidden className="mt-1 size-4 shrink-0 rounded-full border border-line peer-checked:border-brand peer-checked:bg-brand" /><span className="min-w-0 break-words">{option.text}</span>
      </label>)}
    </fieldset>
    <button type="button" disabled={committed || !validDraft} onClick={() => setPractice(setId, old => ({ ...old, choices: { ...old.choices, [item.id]: old.drafts[item.id] } }))} className="mt-4 min-h-11 border border-line px-4 text-sm disabled:text-subtle">Check answer</button>
    {committed && <div role="status" className="mt-4 border border-line bg-sunken p-4"><p className={`mb-2 text-sm font-semibold ${choice === item.answer ? 'text-go' : 'text-danger'}`}>{choice === item.answer ? 'Correct' : 'Reconsider'}</p><p className="text-sm leading-relaxed text-muted">{item.rationale}</p></div>}
    <div className="mt-4 flex flex-wrap gap-2">
      <button type="button" disabled={run.index === 0} onClick={() => setPractice(setId, old => ({ ...old, index: old.index - 1 }))} className="min-h-11 border border-line px-3 text-sm disabled:text-subtle">Previous case</button>
      <button type="button" disabled={run.index === cases.length - 1} onClick={() => setPractice(setId, old => ({ ...old, index: old.index + 1 }))} className="min-h-11 border border-line px-3 text-sm disabled:text-subtle">Next case</button>
      <button type="button" onClick={() => setPractice(setId, () => ({ index: 0, drafts: {}, choices: {} }))} className="min-h-11 border border-line px-3 text-sm">Reset practice</button>
    </div>
  </Card>
}
```

`PracticePanels.tsx`:

```tsx
import Link from 'next/link'
import { RevealList } from '@/components/RevealList'
import { Prose, Section } from '@/components/ui'
import { DecisionDrill } from './DecisionDrill'
import { COMMENT_CASES, EVIDENCE_CASES } from './practice'
export function CommentsPanel() {
  return <Section title="Explain the exception in a comment">
    <Prose><p>Implementation comments explain intent or constraints a reader cannot recover from code. Module documentation may describe purpose, use and behavior too. Rename unclear code when a good name carries the meaning.</p><p>The four comment specimens are illustrative patterns, not runnable implementations. <a href="https://google.github.io/eng-practices/review/reviewer/looking-for.html#comments">Google&apos;s review guidance</a> makes the distinction. <a href="https://docs.stripe.com/metadata#data">Stripe&apos;s metadata source</a> supports its value limit; an attempt count alone cannot diagnose a delivery failure.</p></Prose>
    <div className="mt-5"><DecisionDrill setId="comments" title="What does the comment explain?" cases={COMMENT_CASES} /></div>
  </Section>
}
export function AIPanel() {
  return <Section title="AI in documentation">
    <Prose><p>Give an assistant the source and version in scope. It can map affected documents, draft structure, compare an example with a schema and suggest lookup headings. Ask it to label missing facts rather than complete a plausible guess.</p></Prose>
    <div className="mt-5"><DecisionDrill setId="evidence" title="Which evidence do you actually have?" cases={EVIDENCE_CASES} /></div>
    <div className="mt-5"><RevealList idPrefix="documentation-ai" rows={[
      { id: 'review', title: 'Ground and review the draft', body: <div><p>A named reviewer compares the draft with the relevant diff, contract, code, verified procedure or approved notes. Use synthetic identifiers; remove real credentials, contact details and private payloads.</p><p className="mt-3">Permissions, limits, defaults, provider behavior, incident outcomes and release promises need a traceable source. Template infrastructure and test claims must be replaced with project facts.</p></div> },
      { id: 'limits', title: 'Record the limits of validation', body: <p>Read, Compile and Execute establish different things. For execution, record the command, revision, environment and observed result. An assistant needs the same evidence as anyone else. A successful isolated example does not establish production recovery; <Link href="/stages/14-post-deployment-verification">Stage 14 owns production verification</Link>.</p> },
    ]} /></div>
  </Section>
}
```

- [ ] **Step 4: Focused GREEN, lint and typecheck.** Open both AI rows and retain the named-reviewer, missing-facts and synthetic-data render assertions written in Step 1.

- [ ] **Step 5: Teeth check.** Change the feedback condition from `committed` to `committed && choice === item.answer`; wrong-answer tests must fail with missing rationale. Restore and rerun the file. Score is not a completion/verification badge.
- [ ] **Step 6: Independent review and commit** `feat(documentation): practise comment and evidence judgments`. Deferred: personal forms and registration.

