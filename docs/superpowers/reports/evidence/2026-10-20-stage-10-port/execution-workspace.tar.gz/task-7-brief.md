### Task 7: Expose the change record and checks through two compact views

**Files:** Create `RecordPanels.tsx`, `RecordPanels.test.tsx`.

**Interfaces:** Consumes Tasks 1/2/3. Produces `RecordPanel({ view: 'change' |
'evidence' })` and `ChecklistPanel()`. Export and clear operate on the whole
record from either form or checklist; checklist-only records remain exportable.
A failed clear leaves a retry enabled even when the visible draft is empty.

- [ ] **Step 1: Write full render tests.**

```tsx
import { act, fireEvent, render, screen } from '@testing-library/react'
import { useState } from 'react'
import { afterEach, beforeEach, expect, test, vi } from 'vitest'
import { DocumentationSession } from './DocumentationSession'
import { ChecklistPanel, RecordPanel } from './RecordPanels'
import { CHECKS, EMPTY_RECORD, FIELDS, RECORD_KEY, recordMarkdown, TEAM_NOTES } from './record'
let write = vi.fn<(text: string) => Promise<void>>()
beforeEach(() => { window.localStorage.clear(); write = vi.fn<(text: string) => Promise<void>>().mockResolvedValue(undefined); vi.stubGlobal('navigator', { clipboard: { writeText: write } }) })
afterEach(() => { vi.restoreAllMocks(); vi.unstubAllGlobals() })
function Harness() {
  const [view, setView] = useState<'change' | 'evidence' | 'checks'>('change')
  return <DocumentationSession><button onClick={() => setView('change')}>Change view</button><button onClick={() => setView('evidence')}>Evidence view</button><button onClick={() => setView('checks')}>Checks view</button>{view === 'checks' ? <ChecklistPanel /> : <RecordPanel view={view} />}</DocumentationSession>
}
const edit = (label: string, value: string) => fireEvent.change(screen.getByLabelText(label), { target: { value } })
test('all eight fields retain literal input across views and export only the personal record', async () => {
  const view = render(<Harness />)
  const expected = { ...EMPTY_RECORD }
  for (const section of ['change', 'evidence'] as const) {
    fireEvent.click(screen.getByText(section === 'change' ? 'Change view' : 'Evidence view'))
    for (const field of FIELDS.filter(f => f.view === section)) { expected[field.id] = `${field.id}: <b>literal</b>`; edit(field.label, expected[field.id]) }
  }
  expect(screen.getByText('8 of 8 fields recorded')).toBeTruthy()
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdown' })) })
  expect(write).toHaveBeenLastCalledWith(recordMarkdown(expected))
  expect(view.container.querySelector('b')).toBeNull()
  expect(screen.getByText(/Recording fields and checks does not verify/)).toBeTruthy()
})
test('ten checks stay in their cadence groups and a periodic-only record exports from the other view', async () => {
  render(<Harness />); fireEvent.click(screen.getByText('Checks view'))
  expect(screen.getAllByRole('checkbox')).toHaveLength(10)
  expect(screen.getByRole('group', { name: 'Per-change checks' }).querySelectorAll('input')).toHaveLength(7)
  expect(screen.getByRole('group', { name: 'Periodic checks' }).querySelectorAll('input')).toHaveLength(3)
  fireEvent.click(screen.getByRole('checkbox', { name: CHECKS[9].text }))
  fireEvent.click(screen.getByText('Evidence view'))
  expect((screen.getByRole('button', { name: 'Copy as Markdown' }) as HTMLButtonElement).disabled).toBe(false)
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdown' })) })
  expect(write).toHaveBeenLastCalledWith(recordMarkdown({ ...EMPTY_RECORD, checked: ['history'] }))
  fireEvent.click(screen.getByText('Checks view')); fireEvent.click(screen.getByRole('button', { name: 'If you are not solo' }))
  for (const note of TEAM_NOTES) expect(screen.getByText(note)).toBeTruthy()
  expect(screen.getByRole('link', { name: 'Stage 16 incident response' }).getAttribute('href')).toBe('/stages/16-incident-management')
})
test('clear from either view confirms and resets all fields and selections while failed removal can be retried', () => {
  render(<Harness />); edit('Change and scope', 'Keep until confirmed')
  fireEvent.click(screen.getByText('Evidence view')); edit('Owner and reviewer', 'Me')
  fireEvent.click(screen.getByText('Checks view')); fireEvent.click(screen.getByRole('checkbox', { name: CHECKS[9].text }))
  const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false)
  fireEvent.click(screen.getByRole('button', { name: 'Clear whole record' })); expect(window.localStorage.getItem(RECORD_KEY)).toContain('Keep until confirmed')
  confirm.mockReturnValue(true)
  const deny = vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => { throw new Error('blocked') })
  fireEvent.click(screen.getByRole('button', { name: 'Clear whole record' }))
  expect(screen.getByText(/could return after reload/)).toBeTruthy()
  expect((screen.getByRole('button', { name: 'Clear whole record' }) as HTMLButtonElement).disabled).toBe(false)
  deny.mockRestore(); fireEvent.click(screen.getByRole('button', { name: 'Clear whole record' }))
  expect(window.localStorage.getItem(RECORD_KEY)).toBeNull()
  expect(screen.getAllByRole('checkbox').some(c => (c as HTMLInputElement).checked)).toBe(false)
  fireEvent.click(screen.getByText('Change view')); expect((screen.getByLabelText('Change and scope') as HTMLTextAreaElement).value).toBe('')
  fireEvent.click(screen.getByText('Evidence view')); expect((screen.getByLabelText('Owner and reviewer') as HTMLTextAreaElement).value).toBe('')
})
test('failed storage still allows copying a draft from the other view with clipboard fallback', async () => {
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('quota') }); write.mockRejectedValue(new Error('clipboard'))
  render(<Harness />); edit('Change and scope', 'Unsaved input')
  fireEvent.click(screen.getByText('Evidence view'))
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdown' })) })
  expect((screen.getByLabelText('Markdown record') as HTMLTextAreaElement).value).toContain('Unsaved input')
  expect(screen.getByText(/Saving is unavailable/)).toBeTruthy()
})
```

- [ ] **Step 2: Run `pnpm test src/features/documentation/RecordPanels.test.tsx`; capture RED.**
- [ ] **Step 3: Add full `RecordPanels.tsx`.**

```tsx
'use client'
import Link from 'next/link'
import { useId } from 'react'
import { TeamNotes } from '@/components/TeamNotes'
import { Card, Section } from '@/components/ui'
import { CopyMarkdown } from './CopyMarkdown'
import { useDocumentationSession } from './DocumentationSession'
import { CHECKS, FIELDS, hasRecord, recordMarkdown, TEAM_NOTES } from './record'
function RecordActions() {
  const { record, warning, clear, clearFailed } = useDocumentationSession()
  const filled = FIELDS.filter(f => record[f.id].trim()).length
  const present = hasRecord(record)
  return <div className="mt-5">
    <p aria-live="polite" className="t-data text-sm text-muted">{filled} of 8 fields recorded</p>
    <p className="mt-2 text-sm text-muted">Recording fields and checks does not verify documentation. Documentation remains continuous work.</p>
    <p aria-live="polite" className="mt-2 text-sm text-warn">{warning}</p>
    <CopyMarkdown text={recordMarkdown(record)} disabled={!present} />
    <button type="button" disabled={!present && !clearFailed} onClick={clear} className="mt-3 min-h-11 border border-line px-4 text-sm disabled:text-subtle">Clear whole record</button>
  </div>
}
export function RecordPanel({ view }: { view: 'change' | 'evidence' }) {
  const root = useId(); const { record, setField } = useDocumentationSession()
  return <Section title={view === 'change' ? 'Plan your documentation change' : 'Plan the check and record evidence'}><Card>
    <p className="mb-4 text-sm text-muted">Your application only. No example answers are inserted. Saved in this browser when storage is available; export the whole record from either view.</p>
    <div className="space-y-5">{FIELDS.filter(f => f.view === view).map(field => <div key={field.id}>
      <label htmlFor={`${root}-${field.id}`} className="block text-sm font-medium">{field.label}</label>
      <p id={`${root}-${field.id}-hint`} className="my-2 text-sm text-muted">{field.hint}</p>
      <textarea id={`${root}-${field.id}`} aria-describedby={`${root}-${field.id}-hint`} value={record[field.id]} rows={2} onChange={e => setField(field.id, e.target.value)} className="w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand" />
    </div>)}</div><RecordActions />
  </Card></Section>
}
export function ChecklistPanel() {
  const { record, toggleCheck } = useDocumentationSession()
  return <Section title="Review this change and keep periodic checks visible"><Card>
    <p className="mb-4 text-sm text-muted">These are self-recorded selections. Periodic checks have their own cadence; they do not certify this stage as finished.</p>
    {[false, true].map(periodic => <fieldset key={String(periodic)} className="mb-5 min-w-0"><legend className="t-head mb-3 text-lg">{periodic ? 'Periodic' : 'Per-change'} checks</legend>
      <div className="space-y-2">{CHECKS.filter(c => c.periodic === periodic).map(check => <label key={check.id} className="relative flex min-h-11 cursor-pointer items-start gap-3 border border-line p-3 text-sm focus-within:outline-2 focus-within:outline-brand">
        <input type="checkbox" checked={record.checked.includes(check.id)} onChange={() => toggleCheck(check.id)} className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0" />
        <span aria-hidden className="mt-1 size-4 shrink-0 border border-line peer-checked:border-brand peer-checked:bg-brand" /><span className="min-w-0 break-words">{check.text}</span>
      </label>)}</div>
    </fieldset>)}
    <RecordActions />
    <div className="mt-6"><TeamNotes><ul className="space-y-3">{TEAM_NOTES.map(note => <li key={note}>{note}</li>)}</ul><p className="mt-3"><Link href="/stages/16-incident-management">Stage 16 incident response</Link></p></TeamNotes></div>
  </Card></Section>
}
```

- [ ] **Step 4: Focused GREEN, lint and typecheck.** Scope assertions to the visible panel; a second simultaneous form must not be used to hide a remount failure.
- [ ] **Step 5: Teeth check.** Temporarily set RecordActions' `filled` count to `0`; the all-eight-fields test must fail because the visible count stays zero despite the populated model. Restore and rerun the whole file. The separate export assertions still verify full-record and checklist-only serialization.
- [ ] **Step 6: Independent review and commit** `feat(documentation): add change plan and completion checks`. Deferred: stage assembly/registration, browser gates and integration.

