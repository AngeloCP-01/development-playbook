# Task 7 implementation report

Implemented the personal change/evidence views and checklist. All eight fields use the record metadata, retain literal input across panel remounts and share whole-record export and confirmed clear. The ten checks remain in their seven per-change and three periodic groups. A checklist-only record can be exported from a form or the checklist. A failed removal leaves clear enabled after navigation even though the visible record is empty. Failed writes keep the complete editable draft and allow manual Markdown copying when clipboard access fails.

The tests force the forms to remount with `key={view}`. They revisit visible fields and checks rather than mounting a second form. Clear is exercised from all three views. New controls use `t-ui` under the controller's typography ruling; existing Task 3 controls remain for its recorded M1 follow-up.

## Authorized provider correction

Provenance: the controller identified a provider-boundary risk during Task 7. The provider used render-time `canRead` inside an updater whose shared hook performs a fresh read. When permission changed without a notification before the next edit, that read returned the empty fallback while `canRead` stayed true. The edit then discarded loaded fields and checks. The regression reproduced this with change, owner and history loaded, no storage/probe event or intermediate render, denied reads/writes, then an immediate UI edit. The owner became empty.

The controller authorized expanding this task to a third product path and recorded the ruling in `progress.md`. The only provider change calls `readable()` inside that updater decision. The shared storage hook and effects are unchanged.

## Files

- `web/src/features/documentation/RecordPanels.tsx`
- `web/src/features/documentation/RecordPanels.test.tsx`
- `web/src/features/documentation/DocumentationSession.tsx` (one-line authorized correction)

Evidence stays in this workspace. Controller-owned records are excluded from the task commit.

## TDD evidence and sensitivity

The initial import RED confirmed the missing module. The behavioral shell RED failed for the right reason: the shell did not bind fields/checks to the session, so literal input disappeared after remount, checklist-only export stayed disabled, and no complete record was persisted for clear. Six tests failed. After implementation all six passed.

The added unnotified-denial regression failed for the right reason: the prior loaded owner was replaced with an empty string after the immediate edit. The other six tests passed. After the authorized provider correction all 22 tests across the three focused files passed.

Both final teeth mutations ran the entire three-file focused set, without a test-name filter. Freezing `filled` at zero failed only the all-eight-fields test (1 failure, 21 passes). Replacing fresh `readable()` with captured `canRead` failed only the new unnotified-denial regression (1 failure, 21 passes). Each mutation was restored byte for byte and followed by 22 passing tests. SHA256 restoration logs and exact mutation patches are linked below.

Commands, stdout/stderr and exit codes below are copied directly from the saved execution logs. They are not reconstructed summaries.

## Import RED

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-import-red.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (0 test)

⎯⎯⎯⎯⎯⎯ Failed Suites 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx [ src/features/documentation/RecordPanels.test.tsx ]
Error: Failed to resolve import "./RecordPanels" from "src/features/documentation/RecordPanels.test.tsx". Does the file exist?
  Plugin: vite:import-analysis
  File: /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web/src/features/documentation/RecordPanels.test.tsx:5:44
  3  |  import { afterEach, beforeEach, expect, test, vi } from "vitest";
  4  |  import { DocumentationSession } from "./DocumentationSession";
  5  |  import { ChecklistPanel, RecordPanel } from "./RecordPanels";
     |                                               ^
  6  |  import { CHECKS, EMPTY_RECORD, FIELDS, RECORD_KEY, recordMarkdown, TEAM_NOTES } from "./record";
  7  |  var _jsxFileName = "/Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web/src/features/documen...
 ❯ TransformPluginContext._formatLog node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30416:39
 ❯ TransformPluginContext.error node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30413:14
 ❯ normalizeUrl node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27438:18
 ❯ node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27506:30
 ❯ TransformPluginContext.transform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:27474:4
 ❯ EnvironmentPluginContainer.transform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:30201:14
 ❯ loadAndTransform node_modules/.pnpm/vite@8.1.5_@types+node@22.20.1_jiti@2.7.0/node_modules/vite/dist/node/chunks/node.js:20124:26

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed (1)
      Tests  no tests
   Start at  10:57:38
   Duration  842ms (transform 19ms, setup 125ms, import 0ms, tests 0ms, environment 534ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Behavioral shell RED

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-behavior-red.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (6 tests | 6 failed) 344ms
   × all eight fields retain literal input across views and export only the personal record 41ms
   × ten checks stay in their cadence groups and a periodic-only record exports from the other view 155ms
   × clear from Change view confirms the whole record and keeps a failed removal retry enabled across remounts 50ms
   × clear from Evidence view confirms the whole record and keeps a failed removal retry enabled across remounts 61ms
   × clear from Checks view confirms the whole record and keeps a failed removal retry enabled across remounts 19ms
   × failed storage still allows copying a draft from the other view with clipboard fallback 16ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 6 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > all eight fields retain literal input across views and export only the personal record
AssertionError: expected '' to be 'change: <b>literal</b>' // Object.is equality

- Expected
+ Received

- change: <b>literal</b>

 ❯ src/features/documentation/RecordPanels.test.tsx:60:9
     58|       expect(
     59|         (screen.getByLabelText(field.label) as HTMLTextAreaElement).va…
     60|       ).toBe(expected[field.id])
       |         ^
     61|     }
     62|   }

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/6]⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > ten checks stay in their cadence groups and a periodic-only record exports from the other view
AssertionError: expected true to be false // Object.is equality

- Expected
+ Received

- false
+ true

 ❯ src/features/documentation/RecordPanels.test.tsx:100:5
     98|       }) as HTMLButtonElement
     99|     ).disabled,
    100|   ).toBe(false)
       |     ^
    101|   await act(async () => {
    102|     fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdo…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[2/6]⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > clear from Change view confirms the whole record and keeps a failed removal retry enabled across remounts
 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > clear from Evidence view confirms the whole record and keeps a failed removal retry enabled across remounts
 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > clear from Checks view confirms the whole record and keeps a failed removal retry enabled across remounts
AssertionError: the given combination of arguments (null and string) is invalid for this assertion. You can use an array, a map, an object, a set, a string, or a weakset instead of a string
 ❯ src/features/documentation/RecordPanels.test.tsx:138:53
    136|     const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false)
    137|     fireEvent.click(screen.getByRole('button', { name: 'Clear whole re…
    138|     expect(window.localStorage.getItem(RECORD_KEY)).toContain(
       |                                                     ^
    139|       'Keep until confirmed',
    140|     )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[3/6]⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > failed storage still allows copying a draft from the other view with clipboard fallback
AssertionError: expected '' to be 'Unsaved input' // Object.is equality

- Expected
+ Received

- Unsaved input

 ❯ src/features/documentation/RecordPanels.test.tsx:196:5
    194|   expect(
    195|     (screen.getByLabelText('Change and scope') as HTMLTextAreaElement)…
    196|   ).toBe('Unsaved input')
       |     ^
    197|   fireEvent.click(screen.getByText('Evidence view'))
    198|   expect(

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[4/6]⎯


 Test Files  1 failed (1)
      Tests  6 failed (6)
   Start at  10:57:53
   Duration  1.60s (transform 60ms, setup 144ms, import 57ms, tests 344ms, environment 929ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Initial GREEN

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-focused-green.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  1 passed (1)
      Tests  6 passed (6)
   Start at  10:58:15
   Duration  1.30s (transform 80ms, setup 109ms, import 139ms, tests 399ms, environment 544ms)


EXIT_CODE=0
```

## Initial count teeth

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-teeth.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (6 tests | 1 failed) 653ms
   × all eight fields retain literal input across views and export only the personal record 85ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > all eight fields retain literal input across views and export only the personal record
TestingLibraryElementError: Unable to find an element with the text: 8 of 8 fields recorded. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.

Ignored nodes: comments, script, style
[36m<body>[39m
  [36m<div>[39m
    [36m<button>[39m
      [0mChange view[0m
    [36m</button>[39m
    [36m<button>[39m
      [0mEvidence view[0m
    [36m</button>[39m
    [36m<button>[39m
      [0mChecks view[0m
    [36m</button>[39m
    [36m<section[39m
      [33mclass[39m=[32m"scroll-mt-24"[39m
    [36m>[39m
      [36m<h2[39m
        [33mclass[39m=[32m"t-head mb-6 text-pretty text-xl sm:text-2xl"[39m
      [36m>[39m
        [0mPlan the check and record evidence[0m
      [36m</h2>[39m
      [36m<div[39m
        [33mclass[39m=[32m"border border-line bg-raised p-5 sm:p-6 "[39m
      [36m>[39m
        [36m<p[39m
          [33mclass[39m=[32m"mb-4 text-sm text-muted"[39m
        [36m>[39m
          [0mYour application only. No example answers are inserted. Saved in this browser when storage is available; export the whole record from either view.[0m
        [36m</p>[39m
        [36m<div[39m
          [33mclass[39m=[32m"space-y-5"[39m
        [36m>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-check"[39m
            [36m>[39m
              [0mCheck and expected result[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-check-hint"[39m
            [36m>[39m
              [0mName the check or command, its safe environment and the result you expect.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-check-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-check"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mcheck: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-evidence"[39m
            [36m>[39m
              [0mObserved evidence and limits[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-evidence-hint"[39m
            [36m>[39m
              [0mRecord what actually ran or was reviewed, revision, environment and observed result. Leave missing evidence explicit.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-evidence-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-evidence"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mevidence: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-owner"[39m
            [36m>[39m
              [0mOwner and reviewer[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-owner-hint"[39m
            [36m>[39m
              [0mWho changes and reviews this? When working alone, name yourself.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-owner-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-owner"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mowner: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-trigger"[39m
            [36m>[39m
              [0mReview trigger and follow-up[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-trigger-hint"[39m
            [36m>[39m
              [0mWhich change or periodic check brings the document back for review?[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-trigger-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-trigger"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mtrigger: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
        [36m</div>[39m
        [36m<div[39m
          [33mclass[39m=[32m"mt-5"[39m
        [36m>[39m
          [36m<p[39m
            [33maria-live[39m=[32m"polite"[39m
            [33mclass[39m=[32m"t-data text-sm text-muted"[39m
          [36m>[39m
            [0m0[0m
            [0m of 8 fields recorded[0m
          [36m</p>[39m
          [36m<p[39m
            [33mclass[39m=[32m"mt-2 text-sm text-muted"[39m
          [36m>[39m
            [0mRecording fields and checks does not verify documentation. Documentation remains continuous work.[0m
          [36m</p>[39m
          [36m<p[39m
            [33maria-live[39m=[32m"polite"[39m
            [33mclass[39m=[32m"mt-2 text-sm text-warn"[39m
          [36m/>[39m
          [36m<div[39m
            [33mclass[39m=[32m"mt-4 min-w-0"[39m
          [36m>[39m
            [36m<button[39m
              [33mclass[39m=[32m"min-h-11 border border-line px-4 text-sm disabled:cursor-default disabled:text-subtle"[39m
              [33mtype[39m=[32m"button"[39m
            [36m>[39m
              [0mCopy as Markdown[0m
            [36m</button>[39m
            [36m<p[39m
              [33maria-label[39m=[32m"Copy status: Copy as Markdown"[39m
              [33mclass[39m=[32m"mt-2 text-sm text-muted"[39m
              [33mrole[39m=[32m"status"[39m
            [36m/>[39m
          [36m</div>[39m
          [36m<button[39m
            [33mclass[39m=[32m"t-ui mt-3 min-h-11 border border-line px-4 text-sm disabled:text-subtle"[39m
            [33mtype[39m=[32m"button"[39m
          [36m>[39m
            [0mClear whole record[0m
          [36m</button>[39m
        [36m</div>[39m
      [36m</div>[39m
    [36m</section>[39m
  [36m</div>[39m
[36m</body>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/RecordPanels.test.tsx:63:17
     61|     }
     62|   }
     63|   expect(screen.getByText('8 of 8 fields recorded')).toBeTruthy()
       |                 ^
     64|   await act(async () => {
     65|     fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdo…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed (1)
      Tests  1 failed | 5 passed (6)
   Start at  10:58:34
   Duration  1.77s (transform 85ms, setup 108ms, import 145ms, tests 653ms, environment 761ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Initial restore

Command: `SHA256 and byte equality`. [Complete raw log](task-7-restore.log).

```text
Before mutation SHA256: baedecb8a3716c165d0aedad388edf0ea6ceab0b271df5199f4b3e51a9199ab8
Restored SHA256: baedecb8a3716c165d0aedad388edf0ea6ceab0b271df5199f4b3e51a9199ab8
Byte-exact restoration: True
```

## Initial restored GREEN

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-restored-green.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  1 passed (1)
      Tests  6 passed (6)
   Start at  10:58:37
   Duration  1.66s (transform 83ms, setup 95ms, import 146ms, tests 785ms, environment 516ms)


EXIT_CODE=0
```

## Unnotified-denial RED

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx`. [Complete raw log](task-7-unnotified-denial-red.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (7 tests | 1 failed) 460ms
   × an edit immediately after storage becomes unavailable retains loaded fields and checks without a notification 9ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > an edit immediately after storage becomes unavailable retains loaded fields and checks without a notification
AssertionError: expected '' to be 'Loaded owner' // Object.is equality

- Expected
+ Received

- Loaded owner

 ❯ src/features/documentation/RecordPanels.test.tsx:246:5
    244|   expect(
    245|     (screen.getByLabelText('Owner and reviewer') as HTMLTextAreaElemen…
    246|   ).toBe('Loaded owner')
       |     ^
    247|   fireEvent.click(screen.getByText('Checks view'))
    248|   expect(

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed (1)
      Tests  1 failed | 6 passed (7)
   Start at  10:58:57
   Duration  1.37s (transform 110ms, setup 114ms, import 208ms, tests 460ms, environment 494ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Provider GREEN

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts`. [Complete raw log](task-7-provider-green.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  3 passed (3)
      Tests  22 passed (22)
   Start at  11:00:00
   Duration  1.57s (transform 143ms, setup 277ms, import 299ms, tests 663ms, environment 1.32s)


EXIT_CODE=0
```

## Final count teeth

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts`. [Complete raw log](task-7-final-count-teeth.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (7 tests | 1 failed) 487ms
   × all eight fields retain literal input across views and export only the personal record 98ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > all eight fields retain literal input across views and export only the personal record
TestingLibraryElementError: Unable to find an element with the text: 8 of 8 fields recorded. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.

Ignored nodes: comments, script, style
[36m<body>[39m
  [36m<div>[39m
    [36m<button>[39m
      [0mChange view[0m
    [36m</button>[39m
    [36m<button>[39m
      [0mEvidence view[0m
    [36m</button>[39m
    [36m<button>[39m
      [0mChecks view[0m
    [36m</button>[39m
    [36m<section[39m
      [33mclass[39m=[32m"scroll-mt-24"[39m
    [36m>[39m
      [36m<h2[39m
        [33mclass[39m=[32m"t-head mb-6 text-pretty text-xl sm:text-2xl"[39m
      [36m>[39m
        [0mPlan the check and record evidence[0m
      [36m</h2>[39m
      [36m<div[39m
        [33mclass[39m=[32m"border border-line bg-raised p-5 sm:p-6 "[39m
      [36m>[39m
        [36m<p[39m
          [33mclass[39m=[32m"mb-4 text-sm text-muted"[39m
        [36m>[39m
          [0mYour application only. No example answers are inserted. Saved in this browser when storage is available; export the whole record from either view.[0m
        [36m</p>[39m
        [36m<div[39m
          [33mclass[39m=[32m"space-y-5"[39m
        [36m>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-check"[39m
            [36m>[39m
              [0mCheck and expected result[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-check-hint"[39m
            [36m>[39m
              [0mName the check or command, its safe environment and the result you expect.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-check-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-check"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mcheck: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-evidence"[39m
            [36m>[39m
              [0mObserved evidence and limits[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-evidence-hint"[39m
            [36m>[39m
              [0mRecord what actually ran or was reviewed, revision, environment and observed result. Leave missing evidence explicit.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-evidence-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-evidence"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mevidence: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-owner"[39m
            [36m>[39m
              [0mOwner and reviewer[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-owner-hint"[39m
            [36m>[39m
              [0mWho changes and reviews this? When working alone, name yourself.[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-owner-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-owner"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mowner: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
          [36m<div>[39m
            [36m<label[39m
              [33mclass[39m=[32m"t-ui block text-sm font-medium"[39m
              [33mfor[39m=[32m"_r_6_-trigger"[39m
            [36m>[39m
              [0mReview trigger and follow-up[0m
            [36m</label>[39m
            [36m<p[39m
              [33mclass[39m=[32m"my-2 text-sm text-muted"[39m
              [33mid[39m=[32m"_r_6_-trigger-hint"[39m
            [36m>[39m
              [0mWhich change or periodic check brings the document back for review?[0m
            [36m</p>[39m
            [36m<textarea[39m
              [33maria-describedby[39m=[32m"_r_6_-trigger-hint"[39m
              [33mclass[39m=[32m"t-ui w-full resize-y border border-line bg-sunken px-3 py-2 text-[15px] leading-6 text-fg focus-visible:outline-2 focus-visible:outline-brand"[39m
              [33mid[39m=[32m"_r_6_-trigger"[39m
              [33mrows[39m=[32m"2"[39m
            [36m>[39m
              [0mtrigger: &lt;b&gt;literal&lt;/b&gt;[0m
            [36m</textarea>[39m
          [36m</div>[39m
        [36m</div>[39m
        [36m<div[39m
          [33mclass[39m=[32m"mt-5"[39m
        [36m>[39m
          [36m<p[39m
            [33maria-live[39m=[32m"polite"[39m
            [33mclass[39m=[32m"t-data text-sm text-muted"[39m
          [36m>[39m
            [0m0[0m
            [0m of 8 fields recorded[0m
          [36m</p>[39m
          [36m<p[39m
            [33mclass[39m=[32m"mt-2 text-sm text-muted"[39m
          [36m>[39m
            [0mRecording fields and checks does not verify documentation. Documentation remains continuous work.[0m
          [36m</p>[39m
          [36m<p[39m
            [33maria-live[39m=[32m"polite"[39m
            [33mclass[39m=[32m"mt-2 text-sm text-warn"[39m
          [36m/>[39m
          [36m<div[39m
            [33mclass[39m=[32m"mt-4 min-w-0"[39m
          [36m>[39m
            [36m<button[39m
              [33mclass[39m=[32m"min-h-11 border border-line px-4 text-sm disabled:cursor-default disabled:text-subtle"[39m
              [33mtype[39m=[32m"button"[39m
            [36m>[39m
              [0mCopy as Markdown[0m
            [36m</button>[39m
            [36m<p[39m
              [33maria-label[39m=[32m"Copy status: Copy as Markdown"[39m
              [33mclass[39m=[32m"mt-2 text-sm text-muted"[39m
              [33mrole[39m=[32m"status"[39m
            [36m/>[39m
          [36m</div>[39m
          [36m<button[39m
            [33mclass[39m=[32m"t-ui mt-3 min-h-11 border border-line px-4 text-sm disabled:text-subtle"[39m
            [33mtype[39m=[32m"button"[39m
          [36m>[39m
            [0mClear whole record[0m
          [36m</button>[39m
        [36m</div>[39m
      [36m</div>[39m
    [36m</section>[39m
  [36m</div>[39m
[36m</body>[39m
 ❯ Object.getElementError node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/config.js:37:19
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:76:38
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:52:17
 ❯ node_modules/.pnpm/@testing-library+dom@10.4.1/node_modules/@testing-library/dom/dist/query-helpers.js:95:19
 ❯ src/features/documentation/RecordPanels.test.tsx:63:17
     61|     }
     62|   }
     63|   expect(screen.getByText('8 of 8 fields recorded')).toBeTruthy()
       |                 ^
     64|   await act(async () => {
     65|     fireEvent.click(screen.getByRole('button', { name: 'Copy as Markdo…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed | 2 passed (3)
      Tests  1 failed | 21 passed (22)
   Start at  11:00:18
   Duration  1.60s (transform 172ms, setup 243ms, import 281ms, tests 717ms, environment 1.40s)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Final count restore

Command: `SHA256 and byte equality`. [Complete raw log](task-7-final-count-teeth-restore.log).

```text
Before mutation SHA256: baedecb8a3716c165d0aedad388edf0ea6ceab0b271df5199f4b3e51a9199ab8
Restored SHA256: baedecb8a3716c165d0aedad388edf0ea6ceab0b271df5199f4b3e51a9199ab8
Byte-exact restoration: True
```

## Final count restored GREEN

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts`. [Complete raw log](task-7-final-count-teeth-restored-green.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  3 passed (3)
      Tests  22 passed (22)
   Start at  11:00:20
   Duration  1.61s (transform 202ms, setup 283ms, import 343ms, tests 865ms, environment 1.03s)


EXIT_CODE=0
```

## Provider teeth

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts`. [Complete raw log](task-7-provider-teeth.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/RecordPanels.test.tsx (7 tests | 1 failed) 859ms
   × an edit immediately after storage becomes unavailable retains loaded fields and checks without a notification 9ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/RecordPanels.test.tsx > an edit immediately after storage becomes unavailable retains loaded fields and checks without a notification
AssertionError: expected '' to be 'Loaded owner' // Object.is equality

- Expected
+ Received

- Loaded owner

 ❯ src/features/documentation/RecordPanels.test.tsx:246:5
    244|   expect(
    245|     (screen.getByLabelText('Owner and reviewer') as HTMLTextAreaElemen…
    246|   ).toBe('Loaded owner')
       |     ^
    247|   fireEvent.click(screen.getByText('Checks view'))
    248|   expect(

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed | 2 passed (3)
      Tests  1 failed | 21 passed (22)
   Start at  11:00:22
   Duration  2.18s (transform 415ms, setup 224ms, import 639ms, tests 1.61s, environment 1.55s)

 ELIFECYCLE  Test failed. See above for more details.

EXIT_CODE=1
```

## Provider restore

Command: `SHA256 and byte equality`. [Complete raw log](task-7-provider-teeth-restore.log).

```text
Before mutation SHA256: 095ececcd32d33700b300ecefb2fadc5fcd8274084a6aa3b31a09393ce41a80a
Restored SHA256: 095ececcd32d33700b300ecefb2fadc5fcd8274084a6aa3b31a09393ce41a80a
Byte-exact restoration: True
```

## Provider restored GREEN

Command: `pnpm test src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts`. [Complete raw log](task-7-provider-teeth-restored-green.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/RecordPanels.test.tsx src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  3 passed (3)
      Tests  22 passed (22)
   Start at  11:00:25
   Duration  1.74s (transform 169ms, setup 232ms, import 294ms, tests 997ms, environment 1.04s)


EXIT_CODE=0
```

## Self-review and prose pass

Read the component/test diff and the provider boundary against the brief. The panels consume the existing provider and serializer, insert no sample answers and keep practice state outside the personal record. Labels, hints, checklist groups, notes and the Stage 16 link retain the specified facts. Both warning and field count use polite live announcements. Field labels and hint IDs are unique per mounted form. Checkbox labels provide the full target area and focus outline.

Applied the humanizer review to the authored UI and report prose. Kept the specified warning, labels and cadence language. No factual or label rewrite was needed. No further issue was found in self-review. Independent task review belongs to the controller.

Deferred: stage assembly/registration and provider lifetime in the actual stage (Task 8); live browser checks, contrast, responsive/touch measurements, console checks and panel budget (Task 9); final whole-branch review and integration. No build, browser, merge, deployment or push is claimed by this task.

Mutation patches: [count](task-7-final-count-teeth.patch), [provider](task-7-provider-teeth.patch).

## Final verification

The full suite ran once after both source changes were restored: 1554 tests across 216 files passed. Final lint, typecheck and format check passed. Output contained no test or compiler warnings.

### Full suite

Command: `pnpm test`. [Complete raw log](task-7-full-suite.log).

```text

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  216 passed (216)
      Tests  1554 passed (1554)
   Start at  11:00:37
   Duration  45.27s (transform 16.03s, setup 20.92s, import 42.98s, tests 80.30s, environment 129.22s)


EXIT_CODE=0
```

### Lint

Command: `pnpm lint`. [Complete raw log](task-7-final-lint.log).

```text

> web@0.1.0 lint /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> eslint --max-warnings 0


EXIT_CODE=0
```

### Typecheck

Command: `pnpm typecheck`. [Complete raw log](task-7-final-typecheck.log).

```text

> web@0.1.0 typecheck /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> next typegen && tsc --noEmit

Generating route types...
✓ Types generated successfully

EXIT_CODE=0
```

### Format

Command: `pnpm format:check`. [Complete raw log](task-7-format-check.log).

```text

> web@0.1.0 format:check /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> prettier --check .

Checking formatting...
All matched files use Prettier code style!

EXIT_CODE=0
```


## Commit and final state

`fe93271 feat(documentation): add change plan and completion checks` contains only the three product paths listed above. [Final product diff](task-7-final.diff). The commit hooks left all three files unchanged. Controller-owned edits remain in the working tree; task product files are clean. Not merged, not pushed, not deployed.

Command: `git commit -m "feat(documentation): add change plan and completion checks" -m "Co-Authored-By: Codex Opus 4.8 (1M context) <noreply@anthropic.com>"`. [Raw commit log](task-7-commit.log).

```text
╭───────────────────────────────────────╮
│ lefthook  v2.1.10   hook:  [1mpre-commit[m │
╰───────────────────────────────────────╯
┃  format ❯ 
src/features/documentation/DocumentationSession.tsx 52ms (unchanged)
src/features/documentation/RecordPanels.test.tsx 36ms (unchanged)
src/features/documentation/RecordPanels.tsx 15ms (unchanged)

┃  lint ❯ 

[38;2;56;56;56m  ────────────────────────────────────[m
summary: (done in 2.15 seconds)
✓ format (0.42 seconds)
✓ lint (2.13 seconds)
[feat/stage-10-documentation fe93271] feat(documentation): add change plan and completion checks
 3 files changed, 396 insertions(+), 1 deletion(-)
 create mode 100644 web/src/features/documentation/RecordPanels.test.tsx
 create mode 100644 web/src/features/documentation/RecordPanels.tsx

EXIT_CODE=0
```

Command: `git status --short`. [Raw state log](task-7-final-status.log).

```text
 M .superpowers/sdd/2026-10-20-stage-10-interactive-port/task-2-report.md
 M KICKOFF.md
 M docs/superpowers/reports/2026-10-20-stage-10-port-execution.md
 M docs/task.md

EXIT_CODE=0
```
