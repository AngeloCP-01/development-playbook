from pathlib import Path
import hashlib, json, tarfile
root = Path.cwd()
source = root / '.superpowers/sdd/2026-10-20-stage-10-interactive-port'
target = root / 'docs/superpowers/reports/evidence/2026-10-20-stage-10-port'
target.mkdir(parents=True, exist_ok=True)
archive = target / 'execution-workspace.tar.gz'
external = json.loads((source / 'external-source-preservation.json').read_text())
excluded = {e['path'] for e in external['entries']}
assert hashlib.sha256(Path(external['local_archive']).read_bytes()).hexdigest() == external['archive_sha256']
for entry in external['entries']:
    raw = (source / entry['path']).read_bytes()
    assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], entry['path']
files = sorted(p for p in source.rglob('*') if p.is_file() and p.relative_to(source).as_posix() not in excluded)
entries = []
for p in files:
    data = p.read_bytes()
    entries.append({'path': p.relative_to(source).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'w:gz') as bundle:
    for p in files:
        bundle.add(p, arcname=p.relative_to(source).as_posix(), recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    members = {m.name: m for m in bundle.getmembers() if m.isfile()}
    assert set(members) == {e['path'] for e in entries}
    for e in entries:
        data = bundle.extractfile(members[e['path']]).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256'], e['path']
manifest = {'source': source.relative_to(root).as_posix(), 'files': len(entries), 'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': entries, 'external_snapshots': external}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(entries), 'archive_bytes': archive.stat().st_size, 'verified': True, 'archive_sha256': manifest['archive_sha256']}))
