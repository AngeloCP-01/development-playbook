# Task 2 report: mounted documentation session

## Result and scope

Implemented `DocumentationSession.tsx` and its nine render tests. The mounted provider keeps failed writes and clears visible across child panel remounts, normalizes unknown storage, preserves other-view data, exposes honest storage warnings, and holds practice state in memory. Successful writes use the existing shared storage hook's notifications. Server markup starts empty and hydration loads the saved record without a recoverable error.

Production source follows the approved task slice, with formatting only. No shared hook, dependency, registry, stage UI, parent file, or server changed. Deferred: actual forms and exercise UI; mounting the provider around the stage Stepper belongs to the later integration task. Independent review is supplied by the controller and is not claimed in this report.

## TDD sequence and test intent

Before writing tests, identified the breaks they must catch: losing record/check/practice data on panel changes; persisting practice across reloads; allowing malformed or unknown storage into the next save; discarding the other view's valid data; losing unsaved edits on failed storage operations; replacing a failed draft with external storage; omitting same-tab notifications; clearing despite cancellation; retaining the visible record after failed removal; and hydrating against a client-only initial value.

1. Wrote the approved nine tests before implementation. The missing-module run (`task-2-import-red.log`, exit 1) establishes harness readiness only.
2. Added a shared-hook-only provider shell (`task-2-shell.tsx.txt`). Initial behavioral run (`task-2-behavior-red.log`, exit 1) had four failures and five passes. The failed-write observation disappearing was a meaningful behavior failure. The ambiguous warning query was a harness failure and does not count as behavioral RED.
3. Ran the prescribed full source once; `task-2-first-green-attempt.log` (exit 1) showed only the three ambiguous warning queries remained. No product behavior was changed in response to those errors.
4. Controller approved the minimal harness correction. Restored the shared-hook-only shell and reran the corrected tests before restoring the full provider: four behavioral failures and five passes (`task-2-corrected-behavior-red.log`, exit 1). These failed for the right reasons: missing saving warning, missing unsaved observation, clear ignoring cancellation, and failed clear retaining the saved value on screen.
5. Restored the full provider and ran focused GREEN: nine passed (`task-2-green.log`, exit 0).

The real shared hook and browser storage implementation run in these tests. Spies replace only denied storage access and the confirmation response. The hydration test uses real server rendering and `hydrateRoot`.

## PLAN-AUTHORED harness correction

The proposed Probe rendered two `<output>` elements, each with implicit role `status`, beside `<p role="status">`. `getByRole('status')` was ambiguous. The raw errors list all three elements. The controller ruling allowed naming the warning paragraph `aria-label="saving warning"` and scoping every warning query with that accessible name. Output roles and all warning/hydration assertions remain intact. Exact correction: `task-2-harness-correction.diff`.

No implementation or architecture correction was needed. No unrelated fix is retained.

## Teeth check and restoration

Applied the prescribed mutation from `setDraft(saved ? null : next)` to `setDraft(saved || canRead ? null : next)`. Ran the complete Task 1/2 suite while mutated: exactly the later-failed-write test failed, with expected `Unsaved observation` and received an empty string; the other twelve tests passed (exit 1). This confirms that readable storage does not imply a write succeeded.

Restored the original line and reran both task files: thirteen passed (exit 0). The exact forward and reverse diffs are `task-2-teeth.diff` and `task-2-restoration.diff`; `task-2-green-source.tsx.txt` is the restored source snapshot. No mutation remains in the component.

## Verification and self-review

- Full `pnpm test`: 210 files, 1,525 tests passed, exit 0.
- Task 1/2 after restoration: 2 files, 13 tests passed, exit 0.
- Repository-wide `pnpm lint`: exit 0, no diagnostics.
- `pnpm typecheck` runs Next type generation first: exit 0.
- Repository-wide `pnpm format:check`: exit 0.
- `git diff --check`: exit 0 before staging; final staged whitespace check recorded separately. Initial staging included the supplied task brief through an overly broad filename glob; it was removed from the index before commit. Blank unchanged-context lines in evidence diffs were normalized after the initial whitespace check flagged them. Product sources were unaffected.
- Self-review compared implementation and tests with the complete Task 2 brief and global constraints: one provider context; exact required exports; stable module server-empty record; no effects; persistent record and session-only practices; failed-draft precedence; normalization before updates; confirmed whole-record clear; read/write/clear warnings; unchanged shared hook. Test source differs only in formatting and the approved warning query correction.
- This headless provider is not registered in the live stage yet. Browser contrast, responsive, production-console and development-console audits remain controller-level stage integration checks; no live-build claim is made here.

## Raw terminal output

All logs below include their command and process exit status. Initial import/harness error runs are preserved alongside this report under their filenames above.

### Corrected behavioral RED

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentationSession.test.tsx (9 tests | 4 failed) 123ms
   × failed reads announce the problem and keep subsequent edits across panel remounts 49ms
   × a later failed write retains the whole draft ahead of external storage updates 4ms
   × clear cancellation preserves everything and confirmed clear removes the complete saved record without resetting practice 4ms
   × a failed clear empties the mounted draft while warning that the saved copy can return 3ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 4 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > failed reads announce the problem and keep subsequent edits across panel remounts
AssertionError: expected '' to contain 'Saving is unavailable'

- Expected
+ Received

- Saving is unavailable

 ❯ src/features/documentation/DocumentationSession.test.tsx:107:78
    105|   })
    106|   render(<Harness />)
    107|   expect(screen.getByRole('status', { name: 'saving warning' }).textCo…
       |                                                                              ^
    108|     'Saving is unavailable',
    109|   )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/4]⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > a later failed write retains the whole draft ahead of external storage updates
AssertionError: expected '' to be 'Unsaved observation' // Object.is equality

- Expected
+ Received

- Unsaved observation

 ❯ src/features/documentation/DocumentationSession.test.tsx:131:73
    129|   edit('evidence', 'Unsaved observation')
    130|   fireEvent.click(screen.getByText('Switch panel'))
    131|   expect((screen.getByLabelText('evidence') as HTMLInputElement).value…
       |                                                                         ^
    132|     'Unsaved observation',
    133|   )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[2/4]⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > clear cancellation preserves everything and confirmed clear removes the complete saved record without resetting practice
AssertionError: expected null not to be null
 ❯ src/features/documentation/DocumentationSession.test.tsx:200:55
    198|   const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false)
    199|   fireEvent.click(screen.getByText('Clear'))
    200|   expect(window.localStorage.getItem(RECORD_KEY)).not.toBeNull()
       |                                                       ^
    201|   confirm.mockReturnValue(true)
    202|   fireEvent.click(screen.getByText('Clear'))

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[3/4]⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > a failed clear empties the mounted draft while warning that the saved copy can return
AssertionError: expected 'Saved' to be '' // Object.is equality

- Expected
+ Received

+ Saved

 ❯ src/features/documentation/DocumentationSession.test.tsx:222:71
    220|   fireEvent.click(screen.getByText('Clear'))
    221|   fireEvent.click(screen.getByText('Switch panel'))
    222|   expect((screen.getByLabelText('change') as HTMLInputElement).value).…
       |                                                                       ^
    223|   expect(window.localStorage.getItem(RECORD_KEY)).toContain('Saved')
    224|   expect(screen.getByRole('status', { name: 'saving warning' }).textCo…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[4/4]⎯


 Test Files  1 failed (1)
      Tests  4 failed | 5 passed (9)
   Start at  10:11:55
   Duration  898ms (transform 44ms, setup 103ms, import 58ms, tests 123ms, environment 527ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

### Focused GREEN

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  1 passed (1)
      Tests  9 passed (9)
   Start at  10:12:16
   Duration  821ms (transform 44ms, setup 96ms, import 67ms, tests 124ms, environment 445ms)


EXIT STATUS: 0
```

### Teeth mutation

```text
$ pnpm test src/features/documentation/record.test.ts src/features/documentation/DocumentationSession.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/record.test.ts src/features/documentation/DocumentationSession.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentationSession.test.tsx (9 tests | 1 failed) 125ms
   × a later failed write retains the whole draft ahead of external storage updates 7ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > a later failed write retains the whole draft ahead of external storage updates
AssertionError: expected '' to be 'Unsaved observation' // Object.is equality

- Expected
+ Received

- Unsaved observation

 ❯ src/features/documentation/DocumentationSession.test.tsx:133:73
    131|   edit('evidence', 'Unsaved observation')
    132|   fireEvent.click(screen.getByText('Switch panel'))
    133|   expect((screen.getByLabelText('evidence') as HTMLInputElement).value…
       |                                                                         ^
    134|     'Unsaved observation',
    135|   )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed | 1 passed (2)
      Tests  1 failed | 12 passed (13)
   Start at  10:12:19
   Duration  695ms (transform 49ms, setup 70ms, import 81ms, tests 128ms, environment 333ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

### Restored Task 1/2 GREEN

```text
$ pnpm test src/features/documentation/record.test.ts src/features/documentation/DocumentationSession.test.tsx

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/record.test.ts src/features/documentation/DocumentationSession.test.tsx


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  2 passed (2)
      Tests  13 passed (13)
   Start at  10:12:22
   Duration  706ms (transform 49ms, setup 70ms, import 80ms, tests 193ms, environment 312ms)


EXIT STATUS: 0
```

### Full test suite

```text
$ pnpm test

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  210 passed (210)
      Tests  1525 passed (1525)
   Start at  10:12:36
   Duration  35.85s (transform 16.59s, setup 16.37s, import 37.41s, tests 60.92s, environment 100.45s)


EXIT STATUS: 0
```

### Final lint

```text
$ pnpm lint

> web@0.1.0 lint /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> eslint --max-warnings 0


EXIT STATUS: 0
```

### Final typecheck

```text
$ pnpm typecheck

> web@0.1.0 typecheck /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> next typegen && tsc --noEmit

Generating route types...
✓ Types generated successfully

EXIT STATUS: 0
```

### Final format check

```text
$ pnpm format:check

> web@0.1.0 format:check /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> prettier --check .

Checking formatting...
All matched files use Prettier code style!

EXIT STATUS: 0
```

### Mutation diff

```diff
--- DocumentationSession.tsx green
+++ DocumentationSession.tsx teeth mutation
@@ -80,7 +80,7 @@
     } catch {
       /* keep stage-session draft */
     }
-    setDraft(saved ? null : next)
+    setDraft(saved || canRead ? null : next)
     setFailure(saved ? null : 'save')
     window.dispatchEvent(new Event(PROBE_EVENT))
   }
```

### Restoration diff

```diff
--- DocumentationSession.tsx teeth mutation
+++ DocumentationSession.tsx restored
@@ -80,7 +80,7 @@
     } catch {
       /* keep stage-session draft */
     }
-    setDraft(saved || canRead ? null : next)
+    setDraft(saved ? null : next)
     setFailure(saved ? null : 'save')
     window.dispatchEvent(new Event(PROBE_EVENT))
   }
```

## Fix round 1: I1 later read denial (BASE 6ebcecf)

I1 is a blocking PLAN-AUTHORED provider retention gap; the shared hook's read-denial fallback is PRE-EXISTING. The controller authorized a provider-local correction because the spec requires retention when storage fails. Verified the review against the provider and shared hook, then reproduced it with two render regressions written before changing production code.

The original provider had no local draft after successful load/save. The shared hook returned `EMPTY_RECORD` on a later denied read, so the provider displayed empty fields/checks and used that fallback for its next edit. The new tests first prove a populated record loaded successfully, then deny reads and notify subscribers. Their RED failures were for the right reason: expected `Already visible`/`First load`, received an empty string. The existing thirteen covering tests stayed green.

The correction keeps the last readable normalized snapshot in provider state. A guarded render-time state adjustment tracks changes to the shared hook's snapshot while reads work; it performs no effect-body updates. Rendering and the next edit use the retained snapshot while reads are denied. An edited draft continues to take precedence over external updates until a successful retry; without local edits, recovery accepts external data and refreshes the retained snapshot. No shared hook or subscription mechanism was changed.

The first regression checks loaded fields/checks, denial notification, child remount, next edit, recovery with conflicting external storage, complete-draft retry, and acceptance of later external updates after that retry. The second checks recovery without edits and a second denial after an external refresh. Both tests assert literal field and checklist values through the real provider and shared hook. They simulate read denial at the storage boundary.

Targeted teeth mutation removed the retained-snapshot branch only from the updater. The visible record initially survived denial, but the next edit lost `Already visible`, proving that render-only retention would be insufficient. Exactly that new regression failed; the other fourteen tests passed. Restored the updater byte for byte and reran both task files: fifteen passed.

Self-review: compared the fix with I1 and the controller ruling, checked that recovered external updates are not frozen behind a stale snapshot, and retained original hydration, failed-write, failed-clear, and same-tab tests. No effect, ref mutation, shared-hook repair, or downstream UI was added. C1 provider placement and C2 warning/export/retry UI remain later-task controller obligations. Parent delivery-report changes were observed and left untouched.

Exact source/test change: `task-2-fix1-source.diff`. Mutation and inverse: `task-2-fix1-teeth.diff`, `task-2-fix1-restoration.diff`. Restored source: `task-2-fix1-green-source.tsx.txt`. Independent re-review remains the controller's step.

### Fix round 1 raw terminal output

#### I1 transition RED

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentationSession.test.tsx (11 tests | 2 failed) 194ms
   × later read denial retains visible fields and checks through remount and editing until the complete draft can be saved 18ms
   × read recovery without local edits accepts external changes and retains that refreshed record if reads fail again 10ms

 Test Files  1 failed | 1 passed (2)
      Tests  2 failed | 13 passed (15)
   Start at  10:20:58
   Duration  1.06s (transform 96ms, setup 97ms, import 132ms, tests 197ms, environment 557ms)

 ELIFECYCLE  Test failed. See above for more details.

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 2 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > later read denial retains visible fields and checks through remount and editing until the complete draft can be saved
AssertionError: expected '' to be 'Already visible' // Object.is equality

- Expected
+ Received

- Already visible

 ❯ src/features/documentation/DocumentationSession.test.tsx:133:71
    131|   const denied = vi.spyOn(Storage.prototype, 'getItem').mockImplementa…
    132|   act(() => window.dispatchEvent(new StorageEvent('storage', { key: RE…
    133|   expect((screen.getByLabelText('change') as HTMLInputElement).value).…
       |                                                                       ^
    134|   fireEvent.click(screen.getByText('Switch panel'))
    135|   expect((screen.getByLabelText('evidence') as HTMLInputElement).value…

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/2]⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > read recovery without local edits accepts external changes and retains that refreshed record if reads fail again
AssertionError: expected '' to be 'First load' // Object.is equality

- Expected
+ Received

- First load

 ❯ src/features/documentation/DocumentationSession.test.tsx:168:71
    166|   act(() => window.dispatchEvent(new StorageEvent('storage', { key: RE…
    167|   fireEvent.click(screen.getByText('Switch panel'))
    168|   expect((screen.getByLabelText('change') as HTMLInputElement).value).…
       |                                                                       ^
    169|   denied.mockRestore()
    170|   act(() => {

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[2/2]⎯


EXIT STATUS: 1
```

#### Fix GREEN

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  2 passed (2)
      Tests  15 passed (15)
   Start at  10:21:19
   Duration  1.27s (transform 88ms, setup 173ms, import 137ms, tests 234ms, environment 659ms)


EXIT STATUS: 0
```

#### Updater mutation RED

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web

 ❯ |dom| src/features/documentation/DocumentationSession.test.tsx (11 tests | 1 failed) 137ms
   × later read denial retains visible fields and checks through remount and editing until the complete draft can be saved 12ms

⎯⎯⎯⎯⎯⎯⎯ Failed Tests 1 ⎯⎯⎯⎯⎯⎯⎯

 FAIL  |dom| src/features/documentation/DocumentationSession.test.tsx > later read denial retains visible fields and checks through remount and editing until the complete draft can be saved
AssertionError: expected '' to be 'Already visible' // Object.is equality

- Expected
+ Received

- Already visible

 ❯ src/features/documentation/DocumentationSession.test.tsx:165:71
    163|   ).toContain('Saving is unavailable')
    164|   edit('evidence', 'Edited while denied')
    165|   expect((screen.getByLabelText('change') as HTMLInputElement).value).…
       |                                                                       ^
    166|     'Already visible',
    167|   )

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯[1/1]⎯


 Test Files  1 failed | 1 passed (2)
      Tests  1 failed | 14 passed (15)
   Start at  10:21:39
   Duration  854ms (transform 55ms, setup 85ms, import 89ms, tests 140ms, environment 489ms)

 ELIFECYCLE  Test failed. See above for more details.

EXIT STATUS: 1
```

#### Restored Task 1/2 GREEN

```text
$ pnpm test src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run src/features/documentation/DocumentationSession.test.tsx src/features/documentation/record.test.ts


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  2 passed (2)
      Tests  15 passed (15)
   Start at  10:21:42
   Duration  678ms (transform 49ms, setup 57ms, import 80ms, tests 154ms, environment 334ms)


EXIT STATUS: 0
```

#### Full suite after fix

```text
$ pnpm test

> web@0.1.0 test /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> vitest run


 RUN  v4.1.10 /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web


 Test Files  210 passed (210)
      Tests  1527 passed (1527)
   Start at  10:21:53
   Duration  33.02s (transform 16.02s, setup 15.68s, import 36.49s, tests 54.95s, environment 90.44s)


EXIT STATUS: 0
```

#### Lint after fix

```text
$ pnpm lint

> web@0.1.0 lint /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> eslint --max-warnings 0


EXIT STATUS: 0
```

#### Typecheck after fix

```text
$ pnpm typecheck

> web@0.1.0 typecheck /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> next typegen && tsc --noEmit

Generating route types...
✓ Types generated successfully

EXIT STATUS: 0
```

#### Formatting check after fix

```text
$ pnpm format:check

> web@0.1.0 format:check /Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter/web
> prettier --check .

Checking formatting...
All matched files use Prettier code style!

EXIT STATUS: 0
```

#### Updater mutation diff

```diff
--- DocumentationSession.tsx fixed
+++ DocumentationSession.tsx updater mutation
@@ -85 +85 @@
-        draft ?? (canRead ? normalizeRecord(previous) : lastReadable.record),
+        draft ?? normalizeRecord(previous),
```

#### Updater restoration diff

```diff
--- DocumentationSession.tsx updater mutation
+++ DocumentationSession.tsx restored
@@ -85 +85 @@
-        draft ?? normalizeRecord(previous),
+        draft ?? (canRead ? normalizeRecord(previous) : lastReadable.record),
```

Humanizer review: split the dense test-boundary sentence and kept the observed field values and recovery behavior explicit. Terminal output and code are unchanged.
