# Task 9 independent review

Reviewed 2026-10-23. Range: `7f803bc..534b681`. Worktree:
`/Users/angelito/personal/Development-Playbook/.worktrees/stage10-chapter`.

**Spec compliance: compliant for the submitted verification/reader checkpoint,
with one nonblocking records finding.** The controller's separate final
whole-branch review and closing archive/records remain required. This review
does not mark the entire Task 9 delivery complete.

**Task quality: Approved, with Minor T9-M1 carried to final triage.** No Critical
or Important finding was established. Reader R-M1 remains a separate carried
Minor; its raw MISFILED result has not been upgraded or dismissed.

## Scope and method

Read the dispatch, Task 9 brief, global constraints and verifier report, then
the supplied actual range package. The package was the single view of changed
files, including the canonical execution report, coverage, reader report,
handoff records and four application changes. I did not rederive a Git diff or
separately reread changed application files. I inspected recorded harnesses,
raw results and reader outputs to assess their claims. No unchanged application
source was inspected, and no broad tests, builds, browser sessions, commits or
source edits were performed.

The following focused evidence checks addressed concrete risks:

- Lost evidence after retiring tracked Task 1/2 scratch paths: verified the
  compressed archive hash and the size/SHA256 of all 391 manifest members,
  including 56 Task 1/2 members. All matched. The nine separately preserved
  external snapshots also matched their archive and member hashes.
- Reuse of results from a different application: compared the three complete
  matrix/final-gate/reader manifests, then compared every listed file with the
  current tree. All 567 files matched, with source identity
  `f2a91fb65cdab8972153e1064bac8921d7f729761dfeb52d96af8d8ecf689c1a`.
- Changed held-out inputs: compared the port's scenario/questions with the
  accepted chapter cold-reader files byte for byte. Both matched their recorded
  hashes. The correction-rerun report links those files rather than reproducing
  the complete instruments; searching only that report would give a false
  mismatch.
- A height-only matrix guard hiding narrow targets: inspected recorded target
  geometry below 1024px. There were zero nonexempt targets under 44px wide.

These were evidence inspections, not new application test runs.

## Evidence-based strengths

The product diff is confined to the intended corrections:
`CopyMarkdown.tsx:40` and `SelectionTabs.tsx:52` receive `t-ui`;
`LookupPanels.tsx:191` and `RecordPanels.tsx:134` receive standalone-link hit
areas. Destinations and event behavior are unchanged. The actual browser guards
measure computed typeface/variation and link geometry instead of mirroring class
strings.

The guard records show meaningful RED, GREEN, sensitivity and restoration:

| Correction | RED | GREEN | Teeth | Restored |
| --- | --- | --- | --- | --- |
| Control type role | Two named leaves fail; four controls present; Newsreader/normal instead of Archivo and the UI width setting | Zero failures | Removing only CopyMarkdown's token produces exactly its one named failure | Zero failures after byte-exact restoration and fresh build |
| Standalone links | Two failures: Stage 05 is 17px high; Stage 16 is 16px | Both 44px; zero failures | Removing only Stage 05's minimum height produces one failure at 29.75px | Both 44px; zero failures after restoration/build |

The typography chronology is disclosed accurately in the detailed evidence. The
first measurement-only run exited 0 and the premature empty probe are explicitly
excluded from TDD evidence. The guarded redo removes the additions before its
failing baseline, implements the minimum changes after that failure, and restores
the same application bytes used by the completed gate/matrix. The earlier lapse
is retained rather than relabeled. Five existing control behavior tests pass
after the redo. This review independently covers all four final product changes.

The final raw gate records all seven commands exiting 0: format, lint, generated
route typecheck, the full 1,558 tests across 218 files with one worker, production
build, 27 production browser checks, and the separate development sweep with zero
React validation warnings. Earlier default-run failures, the unchanged snapshot
repeat and isolated timing passes remain available. The single-worker run keeps
all files, assertions and 5s limits; it is not evidence that the default parallel
run subsequently passed. No timeout, snapshot or committed runner configuration
was changed.

The expanded matrix has 1,358 recorded states, twelve panels, seven prescribed
widths and both themes. Its harness explicitly traverses every selectable row,
all three ADR specimens, wrong/right answers for all seven practice cases,
disclosures/team notes, filled fields, checked boxes, copy success/denial/missing
API, manual text and read/write/clear warning states. Each warning-state category
has 42 records. The 157 measured color/style pairs have minimum contrast
5.060095635:1; the matrix records zero overflow, contrast or target findings.
All 784 keyboard/disclosure observations pass their recorded expectations.
The largest initial 1024x768 panel is 1.750631 screens; the largest opened
material state is 2.509257 screens. No D-52 split or exception increase was
needed. These are material-state measurements, not every possible combination
or screen-reader certification.

`docs/stage-10-status.md:15` supplies the twelve-row chapter-to-implementation
trace, including all nine teaching subsections, entry criteria, artifacts,
definition of done, team guidance and eight traps. It names actual interactions
and proving tests, keeps the hand-port duplication explicit, and assigns none of
the coverage to a research appendix or future companion.

The source navigation record preserves all nine URLs, dates, returned titles and
snapshots. The destination record shows the actual selected panels for Stages
03/04/05/06/13/14/16. Stage 05 lands on `tab-commits` / `panel-commits`, and the
Stage 10 History click has its own retained observation. External-page console
events are kept separate from local application evidence. Full external texts
remain in a verified local archive while portable navigation results enter the
committed archive.

Both fresh reader briefs prohibit source/chapter/private-state access and give
the same public URL and frozen inputs. The lookup brief prevents the first
navigation snapshot from revealing panel bodies before the choices are frozen.
The reports retain actual artifacts, first choices, navigation retries, explicit
unknown project facts and browser release. Sequential ownership and the
between-reader empty-record observation support the claimed isolation. The
completeness reader supplies actual drafts and no teaching-gap finding; lookup
retains 4 HIT / 1 MISFILED. Both use the stable reader BUILD_ID
`YDyl-9Cl-MRjn8rpkfEza`; the controller's handoff and overnight records preserve
source identity.

The records distinguish feature 16/18 ready stages from develop 15/18, retain
W-6 at 22 drawn / 27 registered, and preserve the required deferrals. Evidence,
verification and tracker changes have separate conventional commits. The
historical 28-commit verifier checkpoint is not presented as the current tip.

## Findings

### T9-M1 (Minor, introduced records wording): contention is stated as established causation

Location: `KICKOFF.md:49`.

The handoff says: “The default parallel run failed under contention”. The
verifier's Unit-failure diagnosis section is more precise: the process sample
supports a contention hypothesis but does not establish a unique cause. Passing
unchanged focused/isolated tests and a serialized full run do not identify why
the original parallel run failed, including its transient Shiki difference.

Impact: a cold-start reader may treat an unproven environmental diagnosis as a
settled explanation. This is a records accuracy issue, not an observed product
failure or a reason to discard the valid single-worker result.

Requested correction: say the default run failed and that contention is the
working hypothesis, retaining the passing isolated/serialized results and the
unchanged test limits. Provenance: introduced during Task 9 handoff editing;
not a plan-authored implementation defect. Carry to the controller's final
Minor triage and records fix wave.

Critical: none. Important: none. No additional product Minor established in
this range. Reader R-M1 is already recorded at
`docs/superpowers/reports/2026-10-20-stage-10-port-reader-rerun.md:48`; its final
navigation disposition belongs to the whole-branch review.

## Disproved suspicions and verification limits

- DISPROVED possible loss of the deleted Task 1/2 evidence: the archive preserves
  the final reports and raw logs, its complete hash check passes, and original
  commits remain in history.
- DISPROVED possible gate/matrix/reader source mismatch: all 567 manifests and
  current file hashes agree despite distinct production BUILD_IDs.
- DISPROVED instrument drift: both files are byte-identical to the accepted
  chapter instruments. The first attempted comparison used the linking report
  rather than its retained input files.
- DISPROVED a vacuous final font guard: it requires all four actual controls and
  the expected face/variation. Its one-leaf mutation fails exactly that leaf.
- Cannot verify a unique cause for the original parallel failures. The detailed
  report correctly limits that inference; T9-M1 concerns the stronger summary.
- C1 (evidence scope): the denied-storage matrix page captures `pageerror` but lacks the ordinary
  context's `console` error listener. The passing shared console sweep covers
  ordinary pages/panels. The matrix alone cannot establish absence of
  `console.error` emissions specifically in its denied-storage warning states.
  No actual console failure was observed; this is an evidence-scope limit.
- I did not independently operate a browser, recertify all screenshot appearance,
  use a screen reader or revisit external pages. This review assesses retained
  exact-source evidence and the recorded reader outputs.

## Remaining closure and branch state

The controller must complete the separate `79f9e31..HEAD` whole-branch review,
triage R-M1 and T9-M1, resolve any blockers through independent fix verification,
then refresh/hash-check the closing archive and records. The present archive
passes its checkpoint verification; it cannot already contain this review or a
future whole-branch disposition. Finishing-a-development-branch follows those
steps. Any merge still needs the user's separate approval.

At the reviewed tip `534b681`: 30 commits off develop base `79f9e31`, 19 off
chapter tip `c092ac7`; tracked tree clean before this ignored review report was
written. Recorded exact-source results: 1,558/1,558 tests across 218 files,
production build clean, 27/27 production browser checks, development sweep 1/1.
Parent preservation is supported by the twelve recorded hashes and stable
port-3200 ownership. NOT merged, NOT pushed, NOT deployed. This is an approved
task checkpoint with the stated Minor and closure obligations, not final branch
approval.

Prose review: applied the humanizer guidance; retained concrete measurements,
uncertainty, literal findings and source paths. Removed promotional framing and
kept the review's scope separate from recorded execution claims.
