# Frozen lookup first choices

Frozen before reading any panel body. The first load returned only the visible Stage steps tab labels and public aria-controls values. No rail hints were shown in that result.

| Question | First-choice visible rail label | Public panel control |
| --- | --- | --- |
| 1. A second maintainer cannot run the app from a fresh clone. Where do I find what the setup guide must include and how to verify it? | 02 Verify the README | panel-readme |
| 2. We replaced an earlier architecture decision. What should I write now, and how does a reader discover that the old decision no longer applies? | 03 Replace a decision | panel-decisions |
| 3. A user needs the exact allowed values and defaults for a retry option. Should that live in a tutorial, reference page or explanation? | 04 State exact facts | panel-reference |
| 4. This change adds configuration and a response field. Which documents need updates, who owns them, and what checks detect drift? | 06 Trace the change | panel-changes |
| 5. An AI assistant drafted documentation claiming a fix was validated. What evidence must I check before publishing it? | 08 Check the evidence | panel-ai |

The rail also showed: 01 Choose a document; 05 Explain the exception; 07 Keep history usable; 09 Plan your change; 10 Plan the check; 11 Review this change; 12 Spot the trap.
